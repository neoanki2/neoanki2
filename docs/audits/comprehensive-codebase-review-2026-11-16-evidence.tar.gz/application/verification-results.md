# Focused baseline verification results

Executed only after the core investigator explicitly released the exclusive timing window. No product/test/snapshot source edits, GUI/app launches, device/cloud access or unchanged reruns occurred. Baseline tests ran against the pinned snapshot; documentation validation ran against the live current workspace separately.

| Stage | Exact entry point | Actual result |
| --- | --- | --- |
| Core | Standard swift test, snapshot/NeoAnkiCore, dedicated application/verification/core scratch, recorded filter | PASS: 78 tests, 0 suites; exit 0; no issues/errors |
| Root | Standard swift test, snapshot root, dedicated application/verification/root scratch, recorded filter | PASS: 9 prose + 18 poem + 53 feature tests in 2 suites + 3 app builder tests = 83; exit 0; no issues/errors |
| Documentation | `swift Scripts/validate-docs.swift`, live workspace | PASS: 53 features; exit 0 |
| Pinned source integrity | SHA-256 against snapshot-manifest.json after verification | PASS: all 866 tracked files matched; zero mismatches |

Total selected baseline: **161 tests passed** as reported by the Swift Testing runners. Runtime argument instances are not separately asserted as an additional test count. Core test coverage includes eligibility plans/family/scoped limits/read-snapshot checks, queue/work ordering, availability, due hydration, reservations, authored compatibility/security, contextual schemas and atomic card reconciliation. Root coverage includes both remaining generators, actual native registry/import/model refresh, receipt/demand/recovery and progressive shared study/repair/undo contracts.

The root command compiled the Swift package target/test graph, including native UI modules, but selected only headless tests and launched no application/window. Test/build elapsed times are retained in receipts for reproducibility and are **not performance measurements**.

Reproducibility files:

- `verification-selection.json`: selected source paths/hashes and all function/module names.
- `verification-commands.txt`, `core-verification-filter.txt`, `root-verification-filter.txt`: exact command arguments and regexes.
- `verification/{core,root,docs}.log`: original raw logs.
- `verification/{core,root,docs}-result.json`: command, timestamps, source basis, exit status, observed summary lines and issue/error list.
- `verification/snapshot-integrity-after.json`: final source hash audit.
- `verification-plan.md`: meaningful new differential/atomicity/recovery/bounded-work acceptance tests for future typed creation and bounded study-head implementation.

These results establish baseline compatibility and meaningful existing coverage. Neither recommended implementation exists yet; no resulting speedup or future acceptance pass is claimed.

The independent refresh counting probe was compiled/run by the core investigator, not by this baseline runner. Its authoritative source is `integrations/metadata-probe/Sources/RefreshProbe/Probe.swift` (including four required protocol forwarding methods), and output is `core/refresh-counts.jsonl`. The earlier `application/refresh-count-probe.swift` is an uncompiled draft. Actual counts confirm the static lower bound: three unchanged refreshes after browsing yield home=3, catalog=3, items=3, scoped availability=36, cursor reads=6 and widget publications=3. Journal observation is deliberately ended in that probe, so these counts exclude additional journal/UI callback work.
