#!/usr/bin/env python3
"""One-shot baseline runner; only execute a stage after coordinator releases perf window."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, shlex, subprocess, sys, time

out = Path(__file__).resolve().parent
plan = json.loads((out / 'verification-selection.json').read_text())
parser = argparse.ArgumentParser()
parser.add_argument('stage', choices=['core', 'root', 'docs', 'list'])
args = parser.parse_args()
if args.stage == 'list':
    print((out / 'verification-commands.txt').read_text())
    raise SystemExit(0)
verification = out / 'verification'
verification.mkdir(exist_ok=True)
receipt = verification / (args.stage + '-result.json')
if receipt.exists():
    raise SystemExit('Refusing unchanged rerun: result already exists at ' + str(receipt))
if args.stage in ['core', 'root']:
    group = plan['groups'][args.stage]
    for entry in group['files']:
        source = Path(plan['snapshot']) / entry['path']
        if hashlib.sha256(source.read_bytes()).hexdigest() != entry['sha256']:
            raise SystemExit('Pinned selected source changed: ' + entry['path'])
    command, cwd = group['command'], Path(plan['snapshot'])
else:
    command, cwd = plan['docs_command'], Path(plan['live_docs_root'])
log = verification / (args.stage + '.log')
env = os.environ.copy()
for key in ['NEOANKI_PERF_SCALE', 'NEOANKI_TEST_SCENARIO', 'NEOANKI_CONTEXT_LIVE_EVALUATION', 'NEOANKI_CONTEXT_GENERATION_DIAGNOSTICS']:
    env.pop(key, None)
temporary = verification / ('tmp-' + args.stage)
temporary.mkdir(exist_ok=True)
env['TMPDIR'] = str(temporary) + '/'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
monotonic_start = time.monotonic()
print('Running ' + args.stage + ': ' + shlex.join(command), flush=True)
with log.open('wb') as stream:
    process = subprocess.run(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT, check=False)
text = log.read_text(errors='replace')
result = {
    'stage': args.stage, 'command': command, 'cwd': str(cwd), 'source_basis': 'pinned snapshot' if args.stage != 'docs' else 'live current workspace',
    'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_seconds_not_a_benchmark': time.monotonic() - monotonic_start, 'exit_code': process.returncode,
    'log': str(log), 'declared_selected_tests': plan['groups'][args.stage]['declared_test_count'] if args.stage != 'docs' else None,
    'swift_testing_summaries': re.findall(r'.*Test run with.*', text),
    'xctest_summaries': re.findall(r'.*Executed \d+ tests?.*', text),
    'issues_or_errors': [line for line in text.splitlines() if 'error:' in line or 'failed after' in line or 'Issue recorded' in line],
    'rerun_policy': 'No unchanged failed command rerun; preserve original result and diagnose separately.'
}
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
raise SystemExit(process.returncode)
