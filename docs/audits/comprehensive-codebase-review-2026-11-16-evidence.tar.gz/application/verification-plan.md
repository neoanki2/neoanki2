# Focused baseline verification and future acceptance

This is additional evidence planning; the completed investigation report and its original evidence are not rewritten. Commands are authorized by the coordinator, but must wait until the core investigator explicitly releases the timing window. No build/test was executed while preparing this plan. No product or pinned-snapshot file is modified.

## Exact source and command basis

`verification-selection.json` records every selected source path/hash, @Test function, module and exact regex/argument vector. `verification-commands.txt` records shell-equivalent commands; `core-verification-filter.txt` and `root-verification-filter.txt` preserve the regex independently. Source basis is the coordinator-pinned `snapshot/`, base commit `5baf3fe4810512ea9e00babba2f3ae6fbfe67c3f` plus the uncommitted edits recorded in `snapshot-manifest.json`.

The snapshot has no `.git` directory. It sits inside the live repository, so a Git command run there would discover the outer checkout; no selected test invokes Git, and this verification does not infer source state from that ancestor. Swift packages use only local path dependencies. Fixture tests derive paths from `#filePath`, resolving to the pinned fixture/doc tree. The copied test-fast.sh is executable, but deliberately not used: it also runs unrelated release, signing, sync, API and UI-infrastructure contracts. No `xcodebuild`, app launch, Simulator, screenshot, network service, or phone interaction is planned.

Run sequentially, after release of the performance window:

1. `python3 .build/fresh-codebase-review-2026-11-16-5baf3fe/application/run-verification.py core`
2. `python3 .build/fresh-codebase-review-2026-11-16-5baf3fe/application/run-verification.py root`
3. Near completion, `python3 .build/fresh-codebase-review-2026-11-16-5baf3fe/application/run-verification.py docs`

The first two invoke supported `swift test --package-path ... --scratch-path ... --parallel --num-workers 2 --filter ...` commands with separate `application/verification/core` and `root` outputs. The root filter controls execution, not compilation: SwiftPM may compile the root target/test graph including native SwiftUI/AppKit sources, but no application/window is launched. This limitation was explicitly disclosed to and approved by the coordinator. No reduced test shim is substituted for the real application modules.

The docs stage invokes exactly `swift Scripts/validate-docs.swift` in the live workspace, as authorized. Default validation does not request screenshot capture/freshness or a Git base-ref comparison. Live concurrent documentation edits may affect that result, so it is labeled separately from snapshot tests. Failures are preserved and reported without product fixes or an unchanged rerun.

The runner writes stage command, source basis, exit status, raw log, selected declaration count, observed Swift Testing/XCTest summaries and issue/error lines. Actual cases may exceed declaration counts because of parameterization. It refuses a stage if its result receipt already exists, preventing accidental unchanged reruns. It isolates disposable runtime fixtures using a task-owned TMPDIR; build/test duration is explicitly not treated as a performance benchmark.

## Current baseline selected

| Layer | Source test files / reason | Declared @Test count |
| --- | --- | ---: |
| Core bounded selection | StudyEligibilityQueryPlanTests, StudySpacingTests, StudyQueueOrderingTests, RelatedQueueOrderingTests, ScopeSummaryTests, DueCardHydrationTests, StudySessionTests | 41 |
| Core typed-creation invariants | AuthoredDeckTests, DeckScopedItemTypeTests, CardReconciliationFlowTests | 37 |
| Native generators | All PoemDeckBuilderTests and ProseDeckBuilderTests | 27 |
| Application builder hosts | DeckBuilderIntegrationTests (actual two-builder registry, generation/import/model refresh, owned workspace cleanup) | 3 |
| Native command/read contracts | NativeLibraryWorkflowTests (receipt recovery, lazy demand, maturity degradation, publication warning) | 5 |
| Shared study session | StudySessionContractTests, StudyRepairFeatureTests, ContextReviewOrderingRegressionTests | 48 |
| Total | 78 Core + 83 root definitions | 161 |

This baseline can establish that the pinned source passes its current contracts. It does not prove a future implementation, show a speedup, or imply the new bounded-new-head plan is already covered. In particular, current plan tests assert learned partial indexes and family inner indexes but do not forbid a temporary sort for the unrestricted new-card head.

## Future typed poem/prose creation acceptance (design only)

1. **Differential creation, with identity normalization.** For fixed multilingual poem/prose fixtures (repeated lines/phrases, accent/grapheme text, poem stanza breaks, prose paragraph separators and manual unit boundaries), create through the existing generated-file importer and the proposed typed plan in separate disposable databases. Compare rendered prompt/answer/attribution, field definitions/templates/layout/reveal/skill, tags, included type policies, item/card counts, source order and due order. Normalize only newly allocated IDs/timestamps in the comparison; retain reference-graph equality. This catches semantic drift rather than mirroring a new constructor.
2. **Schema reuse and destination policy.** Repeat equivalent creation into destinations with inherited/overridden policies and equivalent preexisting custom item types with different field UUIDs. Assert schema-digest reuse plus correct ordinal field remapping, contextual included ownership, no leaked globally available type, and no changed destination settings. Keep the existing contextual-type/reuse tests; add direct typed-path equivalence.
3. **Atomic destination validation (explicit behavior correction).** Hold between prepare/commit, delete/move/change the selected parent through a second connection, then commit. Either commit the authorized complete parent/deck/type/items/media/receipt state or reject without partial new root. Assert the defined stale-parent result. Today's separate import+parent update can leave top-level data; do not disguise this correction as unchanged behavior.
4. **Failure and ambiguous success.** Inject failure before transaction commit and after commit/before read/publication. Verify precommit rollback includes ownership/media/receipt; after commit, recreate the application adapter and retry the same command identity, recovering the original result with one deck/import and unchanged card identities. Same command/different payload must be rejected. Injecting only a generic thrown error before the write is insufficient.
5. **History and edits stay protected.** Run existing atomic poem/prose reconciliation/history tests against created results; retain exact stale expected-content checks, opening/stanza/paragraph behavior, card IDs/memory/reviews and spoken response deletion authorization. The existing reconcilers are already typed and should remain the canonical edit semantics.
6. **Compatibility exporter is genuinely on demand.** Public GeneratedDeckBundle/workspace APIs still produce the current authored format and owned cleanup behavior when explicitly called. Ordinary typed creation is checked with a counting workspace/filesystem provider to perform zero generated-package writes/parses; this is an operation-count assertion, not a timing threshold. A shared canonical writer replaces the two private wire-shape families. Keep hostile external authored tests unchanged: traversal, duplicate keys, symlinks, source limits, required fields and media integrity remain protected.

## Future bounded study-head acceptance (design only)

1. **Head equals exact complete-queue prefix.** Fixed-clock differential tests compare `fetchDueCards(limit: 1)` and several small limits to the complete canonical queue for independent cards, context families spanning decks/batches, mixed poem/prose works, and mixed learned/new phases. Include equal due dates with UUID ties and more than one related work. Work-containing cases retain the current complete work-order route unless an independently equivalent bounded design is proved.
2. **Eligibility is unchanged.** Matrix all/unassigned/deck with and without descendants; unlimited, zero, one and nested ancestor/child daily limits; family representative inside selected scope; learned relatives/exposure outside it; suspended/future cards; reviews and reverted introductions; corrupt/missing templates and edited content relations. Compare counts and selected IDs, not only expected length. Keep the randomized single-limiter-vs-general fallback tests and one-read-snapshot mutation test.
3. **Bounded execution is structurally asserted.** On populated 100/1k/25k/100k independent-new-card fixtures, verify ordered active-new partial index use and no temporary ordering B-tree for the eligible no-limiter new-head route. Preserve existing family-first inner index assertions. Prove no-work existence begins from work relations instead of scanning every due card. EXPLAIN assertions should cover meaningful operators/index families, not a fragile full text string.
4. **Inspected-work counters, not timing-only unit tests.** Use SQLite VM/progress/scan-status instrumentation where available to record statement steps/rows for head selection and work existence. A narrow successful first head should have roughly bounded inspected work as unrelated independent cards grow; an intentionally difficult ineligible prefix may legitimately inspect more. Keep limits and predicate selectivity explicit. Reject a “fast” raw-card LIMIT that postpones family or quota filtering until after slicing.
5. **Progressive feature and mutation safety.** Retain first-card-readability versus queue-preparation controls, exact remaining count, shared captured clock, restart supersession, corrupt-type atomic fallback, failed remainder behavior, grade/undo/repair ordering and next-new eligibility checks. A lower SQL cost must not make a stale first head appear gradeable before the full session contract allows it.
6. **Performance measurement remains separate.** Run release-built production ItemStore/feature paths after correctness, with cold/warm states and realistic scopes/history. Record end-to-end first-ready and first-gradeable timings in addition to isolated statement times, original logs and process overlap. Do not apply SQL-only prototype speedups to full study startup or total app responsiveness.
