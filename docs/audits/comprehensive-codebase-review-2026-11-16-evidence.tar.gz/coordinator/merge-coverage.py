#!/usr/bin/env python3
import csv,json,collections
from pathlib import Path
root=Path(__file__).resolve().parent.parent
base=list(csv.DictReader((root/'coverage.tsv').open(),delimiter='\t'))
notes=collections.defaultdict(list)
inputs=[('core',root/'core/inventory.tsv'),('application',root/'application/inventory.tsv'),('application',root/'application/cross-boundary-inventory.tsv'),('integrations',root/'integrations/file-coverage.tsv')]
for owner,path in inputs:
 if not path.exists():continue
 for r in csv.DictReader(path.open(),delimiter='\t'):
  depth=r.get('inspection_depth',r.get('inspection','inventory'))
  detail=r.get('detail',r.get('notes',''))
  if r.get('semantic_slices'):detail+='; slices: '+r['semantic_slices']
  notes[r['path']].append((owner,depth,detail))
for row in base:
 entries=notes[row['path']]
 row['agent_inspection']=' | '.join(f'{owner}: {depth}' for owner,depth,detail in entries)
 row['agent_details']=' | '.join(f'{owner}: {detail}' for owner,depth,detail in entries if detail)
 row['semantic_or_focused']='yes' if any(any(k in depth.lower() for k in ['deep','semantic','focused','complete current design']) for _,depth,_ in entries) else 'no'
with (root/'coverage.tsv').open('w') as out:
 w=csv.DictWriter(out,fieldnames=list(base[0]),delimiter='\t');w.writeheader();w.writerows(base)
summary={'snapshot_files':len(base),'files_with_agent_inspection':sum(bool(r['agent_inspection']) for r in base),'files_with_semantic_or_focused_inspection':sum(r['semantic_or_focused']=='yes' for r in base),'by_classification':dict(collections.Counter(r['classification'] for r in base)),'note':'Each source has structural scan, with selective semantic/focused upgrades recorded as exact agent scope; not a claim of full line review.'}
(root/'coverage-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
