#!/usr/bin/env python3
"""Verify frozen investigation inputs, separately reporting concurrent live edits."""
import hashlib, json
from pathlib import Path
here = Path(__file__).resolve().parent.parent
repo = here.parent.parent
manifest = json.loads((here / 'snapshot-manifest.json').read_text())
invalid = []
live_drift = []
for record in manifest['files']:
    name = record['path']
    frozen = here / 'snapshot' / name
    if not frozen.is_file() or hashlib.sha256(frozen.read_bytes()).hexdigest() != record['sha256']:
        invalid.append(name)
    current = repo / name
    if not current.is_file() or hashlib.sha256(current.read_bytes()).hexdigest() != record['sha256']:
        live_drift.append(name)
result = {'snapshot_files_checked': len(manifest['files']), 'invalid_snapshot_files': invalid,
          'live_drift_after_snapshot': live_drift, 'snapshot_passed': not invalid,
          'note': 'Concurrent live edits are preserved, not attributed to the investigation. Findings cite the frozen snapshot.'}
(here / 'source-integrity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
raise SystemExit(bool(invalid))
