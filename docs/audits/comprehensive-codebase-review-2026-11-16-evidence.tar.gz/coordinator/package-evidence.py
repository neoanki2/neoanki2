#!/usr/bin/env python3
"""Package source, logs and analysis, excluding synthetic DBs and build products."""
from pathlib import Path
import hashlib, json, tarfile
root=Path(__file__).resolve().parent.parent
repo=root.parent.parent
output=repo/'docs/audits/comprehensive-codebase-review-2026-11-16-evidence.tar.gz'
allowed={'.md','.tsv','.json','.jsonl','.ndjson','.csv','.log','.txt','.swift','.py','.sh','.yml','.yaml','.toml'}
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if rel.name=='archive-manifest.json':continue
 if rel.parts[:2]==('application','verification') and len(rel.parts)>2 and (rel.parts[2] in {'core','root'} or rel.parts[2].startswith('tmp-')):continue
 if any(part in {'.build','__pycache__','.swiftpm','core.dSYM'} for part in rel.parts):continue
 if rel.parts[0]=='snapshot' or p.suffix in allowed or p.name in {'core-verification-filter.txt','root-verification-filter.txt'}:
  files.append(p)
files.sort()
manifest=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest_file=root/'archive-manifest.json';manifest_file.write_text(json.dumps(manifest,indent=2)+'\n')
output.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(output,'w:gz',compresslevel=6) as tar:
 for p in files+[manifest_file]:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
print(json.dumps({'path':str(output),'files':len(files)+1,'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
