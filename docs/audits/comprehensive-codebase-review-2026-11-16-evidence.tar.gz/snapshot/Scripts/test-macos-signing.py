#!/usr/bin/env python3
"""Release regressions: production capability validation and cleanup on failure."""
import datetime as dt
import contextlib
import importlib.util
from pathlib import Path
import plistlib
import shutil
import struct
import subprocess
import tempfile
import types
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('mac_signing', Path(__file__).with_name('sign-macos-app.py'))
signing = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(signing)


def profile():
    return {
        'ExpirationDate': dt.datetime(2040, 1, 1),
        'TeamIdentifier': ['TEAM123'], 'ProvisionsAllDevices': True, 'Platform': ['OSX'],
        'DeveloperCertificates': [b'certificate'],
        'Entitlements': {
            'com.apple.application-identifier': 'TEAM123.com.neoanki2.app',
            'com.apple.developer.team-identifier': 'TEAM123',
            'com.apple.developer.icloud-container-identifiers': [signing.CONTAINER],
            'com.apple.developer.icloud-services': '*',
            'com.apple.developer.icloud-container-environment': 'Production',
            'com.apple.developer.aps-environment': 'production',
            'com.apple.developer.ubiquity-kvstore-identifier': 'TEAM123.*',
        },
    }


class SigningTests(unittest.TestCase):
    def test_installer_signing_arguments_support_bash_three_empty_arrays(self):
        source = (signing.ROOT / 'Scripts/install-app.sh').read_text()
        start = source.index('SIGNING_ARGUMENTS=()')
        end = source.index('if [ ! -d "$DEST_DIR" ]', start)
        preflight = source[start:end]
        invocation = next(line for line in source.splitlines()
                          if 'python3' in line and '"$STAGE"' in line)
        for notarize, expected in [('1', ['--check', '/fixture/app']),
                                   ('0', ['--check', '--sign-only', '--sign-only', '/fixture/app'])]:
            with self.subTest(notarize=notarize):
                script = ('ROOT=/fixture\nSTAGE=/fixture/app\nSIGNED=1\n'
                          f'NOTARIZE={notarize}\n'
                          'python3() { shift; printf "%s\\n" "$@"; }\n'
                          + preflight + invocation)
                result = subprocess.run(['/bin/bash', '-euc', script],
                                        capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stdout.splitlines(), expected)

    def test_accepts_real_profile_and_expands_signed_entitlements(self):
        p = profile()
        team = signing.validate_profile(p, b'certificate')
        e = signing.entitlements_for(team)
        signing.validate_entitlements(e, team)
        self.assertEqual(e['com.apple.developer.ubiquity-kvstore-identifier'], 'TEAM123.com.neoanki2.app')
        self.assertNotIn('$(TeamIdentifierPrefix)', plistlib.dumps(e).decode())

    def test_rejects_expired_wrong_team_bundle_certificate_or_distribution(self):
        changes = [('ExpirationDate', dt.datetime(2000, 1, 1)), ('TeamIdentifier', []),
                   ('ProvisionsAllDevices', False), ('Platform', ['iOS']),
                   ('DeveloperCertificates', [b'other'])]
        for key, value in changes:
            with self.subTest(key=key):
                p = profile()
                p[key] = value
                with self.assertRaises(signing.SigningError):
                    signing.validate_profile(p, b'certificate')
        for key, value in [('com.apple.application-identifier', 'TEAM123.other'),
                           ('com.apple.developer.team-identifier', 'OTHER'),
                           ('get-task-allow', True)]:
            with self.subTest(key=key):
                p = profile()
                p['Entitlements'][key] = value
                with self.assertRaises(signing.SigningError):
                    signing.validate_profile(p)

    def test_requires_every_production_cloud_capability(self):
        for key in ('com.apple.developer.icloud-container-identifiers',
                    'com.apple.developer.icloud-services',
                    'com.apple.developer.icloud-container-environment',
                    'com.apple.developer.aps-environment',
                    'com.apple.developer.ubiquity-kvstore-identifier'):
            with self.subTest(key=key):
                p = profile()
                del p['Entitlements'][key]
                with self.assertRaises(signing.SigningError):
                    signing.validate_profile(p)
        p = profile()
        p['Entitlements']['com.apple.developer.icloud-container-environment'] = 'Development'
        with self.assertRaises(signing.SigningError):
            signing.validate_profile(p)

    def test_signed_entitlements_cannot_enable_debugger(self):
        e = signing.entitlements_for('TEAM123')
        e['com.apple.security.get-task-allow'] = True
        with self.assertRaises(signing.SigningError):
            signing.validate_entitlements(e, 'TEAM123')

    def test_keychain_cleanup_preserves_concurrent_search_list_on_failure(self):
        calls = []
        keychain = None
        search_list = ['login']

        def run(args, timeout=60):
            nonlocal keychain
            calls.append(args)
            if args[:2] == ['openssl', 'pkcs12']:
                Path(args[args.index('-out') + 1]).touch()
            if args[:2] == ['security', 'create-keychain']:
                keychain = args[-1]
            if args[:2] == ['security', 'list-keychains']:
                if '-s' in args:
                    search_list[:] = args[args.index('-s') + 1:]
                else:
                    return '\n'.join(f'"{path}"' for path in search_list).encode()
            return b''

        with patch.object(signing, 'run', run):
            with self.assertRaisesRegex(RuntimeError, 'fixture'):
                with signing.signing_keychain(types.SimpleNamespace(directory=Path('/fixture'))):
                    self.assertEqual(search_list, ['login', keychain])
                    self.assertIn(['security', 'verify-cert', '-c',
                        '/fixture/Developer-ID-Application.cert.pem', '-p', 'codeSign', '-L'], calls)
                    search_list.append('concurrent')
                    raise RuntimeError('fixture')
        self.assertIn(['security', 'delete-keychain', keychain], calls)
        self.assertIn(['security', 'list-keychains', '-d', 'user', '-s', 'login', 'concurrent'], calls)
        self.assertEqual(search_list, ['login', 'concurrent'])
        self.assertFalse(any('NeoAnki2-signing.keychain-db' in arg for args in calls for arg in args))

    def test_search_list_aliases_do_not_duplicate_or_survive_cleanup(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            real = root / 'real'; real.mkdir()
            alias = root / 'alias'; alias.symlink_to(real)
            keychain = real / 'signing.keychain-db'; keychain.touch()
            search = ['login', str(alias / keychain.name), 'concurrent']
            writes = []
            def run(args):
                if '-s' in args:
                    writes.append(args)
                    search[:] = args[args.index('-s') + 1:]
                return '\n'.join('"' + p + '"' for p in search).encode()
            signing.keychain_support.register(run, keychain)
            self.assertFalse(writes)
            signing.keychain_support.unregister(run, keychain)
            self.assertEqual(search, ['login', 'concurrent'])

    def test_identity_preflight_requires_the_expected_valid_identity(self):
        material = types.SimpleNamespace(identity='A' * 40)
        for available in [True, False]:
            with self.subTest(available=available):
                identities = (f'1) {material.identity} "Developer ID Application: Fixture"' if available
                              else '0 valid identities found').encode()
                keychain = contextlib.nullcontext((Path('/fixture/signing.keychain-db'), None))
                with patch.object(signing, 'signing_keychain', return_value=keychain), \
                     patch.object(signing, 'run', return_value=identities):
                    if available:
                        signing.check_identity(material)
                    else:
                        with self.assertRaisesRegex(signing.SigningError, 'not available'):
                            signing.check_identity(material)

    def test_rejected_notarization_cannot_staple_or_verify(self):
        calls = []
        def run(args, timeout=60):
            calls.append(args)
            if args[:2] == ['openssl', 'pkcs12']:
                Path(args[args.index('-out') + 1]).touch()
            if args[:3] == ['xcrun', 'notarytool', 'submit']:
                return b'{"id":"fixture-id","status":"Invalid"}'
            return b''
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            app = base / 'NeoAnki2.app'
            (app / 'Contents').mkdir(parents=True)
            (base / 'Mac-DeveloperID.provisionprofile').write_bytes(b'fixture')
            material = types.SimpleNamespace(directory=base, team='TEAM123', profile=profile(),
                                             identity='fixture-identity', notary_args=[])
            with patch.object(signing, 'run', run), patch.object(signing, 'verify') as verify:
                with self.assertRaises(signing.SigningError):
                    signing.sign(app, material)
                verify.assert_not_called()
            self.assertTrue((base / 'notarization.json').exists())
        self.assertFalse(any(args[:3] == ['xcrun', 'stapler', 'staple'] for args in calls))
        self.assertTrue(any(args[:3] == ['xcrun', 'notarytool', 'log'] for args in calls))

    def test_release_cannot_opt_out_or_silently_fallback(self):
        import os
        with tempfile.TemporaryDirectory() as folder:
            env = dict(os.environ, NEOANKI_RELEASE_SIGNED='0', NEOANKI_RELEASE_BUILD_NUMBER='999',
                       NEOANKI_RELEASE_VERSION='1.0.999', NEOANKI_SIGNING_DIR=folder)
            result = subprocess.run([str(signing.ROOT / 'Scripts/build-release-artifact.sh'), folder],
                                    env=env, capture_output=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn(b'require Developer ID', result.stderr)
            env.pop('NEOANKI_RELEASE_SIGNED')
            result = subprocess.run([str(signing.ROOT / 'Scripts/build-release-artifact.sh'), folder],
                                    env=env, capture_output=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn(b'Missing signing material', result.stderr)
            self.assertFalse(list(Path(folder).glob('*.dmg')))

    def test_notarization_timeout_keeps_submission_id_without_accepting_app(self):
        import json
        calls = []
        def run(args, timeout=60):
            calls.append(args)
            if args[:2] == ['openssl', 'pkcs12']:
                Path(args[args.index('-out') + 1]).touch()
            if args[:3] == ['xcrun', 'notarytool', 'submit']:
                return b'{"id":"pending-id","status":"In Progress"}'
            if args[:3] == ['xcrun', 'notarytool', 'wait']:
                raise signing.SigningError('notarization timed out')
            return b''
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            app = base / 'NeoAnki2.app'
            (app / 'Contents').mkdir(parents=True)
            (base / 'Mac-DeveloperID.provisionprofile').write_bytes(b'fixture')
            (base / 'notarization.json').write_text('{"id":"stale","status":"Accepted"}')
            material = types.SimpleNamespace(directory=base, team='TEAM123', profile=profile(),
                                             identity='fixture-identity', notary_args=[])
            with patch.object(signing, 'run', run), patch.object(signing, 'verify') as verify:
                with self.assertRaisesRegex(signing.SigningError, 'timed out'):
                    signing.sign(app, material)
                verify.assert_not_called()
            receipt = json.loads((base / 'notarization.json').read_text())
            self.assertEqual(receipt['id'], 'pending-id')
            self.assertEqual(receipt['status'], 'In Progress')
        self.assertFalse(any(args[:3] == ['xcrun', 'stapler', 'staple'] for args in calls))

    def test_local_signing_does_not_require_notarization_credentials(self):
        def run(args, timeout=60):
            if '-subject' in args:
                return b'subject=Developer ID Application: Fixture (TEAM123)'
            if '-pubkey' in args or '-pubout' in args:
                return b'fixture-public-key'
            if '-outform' in args:
                return b'certificate'
            if args[:2] == ['security', 'cms']:
                return plistlib.dumps(profile())
            return b''
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            for name in ('Developer-ID-Application.cert.pem', 'Developer-ID-Application.key.pem',
                         'DeveloperIDG2CA.cer', 'Mac-DeveloperID.provisionprofile'):
                (directory / name).touch()
            with patch.object(signing, 'run', run):
                material = signing.Material(directory, require_notarization=False)
                self.assertEqual(material.team, 'TEAM123')
                with self.assertRaisesRegex(signing.SigningError, 'Missing notarization'):
                    signing.Material(directory)

    def test_local_source_signing_never_submits_to_apple(self):
        calls = []
        def run(args, timeout=60):
            calls.append(args)
            if args[:2] == ['openssl', 'pkcs12']:
                Path(args[args.index('-out') + 1]).touch()
            return b''
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            app = base / 'NeoAnki2.app'
            (app / 'Contents').mkdir(parents=True)
            (base / 'Mac-DeveloperID.provisionprofile').write_bytes(b'fixture')
            material = types.SimpleNamespace(directory=base, team='TEAM123', identity='fixture-identity')
            with patch.object(signing, 'run', run), patch.object(signing, 'verify') as verify:
                signing.sign(app, material, require_notarization=False)
                verify.assert_called_once_with(app, require_notarization=False)
        self.assertTrue(any(args[0] == 'codesign' and '--options' in args for args in calls))
        self.assertFalse(any(args[0] == 'xcrun' for args in calls))


@unittest.skipUnless(shutil.which('lipo'), 'Apple lipo is required')
class UniversalArchitectureTests(unittest.TestCase):
    def test_universal_gate_requires_both_real_macho_slices(self):
        verifier = Path(__file__).with_name('verify-universal-macos.sh')
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            arm = root / 'arm64'
            intel = root / 'x86_64'
            universal = root / 'universal'
            # Minimal valid Mach-O object headers exercise lipo without compiling
            # or launching an application, and without depending on build output.
            arm.write_bytes(struct.pack('<8I', 0xfeedfacf, 0x0100000c, 0, 1, 0, 0, 0, 0))
            intel.write_bytes(struct.pack('<8I', 0xfeedfacf, 0x01000007, 3, 1, 0, 0, 0, 0))
            subprocess.run(['lipo', '-create', str(arm), str(intel), '-o', str(universal)],
                           check=True, capture_output=True)
            for binary, expected_success in [(universal, True), (arm, False), (intel, False)]:
                with self.subTest(binary=binary.name):
                    result = subprocess.run(['bash', str(verifier), str(binary)], capture_output=True)
                    self.assertEqual(result.returncode == 0, expected_success,
                                     result.stderr.decode(errors='replace'))


if __name__ == '__main__':
    unittest.main()
