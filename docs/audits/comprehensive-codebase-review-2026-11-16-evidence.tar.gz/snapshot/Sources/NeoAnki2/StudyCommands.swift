import NeoAnkiCore
import NeoAnkiSharedUI
import SwiftUI

struct StudyCommandHandlers {
    var startStudy: (() -> Void)?
    var endSession: (() -> Void)?
    var editCurrentCard: (() -> Void)?
    var grade: ((ReviewRating) -> Void)?
    var undoLastGrade: (() -> Void)?
    var canStartStudy = false
    var canEndSession = false
    var canEditCurrentCard = false
    var canGrade = false
    var canUndoLastGrade = false

    func canUseSpace(primaryAction: StudyPrimaryActionHandler?) -> Bool {
        canGrade || (primaryAction?.isEnabled ?? false)
    }

    func useSpace(primaryAction: StudyPrimaryActionHandler?) {
        if canGrade {
            grade?(.good)
        } else {
            primaryAction?.invoke()
        }
    }
}

struct StudyPrimaryActionHandler {
    var action: (() -> Void)?
    var isEnabled = false

    func invoke() {
        guard isEnabled else { return }
        action?()
    }
}

private struct StudyPrimaryActionHandlerKey: FocusedValueKey {
    typealias Value = StudyPrimaryActionHandler
    static var defaultValue: StudyPrimaryActionHandler? { nil }
}

private struct StudyCommandHandlersKey: FocusedValueKey {
    typealias Value = StudyCommandHandlers
    static var defaultValue: StudyCommandHandlers? { nil }
}

extension FocusedValues {
    var studyCommandHandlers: StudyCommandHandlers? {
        get { self[StudyCommandHandlersKey.self] }
        set { self[StudyCommandHandlersKey.self] = newValue }
    }

    var studyPrimaryActionHandler: StudyPrimaryActionHandler? {
        get { self[StudyPrimaryActionHandlerKey.self] }
        set { self[StudyPrimaryActionHandlerKey.self] = newValue }
    }
}

struct StudyCommands: Commands {
    @FocusedValue(\.studyCommandHandlers) private var handlers
    @FocusedValue(\.studyPrimaryActionHandler) private var primaryAction
    @AppStorage(StudyPreferences.usesPassFailGrades) private var usesPassFailGrades = false

    var body: some Commands {
        CommandMenu("Study") {
            Button("Start Study") {
                handlers?.startStudy?()
            }
            .keyboardShortcut("s", modifiers: [.command, .shift])
            .disabled(!(handlers?.canStartStudy ?? false))

            Button("End Session") {
                handlers?.endSession?()
            }
            .disabled(!(handlers?.canEndSession ?? false))

            Divider()

            Button("Edit Card…") {
                handlers?.editCurrentCard?()
            }
            .disabled(!(handlers?.canEditCurrentCard ?? false))

            Divider()

            Button(handlers?.canGrade == true ? "Grade: Good with Space" : "Continue") {
                handlers?.useSpace(primaryAction: primaryAction)
            }
            .disabled(!(handlers?.canUseSpace(primaryAction: primaryAction) ?? false))

            Divider()

            ForEach(gradingMode.choices, id: \.rating) { choice in
                Button("Grade: \(choice.title)") {
                    handlers?.grade?(choice.rating)
                }
                .disabled(!(handlers?.canGrade ?? false))
            }

            Divider()

            Button("Undo Last Grade") {
                handlers?.undoLastGrade?()
            }
            .disabled(!(handlers?.canUndoLastGrade ?? false))
        }
    }

    private var gradingMode: StudyGradingMode {
        StudyGradingMode(usesPassFailGrades: usesPassFailGrades)
    }
}
