import NeoAnkiApplication
import NeoAnkiFeatures
import NeoAnkiSharedUI
import NeoAnkiCore
import NeoAnkiTextEditing
import SwiftUI

struct DeckSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Bindable var decksModel: DecksModel
    let deck: DeckSummary
    let onSaved: () async -> Void
    let onProgressReset: () async -> Void

    @State private var typesRevision = 0
    @State private var typeStudio: ItemTypesFeatureModel?
    @State private var showsTypes = false
    @State private var dismissal = DraftDismissal()
    @State private var isLimited: Bool
    @State private var newCardsPerDay: Int
    @State private var isSaving = false
    @State private var isResetting = false
    @State private var showResetConfirmation = false
    @State private var resetCardCount: Int?

    init(
        decksModel: DecksModel,
        deck: DeckSummary,
        onSaved: @escaping () async -> Void = {},
        onProgressReset: @escaping () async -> Void = {}
    ) {
        self.decksModel = decksModel
        self.deck = deck
        self.onSaved = onSaved
        self.onProgressReset = onProgressReset
        _isLimited = State(initialValue: deck.newCardsPerDay != nil)
        _newCardsPerDay = State(initialValue: deck.newCardsPerDay ?? 20)
    }

    var body: some View {
        NavigationStack {
            Form {
                if let errorMessage = decksModel.errorMessage {
                    ErrorBanner(message: errorMessage)
                }

                if let library = decksModel.library as? any LibraryRepository {
                    Section("Item Types") {
                        Button("Manage Item Types…") { showsTypes = true }
                    }
                    .sheet(isPresented: $showsTypes) {
                        NavigationStack {
                            DeckItemTypesView(library: library, deckID: deck.id, refreshToken: typesRevision, onEdit: { type in
                                if let studioLibrary = library as? any LibraryBrowsing & LibraryItemTypeManaging & LibraryItemTypeEditingSafeguarding & LibraryItemTypeStudioSaving {
                                    let studio = ItemTypesFeatureModel(library: studioLibrary)
                                    studio.destinationDeckID = deck.id
                                    Task { await studio.load(); studio.selectItemType(id: type.id); if !studio.isSelectedItemTypeReadOnly { studio.beginEditingSelectedItemType() }; typeStudio = studio }
                                }
                            }, onChanged: onSaved)
                            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { showsTypes = false } } }
                        }.frame(minWidth: 520, minHeight: 450)
                        .sheet(isPresented: Binding(get: { typeStudio != nil }, set: { if !$0 { typeStudio = nil } }), onDismiss: { typesRevision += 1 }) {
                            if let typeStudio {
                                NavigationStack {
                                    TemplatesView(model: typeStudio, onTemplatesChanged: onSaved)
                                        .toolbar { if typeStudio.studioDraft == nil { ToolbarItem(placement: .cancellationAction) { Button("Done") { self.typeStudio = nil } } } }
                                }
                                .interactiveDismissDisabled(typeStudio.studioDraft != nil)
                                .frame(minWidth: 900, minHeight: 650)
                            }
                        }
                    }
                }
                Section {
                    Toggle("Limit new cards per day", isOn: $isLimited)

                    if isLimited {
                        Stepper(
                            "New cards per day: \(newCardsPerDay)",
                            value: $newCardsPerDay,
                            in: 0 ... 9_999
                        )
                        .monospacedDigit()
                        .accessibilityIdentifier("deckNewCardsPerDay")
                    }
                } header: {
                    Text("New Cards")
                } footer: {
                    Text(
                        isLimited
                            ? "Shared by this deck and all its subdecks. A limit of 0 pauses new cards; reviews and learning cards are never limited."
                            : "This deck does not add a limit for its subtree."
                    )
                }

                Section {
                    Button(
                        isResetting ? "Resetting Progress…" : "Reset All Progress…",
                        role: .destructive
                    ) {
                        showResetConfirmation = true
                    }
                    .disabled(isSaving || isResetting)
                    .accessibilityIdentifier("resetDeckProgress")

                    if let resetCardCount {
                        Label(
                            resetCardCount == 1
                                ? "Progress reset for 1 card."
                                : "Progress reset for \(resetCardCount) cards.",
                            systemImage: "checkmark.circle.fill"
                        )
                        .foregroundStyle(.green)
                        .accessibilityIdentifier("deckProgressResetSuccess")
                    }
                } header: {
                    Text("Progress")
                } footer: {
                    Text("Returns every card in this deck and its subdecks to New. Items, deck settings, and suspended cards are kept.")
                }
            }
            .formStyle(.grouped)
            .disabled(isSaving || isResetting)
            .navigationTitle(deck.name)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismissal.request(isDirty: pendingLimit != deck.newCardsPerDay, isBusy: isSaving || isResetting) { dismiss() }
                    }
                        .disabled(isSaving || isResetting)
                        .keyboardShortcut(.cancelAction)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isSaving ? "Saving…" : "Save") {
                        save()
                    }
                    .keyboardShortcut(.defaultAction)
                    .disabled(isSaving || isResetting)
                    .accessibilityIdentifier("saveDeckSettings")
                }
            }
        }
        .protectDraft(isDirty: pendingLimit != deck.newCardsPerDay, isBusy: isSaving || isResetting, dismissal: dismissal)
        .confirmationDialog(
            "Reset all progress for \"\(deck.name)\"?",
            isPresented: $showResetConfirmation,
            titleVisibility: .visible
        ) {
            Button("Reset All Progress", role: .destructive) {
                resetProgress()
            }
            .accessibilityIdentifier("confirmResetDeckProgress")
            Button("Cancel", role: .cancel) {}
                .accessibilityIdentifier("cancelResetDeckProgress")
        } message: {
            Text("This permanently removes review history for this deck and all its subdecks. This cannot be undone.")
        }
        .frame(minWidth: 420, idealWidth: 420, minHeight: 340)
    }

    private var pendingLimit: Int? { isLimited ? newCardsPerDay : nil }

    private func save() {
        guard !isSaving, !isResetting else { return }
        isSaving = true
        Task {
            let saved = await decksModel.updateNewCardsPerDay(
                id: deck.id,
                limit: isLimited ? newCardsPerDay : nil
            )
            if saved {
                await onSaved()
                dismiss()
            }
            isSaving = false
        }
    }

    private func resetProgress() {
        guard !isResetting, !isSaving else { return }
        isResetting = true
        resetCardCount = nil
        Task {
            if let count = await decksModel.resetProgress(id: deck.id) {
                await onProgressReset()
                resetCardCount = count
            }
            isResetting = false
        }
    }
}
