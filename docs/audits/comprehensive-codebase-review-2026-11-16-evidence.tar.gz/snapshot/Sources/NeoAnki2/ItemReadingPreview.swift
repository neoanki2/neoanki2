import NeoAnkiCore
import NeoAnkiSharedUI
import PoemDeckBuilder
import ProseDeckBuilder
import SwiftUI

/// Renders item field content in the study reading column typography.
struct ItemReadingPreview: View {
    let item: Item
    let itemType: ItemType
    var mediaStore: MediaStore?

    private var displayFields: [(FieldDef, ContentValue)] {
        itemType.fields.compactMap { field in
            guard let value = item.value(for: field.id), !value.isEmpty else { return nil }
            return (field, value)
        }
    }

    var body: some View {
        VStack(spacing: DesignSystem.Spacing.lg) {
            ForEach(Array(displayFields.enumerated()), id: \.offset) { index, fieldPair in
                if index == 1 {
                    Divider()
                }

                VStack(spacing: DesignSystem.Spacing.rowTight) {
                    if index >= 2 {
                        Text(fieldPair.0.name)
                            .font(DesignSystem.Typography.uiHint)
                            .foregroundStyle(.tertiary)
                    }

                    ContentValueView(
                        value: fieldPair.1,
                        isAnswerRevealed: true,
                        richTextPointSize: pointSize(for: index),
                        mediaStore: mediaStore
                    )
                        .font(font(for: index))
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                }
            }
        }
    }

    private func font(for index: Int) -> Font {
        switch index {
        case 0: DesignSystem.Typography.cardPrompt
        case 1: DesignSystem.Typography.cardAnswer
        default: DesignSystem.Typography.uiBody
        }
    }

    private func pointSize(for index: Int) -> CGFloat {
        switch index {
        case 0: DesignSystem.Typography.cardPromptPointSize
        case 1: DesignSystem.Typography.cardAnswerPointSize
        default: DesignSystem.Typography.richTextPointSize
        }
    }
}

struct ItemDetailView: View {
    @Bindable var model: ItemsModel
    @Bindable var decksModel: DecksModel
    let scope: StudyScope
    let summary: SavedItemSummary
    var onBack: () -> Void = {}
    var onDeleted: () -> Void = {}
    /// Editing an item can add or retire cards, so the counts outside this pane
    /// need to hear about a save.
    var onSaved: () -> Void = {}

    @State private var item: Item?
    @State private var itemType: ItemType?
    @State private var cardMaturityDetails: [CardMaturityDetail] = []
    @State private var maturityIssue: String?
    @State private var selectedDeckID: UUID?
    @State private var isLoading = true
    @State private var isDeleting = false
    @State private var isMovingDeck = false
    @State private var isEditing = false
    @State private var showDeleteConfirm = false
    @State private var affectedResponseCount = 0
    @State private var errorMessage: String?

    var body: some View {
        Group {
            if isLoading {
                VStack(spacing: DesignSystem.Spacing.sm) {
                    ProgressView()
                    Text("Loading item…")
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Loading item")
            } else if let item, let itemType {
                ScrollView {
                    VStack(spacing: DesignSystem.Spacing.lg) {
                        ItemReadingPreview(
                            item: item,
                            itemType: itemType,
                            mediaStore: model.mediaStore
                        )

                        if !decksModel.summaries.isEmpty {
                            Picker("Deck", selection: $selectedDeckID) {
                                Text("Unassigned").tag(UUID?.none)
                                ForEach(decksModel.summaries) { deck in
                                    Text(deck.name).tag(Optional(deck.id))
                                }
                            }
                            .labelsHidden()
                            .pickerStyle(.menu)
                            .frame(maxWidth: .infinity)
                            .accessibilityLabel("Deck")
                            .accessibilityIdentifier("itemDeckPicker")
                            .onChange(of: selectedDeckID) { oldValue, newValue in
                                guard oldValue != newValue, !isLoading else { return }
                                Task { await moveDeck(to: newValue) }
                            }
                        }

                        Text("\(summary.cardCount) cards · \(summary.itemTypeName)")
                            .font(DesignSystem.Typography.uiCaption)
                            .foregroundStyle(.tertiary)
                            .frame(maxWidth: .infinity)

                        if let maturityIssue { Text(maturityIssue).foregroundStyle(.secondary) }
                        if !cardMaturityDetails.isEmpty {
                            VStack(alignment: .leading, spacing: DesignSystem.Spacing.xs) {
                                Text("Card maturity")
                                    .font(DesignSystem.Typography.uiCaption)
                                    .foregroundStyle(.secondary)
                                ForEach(cardMaturityDetails) { detail in
                                    HStack {
                                        Text(cardMaturityName(detail, itemType: itemType))
                                        Spacer()
                                        Text(detail.status.displayName)
                                            .foregroundStyle(.secondary)
                                    }
                                    .font(DesignSystem.Typography.uiCaption)
                                }
                            }
                            .accessibilityIdentifier("itemCardMaturity")
                        }
                    }
                    .readingColumnLayout()
                }
            } else {
                ContentUnavailableView {
                    Label("Couldn't Load Item", systemImage: "exclamationmark.triangle")
                } description: {
                    Text(errorMessage ?? "This item may have been removed.")
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(DesignSystem.detailBackground)
        .navigationTitle(summary.title)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Back", systemImage: "chevron.left") {
                    onBack()
                }
                .keyboardShortcut(.cancelAction)
                .accessibilityIdentifier("itemDetailBack")
            }
            if item != nil, !isLoading {
                ToolbarItem {
                    Button("Edit", systemImage: "pencil") {
                        isEditing = true
                    }
                    .accessibilityIdentifier("editItem")
                }
                ToolbarItem(placement: .destructiveAction) {
                    Button("Delete", systemImage: "trash", role: .destructive) {
                        Task {
                            affectedResponseCount = await model.studyResponseCount(
                                itemIDs: [summary.id]
                            )
                            showDeleteConfirm = true
                        }
                    }
                    .disabled(isDeleting)
                    .accessibilityIdentifier("deleteItem")
                }
            }
        }
        .sheet(isPresented: $isEditing) {
            if let item, let itemType {
                if itemType.name == "Poem Line",
                   let deckID = item.deckID,
                   let deckName = decksModel.summaries.first(where: { $0.id == deckID })?.name {
                    PoemDeckEditorView(
                        library: model.library,
                        deckID: deckID,
                        itemTypeID: itemType.id,
                        deckName: deckName,
                        onSaved: {
                            isEditing = false
                            Task {
                                await load()
                                onSaved()
                            }
                        },
                        onCancel: { isEditing = false }
                    )
                } else if itemType.name == "Prose Unit",
                          let deckID = item.deckID,
                          let deckName = decksModel.summaries.first(where: { $0.id == deckID })?.name {
                    ProseDeckEditorView(
                        library: model.library,
                        deckID: deckID,
                        itemTypeID: itemType.id,
                        deckName: deckName,
                        onSaved: {
                            isEditing = false
                            Task {
                                await load()
                                onSaved()
                            }
                        },
                        onCancel: { isEditing = false }
                    )
                } else {
                    NavigationStack {
                        AddItemView(
                            model: model,
                            decksModel: decksModel,
                            editingItem: item,
                            editingItemType: itemType
                        ) {
                            isEditing = false
                            Task {
                                await load()
                                onSaved()
                            }
                        }
                    }
                }
            }
        }
        .confirmationDialog(
            "Delete \"\(summary.title)\"?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("Delete Item", role: .destructive) {
                Task { await deleteItem() }
            }
            .accessibilityIdentifier("confirmDeleteItem")
            Button("Cancel", role: .cancel) {}
                .accessibilityIdentifier("cancelDeleteItem")
        } message: {
            if affectedResponseCount > 0 {
                Text("This removes the item, its \(summary.cardCount) study cards, and \(affectedResponseCount) saved spoken \(affectedResponseCount == 1 ? "response" : "responses"). This can't be undone.")
            } else {
                Text(
                    "This removes the item and its \(summary.cardCount) study cards. This can't be undone."
                )
            }
        }
        .task(id: summary.id) {
            await load()
        }
    }

    @MainActor
    private func load() async {
        isLoading = true
        errorMessage = nil

        do {
            if let loaded = try await model.library.item(id: summary.id) {
                item = loaded.item
                itemType = loaded.itemType
                do {
                    cardMaturityDetails = try await model.library.cardMaturityDetails(itemID: summary.id)
                    maturityIssue = nil
                } catch { maturityIssue = "Maturity is unavailable. " + error.localizedDescription }
                selectedDeckID = loaded.item.deckID
            } else {
                cardMaturityDetails = []
                errorMessage = "This item could not be found."
            }
        } catch {
            errorMessage = UserFacingError.message(from: error)
        }

        isLoading = false
    }

    private func cardMaturityName(_ detail: CardMaturityDetail, itemType: ItemType) -> String {
        let setup = itemType.templates.first(where: { $0.id == detail.templateID })?.name ?? "Card"
        if let group = detail.occlusionGroup { return "\(setup) · region group \(group)" }
        if let group = detail.clozeGroup { return "\(setup) · blank \(group)" }
        return setup
    }

    @MainActor
    private func moveDeck(to deckID: UUID?) async {
        guard !isMovingDeck else { return }
        isMovingDeck = true
        defer { isMovingDeck = false }

        let now = Date.now
        if await model.moveItem(id: summary.id, to: deckID, scope: scope, asOf: now) {
            item?.deckID = deckID
            await decksModel.refreshCounts(asOf: now)
        } else {
            selectedDeckID = item?.deckID
        }
    }

    @MainActor
    private func deleteItem() async {
        isDeleting = true
        defer { isDeleting = false }

        if await model.deleteItem(id: summary.id, scope: scope) {
            onDeleted()
        }
    }
}
