import NeoAnkiCore
import NeoAnkiApplication
import NeoAnkiSharedUI
import PoemDeckBuilder
import ProseDeckBuilder
import NeoAnkiTextEditing
import SwiftUI

struct StudyView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage(StudyPreferences.usesPassFailGrades) private var usesPassFailGrades = false
    @Bindable var model: StudyModel
    @Bindable var itemsModel: ItemsModel
    @Bindable var decksModel: DecksModel
    let scope: StudyScope
    let mediaStore: MediaStore?
    @Binding var endSessionTrigger: Bool
    /// Owned by the host so the Study menu can open the editor, and so the
    /// unmodified grade shortcuts stay disabled while it is open.
    @Binding var isEditingCard: Bool
    let onEndSession: () -> Void

    @FocusState private var typedAnswerFocused: Bool
    @State private var showGradeGuide = false
    @State private var showDeleteDraftConfirm = false
    @State private var recording = StudyRecordingController()
    @AccessibilityFocusState private var answerAccessibilityFocused: Bool
    @AccessibilityFocusState private var recordingErrorAccessibilityFocused: Bool

    var body: some View {
        studyContent.modifier(StudyLearningTimeModifier(
            tracker: model.learningTime,
            isEditing: isEditingCard,
            recordingActive: recording.state == .recording || recording.state == .playing
        ))
    }

    private var studyContent: some View {
        Group {
            if model.isLoading {
                loadingView
            } else if model.didFailToLoad {
                loadFailureView
            } else if model.isFinished {
                finishedView
            } else if let card = model.currentCard {
                activeCardView(card)
            } else {
                emptyDueView
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(DesignSystem.detailBackground)

        .task {
            await model.startSession(scope: scope)
        }
        .onChange(of: endSessionTrigger) { _, triggered in
            guard triggered else { return }
            endSessionTrigger = false
            endSession()
        }
        .confirmationDialog(
            "Delete this audio draft?",
            isPresented: $showDeleteDraftConfirm,
            titleVisibility: .visible
        ) {
            Button("Delete Draft", role: .destructive) { recording.reset() }
            Button("Keep Draft", role: .cancel) {}
        } message: {
            Text("This recording has not been saved and cannot be recovered.")
        }
        .onChange(of: model.isAnswerRevealed) { _, revealed in
            if revealed { typedAnswerFocused = false }
            guard revealed, let cardID = model.currentCard?.id else { return }
            if AccessibilityNotifier.shared.post(.answerRevealed(cardID: cardID)) != nil {
                answerAccessibilityFocused = true
            }
        }
        .sheet(isPresented: $isEditingCard) {
            cardEditor
        }
        .focusedSceneValue(\.studyPrimaryActionHandler, primaryActionHandler)
        .editingShortcut(.space, modifiers: [], isEnabled: !isEditingCard && (canGrade || primaryActionHandler.isEnabled)) {
            if canGrade { Task { await model.grade(.good) } }
            else { primaryActionHandler.invoke() }
        }
        .editingShortcut("e", modifiers: .command, isEnabled: model.currentCard != nil && !isEditingCard && !model.isGrading && !model.isPreparingQueue) {
            isEditingCard = true
        }
        .editingShortcut("p", modifiers: .command, isEnabled: recording.hasRecording && !isEditingCard) {
            recording.togglePlayback()
        }
        .editingShortcut("r", modifiers: .command, isEnabled: canUseRecordingShortcut) {
            if recording.state == .recording { recording.stop() }
            else {
                Task { await recording.start(persistentSubmission: model.currentCard?.template.interaction == .audioSubmission) }
            }
        }
        .editingUndoContext(EditingUndoContext(canUndo: model.canUndoLastGrade && !model.isGrading && !isEditingCard) {
            Task { await model.undoLastGrade() }
        })
    }

    /// The library's item editor, opened on the card in front of you. Saving
    /// reconciles cards the way an edit from the library does, so a correction
    /// costs the session nothing beyond the cards the edit itself retires.
    @ViewBuilder
    private var cardEditor: some View {
        if let card = model.currentCard {
            if card.itemType.name == "Poem Line",
               let deckID = card.item.deckID,
               let deckName = decksModel.summaries.first(where: { $0.id == deckID })?.name {
                PoemDeckEditorView(
                    library: itemsModel.library,
                    deckID: deckID,
                    itemTypeID: card.itemType.id,
                    deckName: deckName,
                    onSaved: {
                        isEditingCard = false
                        Task { await model.reloadCurrentItem() }
                    },
                    onCancel: { isEditingCard = false }
                )
            } else if card.itemType.name == "Prose Unit",
                      let deckID = card.item.deckID,
                      let deckName = decksModel.summaries.first(where: { $0.id == deckID })?.name {
                ProseDeckEditorView(
                    library: itemsModel.library,
                    deckID: deckID,
                    itemTypeID: card.itemType.id,
                    deckName: deckName,
                    onSaved: {
                        isEditingCard = false
                        Task { await model.reloadCurrentItem() }
                    },
                    onCancel: { isEditingCard = false }
                )
            } else {
                NavigationStack {
                    AddItemView(
                        model: itemsModel,
                        decksModel: decksModel,
                        editingItem: card.item,
                        editingItemType: card.itemType
                    ) {
                        isEditingCard = false
                        Task { await model.reloadCurrentItem() }
                    }
                }
            }
        }
    }

    private var primaryActionHandler: StudyPrimaryActionHandler {
        let interaction = model.currentCard?.template.interaction
        let recordingIsReady = interaction != .record || recording.isReadyForComparison
        return StudyPrimaryActionHandler(
            action: {
                StudyAnimation.revealAnswer(reduceMotion: reduceMotion) {
                    model.performPrimaryAction()
                }
            },
            isEnabled: canShowAnswer
                && recordingIsReady
                && interaction != .audioSubmission
                && !isEditingCard
        )
    }

    // Menu contents mount lazily; recording shortcuts belong to the study
    // surface so they remain available while the actions menu is closed.
    private var canUseRecordingShortcut: Bool {
        let interaction = model.currentCard?.template.interaction
        return (interaction == .record || interaction == .audioSubmission)
            && !model.isAnswerRevealed && !isEditingCard
            && !model.isCompletingSubmission && !model.isPreparingQueue
            && recording.state != .requestingPermission
    }

    private var canShowAnswer: Bool {
        guard model.currentCard != nil else { return false }
        return !model.isAnswerRevealed
            && !model.isLoading
            && !model.isFinished
    }

    private var canGrade: Bool {
        guard model.currentCard != nil else { return false }
        return model.isAnswerRevealed
            && !model.isGrading
            && !model.isPreparingQueue
    }

    private var canSkip: Bool {
        model.currentCard != nil
            && !model.isGrading
            && !model.isCompletingSubmission
            && !model.isPreparingQueue
            && !isEditingCard
    }

    private var loadingView: some View {
        VStack(spacing: DesignSystem.Spacing.sm) {
            ProgressView()
            Text("Loading due cards…")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Loading due cards")
        .accessibilityIdentifier("studyLoading")
    }

    /// Reached only when a session opens on an empty queue. The scope home is
    /// where "nothing is due" is answered properly, with the time the next card
    /// returns, so this state's job is to send you back there.
    private var emptyDueView: some View {
        ContentUnavailableView {
            Label("Nothing Due Right Now", systemImage: "calendar.badge.clock")
        } description: {
            Text("Leave the session to see when the next card in this scope comes back.")
        } actions: {
            Button("Back to Library") {
                onEndSession()
            }
            .accessibilityIdentifier("studyBackToLibrary")
        }
    }

    /// A queue that could not be read is not a finished session. Saying so, and
    /// offering the retry, keeps a single unreadable card from looking like the
    /// scope had nothing left to study.
    private var loadFailureView: some View {
        ContentUnavailableView {
            Label("Couldn't Load Due Cards", systemImage: "exclamationmark.triangle")
        } description: {
            Text(model.errorMessage ?? "The due cards for this scope could not be read.")
        } actions: {
            Button("Try Again") {
                Task { await model.startSession(scope: scope) }
            }
            .buttonStyle(.borderedProminent)
            .accessibilityIdentifier("studyRetryLoad")

            Button("Back to Library") {
                onEndSession()
            }
            .accessibilityIdentifier("studyBackToLibrary")
        }
        .accessibilityIdentifier("studyLoadFailure")
    }

    private var finishedView: some View {
        ContentUnavailableView {
            Label("Session Complete", systemImage: "checkmark.circle")
        } description: {
            Text(model.queue.isEmpty ? "No more due cards in this session." : model.completionSummary)
            Text("Learning time: " + LearningTimeFormat.duration(model.learningTime.sessionMilliseconds))
            LearningTimeSaveStatusView()
        } actions: {
            if model.canUndoLastGrade {
                Button("Undo Last Grade") {
                    Task { await model.undoLastGrade() }
                }
                .disabled(model.isGrading)
                .accessibilityIdentifier("undoLastGrade")
            }

            Button("Done") {
                onEndSession()
            }
            .keyboardShortcut(.defaultAction)
            .buttonStyle(.borderedProminent)
            .accessibilityIdentifier("studySessionDone")
        }
    }

    @ViewBuilder
    private func activeCardView(_ card: DueCard) -> some View {
        VStack(spacing: 0) {
            studyHeader

            Divider()

            AdaptiveStudyStage(
                layout: StudyStageGeometry.effectiveLayout(
                    for: card.template,
                    item: card.item
                )
            ) {
                studyCardContent(card)
            } footer: {
                VStack(spacing: 0) {
                    if let errorMessage = model.errorMessage {
                        ErrorBanner(message: errorMessage)
                    }
                    studyFooter(for: card)
                }
            }
        }
        .onExitCommand {
            endSession()
        }
        .onChange(of: card.id) {
            recording.reset()
        }
        .onChange(of: recording.state) { _, state in
            guard case let .failed(message) = state else { return }
            if AccessibilityNotifier.shared.post(.recordingError(message)) != nil {
                recordingErrorAccessibilityFocused = true
            }
        }
        .onDisappear {
            recording.reset()
        }
    }

    private var studyHeader: some View {
        HStack(spacing: DesignSystem.Spacing.md) {
            Text(model.headerLabel)
                .font(DesignSystem.Typography.uiCaption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .accessibilityLabel("Progress, \(model.headerLabel)")
                .accessibilityIdentifier("studyProgress")

            Spacer(minLength: DesignSystem.Spacing.md)

            if let undo = model.pendingGradeUndo {
                gradeUndoFeedback(for: undo)
            }

            Button("Skip", systemImage: "forward") {
                skipCurrentCard()
            }
            .buttonStyle(.borderless)
            .fixedSize()
            .help("Move this card to the end of the current session queue")
            .disabled(!canSkip)
            .accessibilityHint("Moves this card to the end without grading it")
            .accessibilityIdentifier("skipStudyCard")

            Menu {
                Button("Edit Card", systemImage: "square.and.pencil") {
                    isEditingCard = true
                }
                .disabled(model.isGrading || model.isPreparingQueue)
                .accessibilityIdentifier("editStudyCard")

                Button("Grade Help", systemImage: "questionmark.circle") {
                    showGradeGuide = true
                }
                .accessibilityIdentifier("gradeHelp")
            } label: {
                Label("More", systemImage: "ellipsis.circle")
            }
            .menuStyle(.borderlessButton)
            .fixedSize()
            .help("Edit the current card or open grade help")
            .accessibilityIdentifier("studyActionsMenu")
            .popover(isPresented: $showGradeGuide, arrowEdge: .top) {
                GradeGuideView(gradingMode: gradingMode)
            }

            Button("End Session", systemImage: "stop.fill") {
                endSession()
            }
            .buttonStyle(.borderless)
            .fixedSize()
            .help("End this study session")
            .accessibilityIdentifier("endStudySession")
        }
        .padding(.horizontal, DesignSystem.Spacing.studyHorizontal)
        .padding(.vertical, DesignSystem.Spacing.sm)
    }

    @ViewBuilder
    private func studyCardContent(_ card: DueCard) -> some View {
        StudyStageContent(spacing: DesignSystem.Spacing.md) {
            StudyCompositionView(
                template: card.template,
                item: card.item,
                isAnswerRevealed: model.isAnswerRevealed,
                mediaStore: mediaStore,
                occlusionGroup: card.card.occlusionGroup, clozeGroup: card.card.clozeGroup,
                response: model.reviewResponse, evaluation: model.answerEvaluation
            )
            .id(card.id)
            .accessibilityIdentifier(model.isAnswerRevealed ? "studyAnswer" : "studyPrompt")
            .frame(maxWidth: .infinity)
            .frame(maxHeight: .infinity)
        } response: {
            studyResponseRegion(for: card)
        }
        .transition(.opacity)
        .accessibilityFocused($answerAccessibilityFocused)
    }

    /// The fixed card template has one flexible composition region and one
    /// intrinsic response region. Keeping every response state in this single
    /// slot prevents the composition from compressing controls or status text.
    @ViewBuilder
    private func studyResponseRegion(for card: DueCard) -> some View {
        VStack(spacing: DesignSystem.Spacing.md) {
            if !model.isAnswerRevealed {
                interactionResponse(for: card)
                    .frame(maxWidth: 640)
                    .padding(.horizontal, DesignSystem.Spacing.studyHorizontal)
            }

            if let message = model.interactionMessage {
                Text(message)
                    .font(DesignSystem.Typography.uiSecondary)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .accessibilityIdentifier("studyInteractionMessage")
            }

            if model.isAnswerRevealed {
                if model.reviewResponse == nil || model.answerEvaluation == .unavailable { evaluationFeedback }

                if card.template.interaction == .record, recording.hasRecording {
                    revealedRecordingPlayback
                }
            }
        }
    }

    @ViewBuilder
    private func interactionResponse(for card: DueCard) -> some View {
        switch card.template.interaction {
        case .reveal, .cloze, .imageOcclusion:
            EmptyView()
        case .type:
            VStack(alignment: .leading, spacing: DesignSystem.Spacing.xs) {
                Text("Your answer")
                    .font(DesignSystem.Typography.uiCaption)
                    .foregroundStyle(.secondary)
                TextField(
                    "Type your answer",
                    text: Binding(
                        get: { model.typedAnswer },
                        set: { model.updateTypedAnswer($0) }
                    )
                )
                .textFieldStyle(.roundedBorder)
                .focused($typedAnswerFocused)
                .onSubmit { model.submitTypedAnswer(); typedAnswerFocused = false }
                .accessibilityIdentifier("typedAnswer")
                Text("Press Return to check. You’ll still choose your own grade.")
                    .font(DesignSystem.Typography.uiHint)
                    .foregroundStyle(.tertiary)
            }
        case .choose:
            VStack(spacing: DesignSystem.Spacing.xs) {
                ForEach(Array(model.choiceOptions.enumerated()), id: \.offset) { index, option in
                    Button {
                        model.selectChoice(option)
                    } label: {
                        HStack {
                            Text("\(index + 1).")
                                .foregroundStyle(.secondary)
                            Text(option)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            if model.selectedChoice == option {
                                Image(systemName: "checkmark")
                                    .accessibilityHidden(true)
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.large)
                    .editingShortcut(KeyEquivalent(Character(String(index + 1))), modifiers: [], isEnabled: !model.isAnswerRevealed && !isEditingCard) {
                        model.selectChoice(option)
                    }
                    .help("Choose option \(index + 1) (\(index + 1))")
                    .accessibilityLabel("Option \(index + 1), \(option)")
                    .accessibilityValue(model.selectedChoice == option ? "Selected" : "")
                    .accessibilityIdentifier("choiceOption\(index)")
                }
            }
            .frame(maxWidth: .infinity)
        case .record:
            recordingResponse
        case .audioSubmission:
            audioSubmissionResponse
        case .arrange:
            arrangementResponse
        }
    }

    private var audioSubmissionResponse: some View {
        VStack(spacing: DesignSystem.Spacing.sm) {
            Label("Private response", systemImage: "lock.fill")
                .font(DesignSystem.Typography.uiSecondary)
                .foregroundStyle(.secondary)
            Text("This recording stays in your local library and is not synced to the cloud.")
                .font(DesignSystem.Typography.uiHint)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Text(recordingDurationText)
                .font(.system(.title2, design: .monospaced).monospacedDigit())
                .accessibilityLabel("Recording duration \(recordingDurationText)")

            Label(audioSubmissionStatusText, systemImage: recordingStatusIcon)
                .font(DesignSystem.Typography.uiHint)
                .foregroundStyle(recordingHasError ? .red : .secondary)
                .multilineTextAlignment(.center)
                .accessibilityFocused($recordingErrorAccessibilityFocused)
                .accessibilityIdentifier("audioSubmissionStatus")
        }
        .frame(maxWidth: 620)
    }

    @ViewBuilder
    private var evaluationFeedback: some View {
        switch model.answerEvaluation {
        case .correct:
            Label("Matches", systemImage: "checkmark.circle.fill")
                .foregroundStyle(.green)
                .accessibilityIdentifier("answerCorrect")
        case .incorrect:
            Label("Differs", systemImage: "arrow.left.arrow.right")
                .foregroundStyle(.secondary)
                .accessibilityIdentifier("answerIncorrect")
        case .unavailable:
            Label("Self-grade", systemImage: "person.crop.circle.badge.questionmark")
                .foregroundStyle(.secondary)
                .accessibilityIdentifier("answerCheckUnavailable")
        case nil:
            EmptyView()
        }
    }

    private var recordingResponse: some View {
        VStack(spacing: DesignSystem.Spacing.sm) {
            Label(recordingStatusText, systemImage: recordingStatusIcon)
                .font(DesignSystem.Typography.uiSecondary)
                .foregroundStyle(recordingHasError ? .red : .secondary)
                .multilineTextAlignment(.center)
                .accessibilityFocused($recordingErrorAccessibilityFocused)

            if recording.hasRecording || recording.state == .recording {
                Text(recordingDurationText)
                    .font(.system(.title2, design: .monospaced).monospacedDigit())
                    .accessibilityLabel("Recording duration \(recordingDurationText)")
            }
        }
    }

    private var revealedRecordingPlayback: some View {
        VStack(spacing: DesignSystem.Spacing.sm) {
            Label(revealedRecordingStatusText, systemImage: recordingStatusIcon)
                .font(DesignSystem.Typography.uiSecondary)
                .foregroundStyle(recordingHasError ? .red : .secondary)
                .multilineTextAlignment(.center)
                .accessibilityFocused($recordingErrorAccessibilityFocused)

            Button(recording.state == .playing ? "Stop My Recording" : "Play My Recording") {
                recording.togglePlayback()
            }
            .controlSize(.large)
            .accessibilityIdentifier("playRecording")
        }
    }

    private var arrangementResponse: some View {
        VStack(spacing: DesignSystem.Spacing.sm) {
            Text("Select an item, then move it into the right order.")
                .font(DesignSystem.Typography.uiHint)
                .foregroundStyle(.secondary)

            ForEach(Array(model.arrangedItems.enumerated()), id: \.offset) { index, item in
                Button {
                    model.selectArrangementItem(at: index)
                } label: {
                    HStack {
                        Text("\(index + 1).")
                            .foregroundStyle(.secondary)
                        Text(item)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        if model.selectedArrangementIndex == index {
                            Image(systemName: "selection.pin.in.out")
                                .accessibilityHidden(true)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.bordered)
                .modifier(ArrangementSelectionShortcut(index: index, isEnabled: !isEditingCard) {
                    model.selectArrangementItem(at: index)
                })
                .accessibilityLabel("Position \(index + 1), \(item)")
                .accessibilityValue(model.selectedArrangementIndex == index ? "Selected" : "")
                .accessibilityIdentifier("arrangementItem\(index)")
            }

            HStack {
                Button("Move Up", systemImage: "arrow.up") {
                    model.moveSelectedArrangementItem(by: -1)
                }
                .editingShortcut(.upArrow, modifiers: .command, isEnabled: !isEditingCard && model.selectedArrangementIndex != nil && model.selectedArrangementIndex != 0) {
                    model.moveSelectedArrangementItem(by: -1)
                }
                .disabled(model.selectedArrangementIndex == nil || model.selectedArrangementIndex == 0)
                .accessibilityIdentifier("moveArrangementUp")

                Button("Move Down", systemImage: "arrow.down") {
                    model.moveSelectedArrangementItem(by: 1)
                }
                .editingShortcut(.downArrow, modifiers: .command, isEnabled: !isEditingCard && model.selectedArrangementIndex != nil && model.selectedArrangementIndex != model.arrangedItems.indices.last) {
                    model.moveSelectedArrangementItem(by: 1)
                }
                .disabled(
                    model.selectedArrangementIndex == nil
                        || model.selectedArrangementIndex == model.arrangedItems.indices.last
                )
                .accessibilityIdentifier("moveArrangementDown")
            }
        }
    }

    @ViewBuilder
    private func studyFooter(for card: DueCard) -> some View {
        HStack {
            if card.template.interaction == .audioSubmission {
                audioSubmissionFooter(for: card)
            } else if model.isAnswerRevealed {
                gradeButtons
            } else if card.template.interaction == .record {
                recordingStudyFooter
            } else {
                HStack(spacing: DesignSystem.Spacing.sm) {
                    Button(primaryActionTitle(for: card.template.interaction)) {
                        StudyAnimation.revealAnswer(reduceMotion: reduceMotion) {
                            model.performPrimaryAction()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .keyboardShortcut(.defaultAction)
                    .accessibilityIdentifier("primaryStudyAction")

                    if card.template.interaction != .reveal, card.template.interaction != .cloze {
                        revealAndSelfGradeButton
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .center)
        .padding(.horizontal, DesignSystem.Spacing.studyHorizontal)
        .padding(.top, DesignSystem.Spacing.sm)
        .padding(.bottom, DesignSystem.Spacing.studyHorizontal)
    }

    @ViewBuilder
    private func audioSubmissionFooter(for card: DueCard) -> some View {
        if model.isCompletingSubmission {
            ProgressView("Saving response…")
                .frame(minHeight: 44)
        } else if recording.state == .requestingPermission {
            ProgressView("Requesting microphone access…")
                .frame(minHeight: 44)
        } else if recording.state == .recording {
            Button("Stop Recording", systemImage: "stop.circle.fill") {
                recording.stop()
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .accessibilityHint("Stops the current private-response recording")
            .accessibilityIdentifier("stopAudioSubmission")
        } else if recording.submissionDraft(cardID: card.id) != nil {
            HStack(spacing: DesignSystem.Spacing.sm) {
                Button("Save & Complete", systemImage: "checkmark.circle.fill") {
                    saveAudioSubmission(for: card)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .keyboardShortcut(.defaultAction)
                .disabled(model.isPreparingQueue)
                .accessibilityHint("Saves this recording locally and completes the card without grading it")
                .accessibilityIdentifier("saveAudioSubmission")

                audioSubmissionActionsMenu
            }
        } else {
            Button("Start Recording", systemImage: "mic.fill") {
                Task { await recording.start(persistentSubmission: true) }
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .accessibilityHint("Starts a private audio response stored only in the local library")
            .accessibilityIdentifier("startAudioSubmission")
        }
    }

    private var audioSubmissionActionsMenu: some View {
        Menu {
            Button(
                recording.state == .playing ? "Stop Playback" : "Play Recording",
                systemImage: recording.state == .playing ? "stop.fill" : "play.fill"
            ) {
                recording.togglePlayback()
            }
            .accessibilityIdentifier("playAudioSubmission")

            Button("Record Again", systemImage: "arrow.counterclockwise") {
                Task { await recording.start(persistentSubmission: true) }
            }
            .accessibilityIdentifier("rerecordAudioSubmission")

            Divider()

            Button("Delete Draft", systemImage: "trash", role: .destructive) {
                showDeleteDraftConfirm = true
            }
            .accessibilityIdentifier("deleteAudioSubmissionDraft")
        } label: {
            Label("Recording", systemImage: "waveform")
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
        .help("Playback and recording actions")
        .accessibilityIdentifier("audioSubmissionActions")
    }

    @ViewBuilder
    private var recordingStudyFooter: some View {
        if recording.state == .requestingPermission {
            ProgressView("Requesting microphone access…")
                .frame(minHeight: 44)
        } else {
            HStack(spacing: DesignSystem.Spacing.sm) {
                if recording.state == .recording {
                    Button("Stop Recording", systemImage: "stop.circle.fill") {
                        recording.stop()
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .accessibilityIdentifier("stopRecording")
                } else if recording.isReadyForComparison {
                    Button("Reveal & Compare", systemImage: "arrow.right.circle.fill") {
                        StudyAnimation.revealAnswer(reduceMotion: reduceMotion) {
                            model.performPrimaryAction()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .keyboardShortcut(.defaultAction)
                    .accessibilityIdentifier("primaryStudyAction")

                    recordingActionsMenu
                } else {
                    Button("Start Recording", systemImage: "mic.fill") {
                        Task { await recording.start() }
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .accessibilityIdentifier("startRecording")
                }

                revealAndSelfGradeButton
            }
        }
    }

    private var recordingActionsMenu: some View {
        Menu {
            Button(
                recording.state == .playing ? "Stop Playback" : "Play My Recording",
                systemImage: recording.state == .playing ? "stop.fill" : "play.fill"
            ) {
                recording.togglePlayback()
            }
            .accessibilityIdentifier("playRecording")

            Button("Record Again", systemImage: "arrow.counterclockwise") {
                Task { await recording.start() }
            }
            .accessibilityIdentifier("startRecording")
        } label: {
            Label("Recording", systemImage: "waveform")
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
        .help("Playback and recording actions")
        .accessibilityIdentifier("recordingActions")
    }

    private var revealAndSelfGradeButton: some View {
        Button("Reveal & Self-Grade") {
            StudyAnimation.revealAnswer(reduceMotion: reduceMotion) {
                model.revealAnswer()
            }
        }
        .controlSize(.large)
        .editingShortcut(.rightArrow, modifiers: [], isEnabled: !isEditingCard && recording.state != .recording && recording.state != .requestingPermission) {
            StudyAnimation.revealAnswer(reduceMotion: reduceMotion) { model.revealAnswer() }
        }
        .help("Reveal without checking (Right Arrow)")
        .disabled(
            recording.state == .recording
                || recording.state == .requestingPermission
        )
        .accessibilityIdentifier("revealAndSelfGrade")
    }

    private func saveAudioSubmission(for card: DueCard) {
        guard let draft = recording.submissionDraft(cardID: card.id) else { return }
        if recording.state == .playing {
            recording.togglePlayback()
        }
        Task {
            if await model.completeAudioSubmission(draft) { recording.reset() }
        }
    }

    private var gradeButtons: some View {
        HStack(spacing: DesignSystem.Spacing.sm) {
            ForEach(gradingMode.choices, id: \.rating) { choice in
                Button(choice.titleWithShortcut) {
                    Task { await model.grade(choice.rating) }
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
                .editingShortcut(KeyEquivalent(Character(choice.shortcutLabel)), modifiers: [], isEnabled: canGrade && !isEditingCard) {
                    Task { await model.grade(choice.rating) }
                }
                .help(choice.guidance)
                .disabled(model.isGrading || model.isPreparingQueue)
                .accessibilityLabel(choice.accessibilityLabel)
                .accessibilityIdentifier(choice.rating.gradeAccessibilityIdentifier)
            }
        }
    }

    private func gradeUndoFeedback(for undo: PendingGradeUndo) -> some View {
        HStack(spacing: DesignSystem.Spacing.sm) {
            Label(
                "Graded as \(gradingMode.title(for: undo.rating)).",
                systemImage: "checkmark.circle"
            )
            .font(DesignSystem.Typography.uiSecondary)
            .foregroundStyle(.secondary)
            .lineLimit(1)

            Button("Undo") {
                Task { await model.undoLastGrade() }
            }
            .buttonStyle(.borderless)
            .accessibilityIdentifier("undoLastGrade")

            Button {
                model.dismissGradeUndo()
            } label: {
                Image(systemName: "xmark")
                    .font(DesignSystem.Typography.uiCaption)
            }
            .buttonStyle(.borderless)
            .help("Dismiss")
            .accessibilityLabel("Dismiss undo")
            .accessibilityIdentifier("dismissGradeUndo")
        }
        .fixedSize()
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Graded as \(gradingMode.title(for: undo.rating)). Undo available")
    }

    private var gradingMode: StudyGradingMode {
        StudyGradingMode(usesPassFailGrades: usesPassFailGrades)
    }

    private func endSession() {
        recording.reset()
        onEndSession()
    }

    private func skipCurrentCard() {
        recording.reset()
        Task { await model.skipCurrentCard() }
    }

    private func primaryActionTitle(for interaction: Interaction) -> String {
        switch interaction {
        case .reveal, .cloze, .imageOcclusion: "Show Answer"
        case .type: "Check Answer"
        case .choose: "Check Choice"
        case .record: "Reveal & Compare"
        case .audioSubmission: "Save & Complete"
        case .arrange: "Check Order"
        }
    }

    private var recordingDurationText: String {
        let total = max(0, Int(recording.elapsedSeconds.rounded(.down)))
        return String(format: "%02d:%02d", total / 60, total % 60)
    }

    private var recordingHasError: Bool {
        if case .failed = recording.state { return true }
        return false
    }

    private var audioSubmissionStatusText: String {
        switch recording.state {
        case .idle: "Ready to record"
        case .requestingPermission: "Waiting for microphone permission…"
        case .recording: "Recording… press Command-R to stop."
        case .recorded: "Recording ready to save"
        case .playing: "Playing your recording…"
        case let .failed(message): message
        }
    }

    private var recordingStatusText: String {
        switch recording.state {
        case .idle: "Record yourself, then compare with the reference answer."
        case .requestingPermission: "Waiting for microphone permission…"
        case .recording: "Recording… press Command-R to stop."
        case .recorded: "Recording ready. Play it back before comparing."
        case .playing: "Playing your recording…"
        case let .failed(message): message
        }
    }

    private var recordingStatusIcon: String {
        switch recording.state {
        case .recording: "waveform"
        case .recorded, .playing: "checkmark.circle"
        case .failed: "exclamationmark.triangle"
        case .idle, .requestingPermission: "mic"
        }
    }

    private var revealedRecordingStatusText: String {
        switch recording.state {
        case .playing:
            "Playing your recording…"
        case let .failed(message):
            message
        case .idle, .requestingPermission, .recording, .recorded:
            "Your recording"
        }
    }
}

/// Binds Command-1 … Command-9 to the first nine arrangement items so the whole
/// arrange interaction (select then move with Command-Arrow) is keyboard-only.
/// Command avoids clashing with the plain 1–4 grade shortcuts, which are only
/// active once the answer is revealed.
private struct ArrangementSelectionShortcut: ViewModifier {
    let index: Int
    let isEnabled: Bool
    let action: () -> Void

    @ViewBuilder
    func body(content: Content) -> some View {
        if index < 9 {
            content.editingShortcut(
                KeyEquivalent(Character("\(index + 1)")),
                modifiers: [.command], isEnabled: isEnabled, action: action
            )
        } else {
            content
        }
    }
}
