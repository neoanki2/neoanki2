import CloudKit
import Foundation
import NeoAnkiApplication
import NeoAnkiCore

/// The scheduler is replaceable inside tests so debounce/recovery contracts can
/// advance virtual time without turning a busy CI runner into a latency failure.
struct SyncTiming: Sendable {
    enum Reason: Sendable, Equatable {
        case localChange(cursor: Int64)
        case recoveryPoll
    }

    let now: @Sendable () -> Date
    let sleep: @Sendable (Duration, Reason) async throws -> Void
    var didFinishSynchronization: @Sendable () -> Void = {}

    static let continuous = SyncTiming(now: { .now }, sleep: { duration, _ in try await Task.sleep(for: duration) })
}

/// Coordinates a local-authoritative repository and an independent CloudKit
/// transport. Transport failure changes status but never prevents local work.
public actor OfflineFirstSyncService: SyncService {
    private let repository: any LibraryChangePersisting
    private let adapter: any LibrarySyncAdapter
    private let transport: any CloudSyncTransport
    private let metadataStore: SyncMetadataStore
    private let learningTime: LearningTimeSyncService?
    private let backupURL: @Sendable () -> URL
    private let recoveryPollInterval: Duration
    private let timing: SyncTiming
    private var currentStatus: SyncStatus = .offline
    private var currentIssues: [SyncIssue] = []
    private var isSynchronizing = false
    private var synchronizationRequested = false
    private var completionWaiters: [UUID: CheckedContinuation<Void, Never>] = [:]
    private var nextAllowedSync: Date?
    private var automaticSyncTask: Task<Void, Never>?
    private var localChangeMonitor: Task<Void, Never>?
    private var localSyncTask: Task<Void, Never>?
    private let libraryChangeEvents = SyncLibraryChanges()
    private var transportStarted = false
    private var lifecycle = 0

    public init(
        repository: any LibraryChangePersisting,
        adapter: any LibrarySyncAdapter,
        transport: any CloudSyncTransport,
        metadataStore: SyncMetadataStore,
        learningTime: LearningTimeSyncService? = nil,
        recoveryPollInterval: Duration = .seconds(10),
        backupURL: @escaping @Sendable () -> URL
    ) {
        self.repository = repository
        self.adapter = adapter
        self.transport = transport
        self.metadataStore = metadataStore
        self.learningTime = learningTime
        self.backupURL = backupURL
        self.recoveryPollInterval = recoveryPollInterval
        self.timing = .continuous
    }

    /// Internal scheduling seam; production callers retain the public initializer.
    init(
        repository: any LibraryChangePersisting,
        adapter: any LibrarySyncAdapter,
        transport: any CloudSyncTransport,
        metadataStore: SyncMetadataStore,
        recoveryPollInterval: Duration = .seconds(10),
        timing: SyncTiming,
        backupURL: @escaping @Sendable () -> URL
    ) {
        self.repository = repository
        self.adapter = adapter
        self.transport = transport
        self.metadataStore = metadataStore
        self.learningTime = nil
        self.backupURL = backupURL
        self.recoveryPollInterval = recoveryPollInterval
        self.timing = timing
    }

    public func start() async {
        let generation = lifecycle
        if localChangeMonitor == nil {
            let stream = await repository.changeNotifications()
            guard generation == lifecycle else { return }
            localChangeMonitor = Task { [weak self] in
                for await cursor in stream {
                    guard !Task.isCancelled else { return }
                    await self?.scheduleLocalSync(after: cursor)
                }
            }
        }
        await synchronize()
        guard generation == lifecycle else { return }
        if automaticSyncTask == nil {
            let interval = recoveryPollInterval
            let scheduler = timing
            automaticSyncTask = Task { [weak self] in
                while !Task.isCancelled {
                    do { try await scheduler.sleep(interval, .recoveryPoll) }
                    catch { return }
                    await self?.synchronize()
                }
            }
        }
    }

    public func synchronize() async {
        guard nextAllowedSync.map({ $0 <= timing.now() }) ?? true else { return }
        guard !isSynchronizing else { synchronizationRequested = true; return }
        isSynchronizing = true
        defer {
            isSynchronizing = false
            finishWaiters()
            timing.didFinishSynchronization()
        }
        let generation = lifecycle
        repeat {
            synchronizationRequested = false
            await synchronizeOnce()
        } while synchronizationRequested && generation == lifecycle && !Task.isCancelled
            && (nextAllowedSync.map({ $0 <= timing.now() }) ?? true)
    }

    /// Background pushes need to await an already-running cycle, including its
    /// coalesced catch-up fetch, before telling the OS their work is complete.
    public func synchronizeAndWait() async {
        guard isSynchronizing else { await synchronize(); return }
        synchronizationRequested = true
        let id = UUID()
        await withTaskCancellationHandler {
            await withCheckedContinuation { continuation in
                if Task.isCancelled { continuation.resume() }
                else { completionWaiters[id] = continuation }
            }
        } onCancel: {
            Task { await self.cancelWaiter(id) }
        }
    }

    private func cancelWaiter(_ id: UUID) { completionWaiters.removeValue(forKey: id)?.resume() }
    private func finishWaiters() {
        let waiters = completionWaiters.values
        completionWaiters = [:]
        for waiter in waiters { waiter.resume() }
    }

    private func synchronizeOnce() async {
        currentStatus = .syncing
        let generation = lifecycle
        do {
            if !transportStarted {
                try await transport.start()
                try checkLifecycle(generation)
                transportStarted = true
            }
            var metadata = try await metadataStore.load()
            currentIssues = metadata.issues
            if metadata.didCreateInitialBackup != true {
                let destination = backupURL()
                try await repository.createBackup(at: destination)
                try await repository.verifyBackup(at: destination)
                metadata.didCreateInitialBackup = true
                try await metadataStore.save(metadata)
            }
            try checkLifecycle(generation)
            // A cursor may advance only after its payloads are durably queued.
            // A process restart must not depend on CKSyncEngine's in-memory
            // records or on an adapter's consumed echo suppression entries.
            try await flushOutbound(metadata: &metadata, generation: generation)
            if metadata.didCompleteInitialMerge == true {
                try await stageLocalChanges(metadata: &metadata)
                try await flushOutbound(metadata: &metadata, generation: generation)
            }

            let incoming = try await transport.fetchPendingChanges()
            try checkLifecycle(generation)
            if !incoming.isEmpty { try await metadataStore.receive(incoming) }
            // The transport can durably stage callbacks while an awaited send
            // or fetch is in flight. Reload, never overwrite that newer inbox.
            metadata = try await metadataStore.load()
            currentIssues = metadata.issues
            // An empty cloud still requires the complete initial snapshot;
            // uploading a local journal first can overwrite colliding identities.
            if metadata.didCompleteInitialMerge != true || !metadata.stagedInbound.isEmpty {
                let recovered = metadata.stagedInbound
                let beforeMergeCursor = try await repository.currentChangeCursor()
                let firstMerge = metadata.didCompleteInitialMerge != true
                try await consumeIncoming(recovered, metadata: &metadata)
                if firstMerge { metadata.outboundCursor = beforeMergeCursor }
                metadata.stagedInbound = []
                metadata.issues = currentIssues
                metadata = try await metadataStore.completeIncoming(recovered, metadata: metadata)
                if !recovered.isEmpty { await libraryChangeEvents.publish() }
            }
            // Resolve both newly discovered conflicts and copies retained by
            // older app versions. Commit each decision before advancing, and
            // queue recovered resources through the ordinary outbound journal.
            try await resolveConflictsAutomatically(generation: generation)
            metadata = try await metadataStore.load()
            currentIssues = metadata.issues
            try await flushOutbound(metadata: &metadata, generation: generation)
            try await stageLocalChanges(metadata: &metadata)
            try await flushOutbound(metadata: &metadata, generation: generation)

            try checkLifecycle(generation)
            if let learningTime {
                do { try await learningTime.synchronize() }
                catch { throw UserFacingError(title: "Learning Time Could Not Sync", message: error.localizedDescription) }
            }
            try checkLifecycle(generation)
            metadata = try await metadataStore.load()
            currentIssues = metadata.issues
            currentIssues.removeAll { $0.resourceID == "sync-batch" && $0.conflictCopy == nil }
            metadata.issues = currentIssues
            try await metadataStore.save(metadata)
            try checkLifecycle(generation)
            nextAllowedSync = nil
            currentStatus = !currentIssues.isEmpty ? .needsAttention(issueCount: currentIssues.count)
                : !metadata.stagedInbound.isEmpty || !(metadata.pendingOutbound ?? []).isEmpty ? .syncing
                : .current(lastSync: timing.now())
        } catch is CancellationError {
            currentStatus = .offline
        } catch {
            if generation == lifecycle {
                if let delay = (error as? CKError)?.retryAfterSeconds, delay > 0 {
                    nextAllowedSync = timing.now().addingTimeInterval(delay)
                }
                if (error as? CKError)?.code == .internalError {
                    // CloudKit can invalidate a long-lived client connection.
                    // Repeating fetch/send on that session never reconnects.
                    // Keep the durable inbox/outbox and restart on the next
                    // ordinary sync cycle instead of retrying inside this one.
                    transportStarted = false
                    await transport.stop()
                }
                if generation == lifecycle { await preserveFailure(error) }
            }
        }
    }

    public func libraryChanges() async -> AsyncStream<Void> { await libraryChangeEvents.stream() }

    private func scheduleLocalSync(after cursor: Int64) {
        localSyncTask?.cancel()
        let generation = lifecycle
        let scheduler = timing
        localSyncTask = Task { [weak self] in
            do {
                try await scheduler.sleep(.milliseconds(600), .localChange(cursor: cursor))
                try await self?.synchronizeLocalChanges(after: cursor, generation: generation)
            } catch {}
        }
    }

    private func synchronizeLocalChanges(after cursor: Int64, generation: Int) async throws {
        // Applying remote data also writes the journal. Once those echoes have
        // been staged, they must not initiate another read.
        let stagedCursor = try await metadataStore.load().outboundCursor
        try checkLifecycle(generation)
        guard stagedCursor < cursor else { return }
        // Debounce only pending work. A later local edit must never cancel an
        // upload that has already started; it requests a catch-up cycle instead.
        localSyncTask = nil
        await synchronize()
    }

    private func stageLocalChanges(metadata: inout SyncMetadata) async throws {
        var latest: [String: LibraryChange] = [:]
        var cursor = metadata.outboundCursor
        while true {
            let page = try await repository.changes(after: cursor, limit: 1_000)
            guard let last = page.last else { break }
            for change in page { latest["\(change.resourceType):\(change.resourceID)"] = change }
            cursor = last.cursor
            if page.count < 1_000 { break }
        }
        let changes = latest.values.sorted { $0.cursor < $1.cursor }
        let outbound = try await adapter.encode(changes: changes, deviceID: metadata.deviceID)
        metadata.pendingOutbound = (metadata.pendingOutbound ?? []) + (try await metadataStore.stageOutbound(outbound))
        metadata.outboundCursor = cursor
        try await metadataStore.save(metadata)
    }

    private func checkLifecycle(_ generation: Int) throws {
        guard generation == lifecycle, !Task.isCancelled else { throw CancellationError() }
    }

    private func resolveConflictsAutomatically(generation: Int) async throws {
        let snapshot = try await metadataStore.load()
        // Recover dependencies before items that may reference them.
        let priority = ["itemType": 0, "deck": 1, "item": 2]
        let issues = snapshot.issues.sorted {
            (priority[$0.conflictCopy?.resourceKind ?? ""] ?? 3) < (priority[$1.conflictCopy?.resourceKind ?? ""] ?? 3)
        }
        for issue in issues {
            guard let copy = issue.conflictCopy else { continue }
            try checkLifecycle(generation)
            guard LibraryResourceKind(rawValue: copy.resourceKind) != nil else { continue }
            if copy.isRestorable {
                // The adapter uses the copy's stable identity. A crash between
                // the domain commit and metadata commit cannot duplicate it.
                try await adapter.restoreConflictCopy(copy)
            }
            try checkLifecycle(generation)
            let latest = try await metadataStore.completeConflict(issue)
            currentIssues = latest.issues
        }
    }

    private func flushOutbound(metadata: inout SyncMetadata, generation: Int) async throws {
        try checkLifecycle(generation)
        guard let pending = metadata.pendingOutbound, !pending.isEmpty else { return }
        try await transport.enqueue(pending)
        try checkLifecycle(generation)
        metadata = try await metadataStore.load()
        currentIssues = metadata.issues
        metadata.pendingOutbound = []
        try await metadataStore.save(metadata)
        await metadataStore.removeStagedAssets(in: pending)
    }

    public func stop() async {
        lifecycle += 1
        automaticSyncTask?.cancel()
        automaticSyncTask = nil
        localChangeMonitor?.cancel()
        localChangeMonitor = nil
        localSyncTask?.cancel()
        localSyncTask = nil
        synchronizationRequested = false
        finishWaiters()
        await transport.stop()
        await learningTime?.stop()
        transportStarted = false
        currentStatus = .offline
    }

    public func status() async -> SyncStatus { currentStatus }
    public func issues() async -> [SyncIssue] { currentIssues }

    public func retryIssue(id: UUID) async {
        currentIssues.removeAll { $0.id == id }
        await persistIssues()
        await synchronize()
    }

    public func dismissIssue(id: UUID) async {
        currentIssues.removeAll { $0.id == id }
        await persistIssues()
        currentStatus = currentIssues.isEmpty ? .current(lastSync: timing.now()) : .needsAttention(issueCount: currentIssues.count)
    }

    public func restoreConflictCopy(forIssueID id: UUID) async throws {
        guard let issue = currentIssues.first(where: { $0.id == id }), let copy = issue.conflictCopy else {
            throw UserFacingError(title: "Conflict Can’t Be Restored", message: "The preserved copy is no longer available.")
        }
        try await adapter.restoreConflictCopy(copy)
        currentIssues.removeAll { $0.id == id }
        await persistIssues()
        await synchronize()
    }

    private func persistIssues() async {
        do {
            var metadata = try await metadataStore.load()
            metadata.issues = currentIssues
            try await metadataStore.save(metadata)
        } catch {}
    }

    private func conflictKind(_ resourceKind: String) -> SyncIssueKind {
        switch resourceKind {
        case LibraryResourceKind.deck.rawValue: .deckConflict
        case LibraryResourceKind.itemType.rawValue: .itemTypeConflict
        default: .itemConflict
        }
    }

    private func conflictKind(_ copy: SyncConflictCopy) -> SyncIssueKind {
        if copy.wasTombstone || copy.acceptedWasTombstone { return .deleteVersusEdit }
        return conflictKind(copy.resourceKind)
    }

    private func consumeIncoming(
        _ records: [SyncRecordEnvelope],
        metadata: inout SyncMetadata
    ) async throws {
        if metadata.didCompleteInitialMerge != true {
            let merged = try await adapter.initialMerge(
                remote: records,
                deviceID: metadata.deviceID
            )
            let copies = await adapter.preservedConflictCopies()
            for copy in copies where !currentIssues.contains(where: { $0.conflictCopy?.id == copy.id }) {
                currentIssues.append(SyncIssue(
                    kind: conflictKind(copy),
                    resourceID: copy.originalResourceID,
                    summary: "A change from another device was accepted. Your prior version is preserved.",
                    conflictCopy: copy
                ))
            }
            metadata.pendingOutbound = (metadata.pendingOutbound ?? []) + (try await metadataStore.stageOutbound(merged))
            metadata.didCompleteInitialMerge = true
        } else {
            try await adapter.applyRemote(records, origin: .cloud)
        }
    }

    private func preserveFailure(_ error: any Error) async {
        if let status = cloudStatus(for: error) {
            currentStatus = status
            return
        }
        let issue = SyncIssue(
            kind: (error as? SQLiteLibrarySyncError).map {
                if case .invalidAsset = $0 { return .mediaFailure }
                return .invalidRemoteChange
            } ?? .invalidRemoteChange,
            resourceID: "sync-batch",
            summary: "A sync batch was preserved for recovery: \(String(describing: error))"
        )
        currentIssues.removeAll { $0.resourceID == "sync-batch" && $0.conflictCopy == nil }
        currentIssues.append(issue)
        do {
            var metadata = try await metadataStore.load()
            metadata.issues = currentIssues
            try await metadataStore.save(metadata)
        } catch {
            // Keep the in-memory issue. The separate metadata store is retried
            // by the next synchronization and domain tables remain unchanged.
        }
        currentStatus = .needsAttention(issueCount: currentIssues.count)
    }

    private func cloudStatus(for error: any Error) -> SyncStatus? {
        let nsError = error as NSError
        if nsError.domain == CKErrorDomain,
           let code = CKError.Code(rawValue: nsError.code) {
            switch code {
            case .networkUnavailable, .networkFailure, .serviceUnavailable,
                 .requestRateLimited, .zoneBusy:
                return .offline
            case .notAuthenticated, .accountTemporarilyUnavailable,
                 .permissionFailure, .managedAccountRestricted:
                return .accountUnavailable
            default:
                break
            }
        }
        return nil
    }
}
