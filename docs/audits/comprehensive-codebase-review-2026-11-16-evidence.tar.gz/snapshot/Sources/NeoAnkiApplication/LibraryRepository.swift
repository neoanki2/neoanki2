import Foundation
import NeoAnkiCore

// MARK: - Application-facing capabilities

/// Startup operations owned by the library boundary rather than presentation code.
public protocol LibraryBootstrapping: Sendable {
    func bootstrap() async throws
    func coldHomeSnapshot(scope: DeckScope, asOf: Date) async throws -> ColdLibraryHomeSnapshot
    func mediaStore() async -> MediaStore?
}

/// Read models needed by library, browse, and item-detail presentation.
public protocol LibraryBrowsing: Sendable {
    func libraryID() async throws -> UUID
    func loadItemTypes() async throws -> ItemTypeLoadResult
    func loadItemTypeCatalog() async throws -> ItemTypeCatalog
    func authoringItemTypes(for deckID: UUID?) async throws -> AuthoringItemTypes
    func effectiveItemTypePolicy(for deckID: UUID) async throws -> DeckItemTypePolicy?
    func items(
        scope: DeckScope,
        sort: ItemSortOrder,
        search: String
    ) async throws -> [SavedItemSummary]
    func item(id: UUID) async throws -> (item: Item, itemType: ItemType)?
    func cardMaturityDetails(itemID: UUID) async throws -> [CardMaturityDetail]
    func itemBrowseSchedules(itemIDs: [UUID]) async throws -> [UUID: ItemBrowseSchedule]
    func scopeSummary(scope: DeckScope, asOf: Date) async throws -> ScopeSummary
    func itemRecordsPage(offset: Int, limit: Int) async throws -> [LibraryItemRecord]
}

public extension LibraryBrowsing {
    func cardMaturityDetails(itemID: UUID) async throws -> [CardMaturityDetail] { [] }
}

/// Item commands exposed as application operations, not persistence primitives.
public protocol LibraryItemMutating: Sendable {
    func createItem(_ item: Item, asOf: Date) async throws -> SavedItemSummary
    func updateItem(_ item: Item, asOf: Date) async throws -> SavedItemSummary
    func deleteItem(id: UUID, asOf: Date) async throws -> Bool
    func deleteAllUnassignedItems(asOf: Date) async throws -> Int
    func moveItem(id: UUID, to deckID: UUID?) async throws -> Bool
    func acknowledgeRepeatedLapses(itemIDs: Set<UUID>, asOf: Date) async throws -> Int
    func performBulkItemOperations(_ operations: [ItemBulkOperation], asOf: Date) async throws -> [ItemBulkOperationResult]
    func reserveMedia(data: Data, kind: MediaKind, altText: String, asOf: Date) async throws -> ReservedMediaAsset
}

/// Narrow capability for workflows that must extend an item type and rewrite
/// its dependent items as one atomic, history-preserving transaction.
public protocol LibraryCoordinatedItemEditing: Sendable {
    func deleteUnchangedUnreviewedItems(
        _ expectedItems: [Item],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult]
    func reconcileItemTypeAndItems(
        expectedItemType: ItemType,
        updatedItemType: ItemType,
        replacements: [Item],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult]
    func reconcileOrderedDeckItems(
        _ operations: [ItemBulkOperation],
        order: OrderedDeckItemReconciliation,
        asOf: Date
    ) async throws -> [ItemBulkOperationResult]
}

public protocol LibraryDeckManaging: Sendable {
    func deck(id: UUID) async throws -> Deck
    func deckSummaries(asOf: Date) async throws -> [DeckSummary]
    func createDeck(_ deck: Deck) async throws -> Deck
    func updateDeck(_ deck: Deck) async throws -> Deck
    func moveDeck(id: UUID, to destination: DeckMoveDestination) async throws -> Bool
    func deleteDeck(id: UUID) async throws -> Bool
    func resetDeckProgress(id: UUID, asOf: Date) async throws -> Int
    func deckDeletionImpact(id: UUID, policy: DeckDeletionPolicy) async throws -> DeckDeletionImpact
    func commitDeckDeletion(id: UUID, policy: DeckDeletionPolicy, asOf: Date) async throws
    func deckResetImpact(id: UUID) async throws -> DeckResetImpact
}

public protocol LibraryItemTypeManaging: Sendable {
    func createItemType(_ type: ItemType, deckID: UUID?, availableEverywhere: Bool) async throws -> ItemType
    func attachItemType(id: UUID, to deckID: UUID) async throws
    func setDeckItemTypes(_ settings: DeckItemTypeSettings) async throws
    func setItemTypeAvailability(id: UUID, availableEverywhere: Bool) async throws
    func createItemType(_ itemType: ItemType) async throws -> ItemType
    func updateItemType(_ itemType: ItemType, asOf: Date) async throws -> ItemType
    func duplicateItemType(id: UUID, name: String) async throws -> ItemType
    func repairItemTypeDefinition(id: UUID, asOf: Date) async throws -> ItemType
    func countItems(itemTypeID: UUID) async throws -> Int
    func deleteItemType(id: UUID) async throws -> Bool
}

public protocol LibraryItemTypeEditingSafeguarding: Sendable {
    func itemTypeEditingImpact(id: UUID) async throws -> ItemTypeEditingImpact
    func unlockItemType(id: UUID) async throws -> ItemType
    func itemTypeSchemaChangeImpact(
        from existing: ItemType,
        to updated: ItemType
    ) async throws -> ItemTypeSchemaChangeImpact
}

/// Atomic, transaction-bound persistence capability used only by Item Type
/// Studio. Kept separate from the historical editing-safeguard contract so
/// existing repository conformers remain source-compatible.
public protocol LibraryItemTypeStudioSaving: Sendable {
    func prepareItemTypeUpdateAuthorization(
        from existing: ItemType,
        to updated: ItemType
    ) async throws -> ItemTypeUpdateAuthorization
    func updateItemType(
        _ itemType: ItemType,
        authorization: ItemTypeUpdateAuthorization,
        asOf: Date
    ) async throws -> ItemType
}

public protocol LibraryStudying: Sendable {
    func dueCount(scope: DeckScope, asOf: Date) async throws -> Int
    func dueCards(scope: DeckScope, asOf: Date, limit: Int?) async throws -> [DueCard]
    /// Revalidates a queued introduction against current family exposure and limits.
    func isNewStudyCardEligible(cardID: UUID, scope: DeckScope, asOf: Date) async throws -> Bool
    func submitReview(
        cardID: UUID,
        rating: ReviewRating,
        asOf: Date,
        durationMilliseconds: Int
    ) async throws -> ReviewSubmission
    func revertReview(id: UUID, asOf: Date) async throws
    /// Computes all four outcomes against one instant without recording a review.
    func reviewSchedulePreviews(
        cardID: UUID,
        asOf: Date
    ) async throws -> [ReviewRating: ReviewSchedulePreview]
}

/// A presentation-safe projection of one possible review answer.
public struct ReviewSchedulePreview: Sendable, Equatable {
    public let rating: ReviewRating
    public let reviewedAt: Date
    public let memoryBefore: MemoryState
    public let memoryAfter: MemoryState
    public let predictedRetrievability: Double
    public let rawIntervalDays: Double
    public let operationalIntervalSeconds: Int
    public let presetID: UUID?
    public let cohortID: UUID?
    public let parameterSetID: UUID?
    public let modelVersion: String
    public let timingPolicyVersion: String
    public let intervalPolicyVersion: String
    public let finalDueAt: Date
    public let constraintReason: String?

    public init(_ value: ReviewSchedulePreviewDetail, reviewedAt: Date) {
        rating = value.rating
        self.reviewedAt = reviewedAt
        memoryBefore = value.memoryBefore
        memoryAfter = value.memoryAfter
        predictedRetrievability = value.predictedRetrievability
        rawIntervalDays = value.rawIntervalDays
        operationalIntervalSeconds = value.operationalIntervalSeconds
        presetID = value.presetID
        cohortID = value.cohortID
        parameterSetID = value.parameterSetID
        modelVersion = value.modelVersion
        timingPolicyVersion = value.timingPolicyVersion
        intervalPolicyVersion = value.intervalPolicyVersion
        finalDueAt = value.finalDueAt
        constraintReason = value.constraintReason
    }

    /// Compatibility initializer for lightweight repository doubles. Production
    /// repositories use the Core detailed-preview projection above.
    public init(rating: ReviewRating, reviewedAt: Date, memory: MemoryState) {
        self.rating = rating
        self.reviewedAt = reviewedAt
        memoryBefore = memory
        memoryAfter = memory
        predictedRetrievability = 1
        rawIntervalDays = max(0, memory.due.timeIntervalSince(reviewedAt) / 86_400)
        operationalIntervalSeconds = max(0, Int(ceil(memory.due.timeIntervalSince(reviewedAt))))
        presetID = nil
        cohortID = nil
        parameterSetID = nil
        modelVersion = "unavailable"
        timingPolicyVersion = FSRSScheduler.elapsedPolicyIdentifier
        intervalPolicyVersion = "continuous-due-v1"
        finalDueAt = memory.due
        constraintReason = rating == .again ? "immediate-repair-v1" : nil
    }

    /// Backwards-compatible presentation alias.
    public var memory: MemoryState { memoryAfter }

    public var intervalSeconds: TimeInterval {
        TimeInterval(operationalIntervalSeconds)
    }
}

/// Persistent, local-only learner audio responses. Kept separate from graded
/// study operations so feature code cannot accidentally manufacture reviews.
public protocol LibraryStudyResponses: Sendable {
    func completeAudioSubmission(
        _ draft: StudyResponseDraft,
        submittedAt: Date
    ) async throws -> StudyResponse
    func studyResponses(matching query: StudyResponseQuery) async throws -> [StudyResponse]
    func studyResponse(id: UUID) async throws -> StudyResponse
    func studyResponseMediaBytes(id: UUID) async throws -> (StudyResponse, MediaAsset, Data)
    func deleteStudyResponse(id: UUID, asOf: Date) async throws -> Bool
    func ordinaryMediaReferenceCount(hash: String) async throws -> Int
    func isStudyResponseMediaHash(_ hash: String) async throws -> Bool
    func studyResponseCount(cardIDs: Set<UUID>) async throws -> Int
    func studyResponseCount(itemIDs: Set<UUID>) async throws -> Int
    func studyResponseCount(templateIDs: Set<UUID>) async throws -> Int
}

public protocol LibraryScheduling: Sendable {
    func studyDayRolloverMinutes() async throws -> Int
    func setStudyDayRolloverMinutes(_ minutes: Int) async throws
    func requestAutomaticSchedulingMaintenance(asOf: Date) async
    func schedulingHealthSnapshot() async throws -> LibrarySchedulingHealth
    func fsrsParameterSetHistory() async throws -> [LibraryFSRSParameterSet]
    func fsrsOptimizationRunHistory(limit: Int?) async throws -> [LibraryFSRSOptimizationRun]
}

public struct LibrarySchedulingHealth: Sendable, Equatable {
    public let modelIdentifier: String
    public let desiredRetention: Double
    public let maximumIntervalDays: Int
    public let automaticOptimizationEnabled: Bool
    public let parameterCount: Int
    public let usesPopulationDefaults: Bool
    public let activeParameterSetID: UUID?
    public let activeParameterSource: String?
    public let optimizerParityVerified: Bool
    public let lastOptimizationDecision: String?
    public let lastOptimizationReason: String?
    public let lastOptimizationCompletedAt: Date?
    public let migrationStatus: String?
    public let legacyParametersQuarantined: Bool
    public let cohortCount: Int
    public let personalizedCohortCount: Int
    public let inheritedCohortCount: Int
    public let pendingMaintenance: Bool
    public let lastMaintenanceAt: Date?

    public var optimizerStatus: String {
        if !optimizerParityVerified { return "parityVerificationPending" }
        return lastOptimizationDecision ?? "notRun"
    }

    public init(
        modelIdentifier: String,
        desiredRetention: Double,
        maximumIntervalDays: Int,
        automaticOptimizationEnabled: Bool,
        parameterCount: Int,
        usesPopulationDefaults: Bool,
        activeParameterSetID: UUID? = nil,
        activeParameterSource: String? = nil,
        optimizerParityVerified: Bool = false,
        lastOptimizationDecision: String? = nil,
        lastOptimizationReason: String? = nil,
        lastOptimizationCompletedAt: Date? = nil,
        migrationStatus: String? = nil,
        legacyParametersQuarantined: Bool = false,
        cohortCount: Int = 1,
        personalizedCohortCount: Int = 0,
        inheritedCohortCount: Int = 0,
        pendingMaintenance: Bool = false,
        lastMaintenanceAt: Date? = nil
    ) {
        self.modelIdentifier = modelIdentifier
        self.desiredRetention = desiredRetention
        self.maximumIntervalDays = maximumIntervalDays
        self.automaticOptimizationEnabled = automaticOptimizationEnabled
        self.parameterCount = parameterCount
        self.usesPopulationDefaults = usesPopulationDefaults
        self.activeParameterSetID = activeParameterSetID
        self.activeParameterSource = activeParameterSource
        self.optimizerParityVerified = optimizerParityVerified
        self.lastOptimizationDecision = lastOptimizationDecision
        self.lastOptimizationReason = lastOptimizationReason
        self.lastOptimizationCompletedAt = lastOptimizationCompletedAt
        self.migrationStatus = migrationStatus
        self.legacyParametersQuarantined = legacyParametersQuarantined
        self.cohortCount = cohortCount
        self.personalizedCohortCount = personalizedCohortCount
        self.inheritedCohortCount = inheritedCohortCount
        self.pendingMaintenance = pendingMaintenance
        self.lastMaintenanceAt = lastMaintenanceAt
    }
}

public struct LibraryFSRSParameterSet: Sendable, Equatable, Identifiable {
    public let id: UUID
    public let isActive: Bool
    public let weights: [Double]
    public let modelVersion: String
    public let upstreamCommit: String
    public let sourceChecksum: String
    public let fixtureChecksum: String?
    public let scope: String
    public let cohortID: UUID?
    public let source: String
    public let inputFingerprint: String?
    public let trainingCutoff: Date?
    public let metrics: [String: Double]
    public let previousParameterSetID: UUID?
    public let createdAt: Date

    public init(_ value: FSRSParameterSet, isActive: Bool = false) {
        id = value.id
        self.isActive = isActive
        weights = value.weights
        modelVersion = value.modelVersion
        upstreamCommit = value.upstreamCommit
        sourceChecksum = value.sourceChecksum
        fixtureChecksum = value.fixtureChecksum
        scope = value.scope
        cohortID = value.cohortID
        source = value.source.rawValue
        inputFingerprint = value.inputFingerprint
        trainingCutoff = value.trainingCutoff
        metrics = value.metrics
        previousParameterSetID = value.previousParameterSetID
        createdAt = value.createdAt
    }
}

public struct LibraryFSRSOptimizationRun: Sendable, Equatable, Identifiable {
    public let id: UUID
    public let presetID: UUID
    public let cohortID: UUID?
    public let startedAt: Date
    public let completedAt: Date
    public let trainingCutoff: Date
    public let inputFingerprint: String
    public let eligibleTargetCount: Int
    public let distinctCardCount: Int
    public let failureCount: Int
    public let studyDayCount: Int
    public let excludedCounts: [String: Int]
    public let foldCount: Int
    public let metrics: [String: Double]
    public let decision: String
    public let reason: String?
    public let candidateParameterSetID: UUID?

    public init(_ value: FSRSOptimizationRun) {
        id = value.id
        presetID = value.presetID
        cohortID = value.cohortID
        startedAt = value.startedAt
        completedAt = value.completedAt
        trainingCutoff = value.trainingCutoff
        inputFingerprint = value.inputFingerprint
        eligibleTargetCount = value.eligibleTargetCount
        distinctCardCount = value.distinctCardCount
        failureCount = value.failureCount
        studyDayCount = value.studyDayCount
        excludedCounts = value.excludedCounts
        foldCount = value.foldCount
        metrics = value.metrics
        decision = value.decision.rawValue
        reason = value.reason
        candidateParameterSetID = value.candidateParameterSetID
    }
}

/// High-level import operations keep parser and persistence details behind the boundary.
public protocol LibraryImporting: Sendable {
    func importJSONItems(
        from data: Data,
        itemTypeID: UUID?,
        context: ImportContext,
        asOf: Date
    ) async throws -> [SavedItemSummary]
    func importCSVItems(
        from data: Data,
        itemTypeID: UUID?,
        itemTypeName: String,
        context: ImportContext,
        asOf: Date
    ) async throws -> [SavedItemSummary]
}

/// Portable formats are workflows. Callers should not need access to the database actor.
public protocol LibraryTransferring: Sendable {
    func importPortableDeck(
        from source: URL,
        conflictResolution: PortableDeckTypeConflictResolution
    ) async throws -> PortableDeckImportResult
    func importAuthoredDeck(from source: URL) async throws -> PortableDeckImportResult
    func importAuthoredItems(from source: URL, into deckID: UUID) async throws -> PortableDeckImportResult
    func exportPortableDeck(id: UUID, to destination: URL) async throws
}

public protocol LibraryChangePersisting: Sendable {
    func changeNotifications() async -> AsyncStream<Int64>
    func currentChangeCursor() async throws -> Int64
    func changes(after cursor: Int64, limit: Int) async throws -> [LibraryChange]
    func createBackup(at destination: URL) async throws
    func verifyBackup(at destination: URL) async throws
}

public extension LibraryChangePersisting {
    func changeNotifications() async -> AsyncStream<Int64> { AsyncStream { $0.finish() } }
    func verifyBackup(at destination: URL) async throws {
        let values = try destination.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard values.isRegularFile == true, (values.fileSize ?? 0) > 0 else {
            throw CocoaError(.fileReadCorruptFile)
        }
    }
}

/// Complete native-client boundary. Feature models should request the smallest
/// constituent capability they need; the composition root owns this aggregate.
public protocol LibraryRepository:
    LibraryBootstrapping,
    LibraryBrowsing,
    LibraryItemMutating,
    LibraryCoordinatedItemEditing,
    LibraryDeckManaging,
    LibraryItemTypeManaging,
    LibraryStudying,
    LibraryStudyResponses,
    LibraryScheduling,
    LibraryImporting,
    LibraryTransferring,
    LibraryChangePersisting
{}

public extension LibraryCoordinatedItemEditing {
    func deleteUnchangedUnreviewedItems(
        _: [Item],
        asOf _: Date
    ) async throws -> [ItemBulkOperationResult] {
        // A fallback made from separate reads and deletes would be unsafe.
        throw DatabaseError.invalidItem("This library cannot safely undo an added batch. Manage its items in the library instead.")
    }

    func reconcileItemTypeAndItems(
        expectedItemType _: ItemType,
        updatedItemType _: ItemType,
        replacements _: [Item],
        asOf _: Date
    ) async throws -> [ItemBulkOperationResult] {
        throw DatabaseError.invalidItem(
            "This library does not support atomic item reconciliation."
        )
    }

    func reconcileOrderedDeckItems(
        _: [ItemBulkOperation],
        order _: OrderedDeckItemReconciliation,
        asOf _: Date
    ) async throws -> [ItemBulkOperationResult] {
        throw DatabaseError.invalidItem("This library does not support ordered deck reconciliation.")
    }
}

/// Debug fixture operations used to seed deterministic UI scenarios without
/// giving the executable direct access to the persistence actor.
public protocol LibraryScenarioSeeding: LibraryRepository {
    func corruptItemTypeDefinitionForTesting(id: UUID) async throws
}

// MARK: - Convenience defaults

public extension LibraryBrowsing {
    func listItems(
        scope: DeckScope = .allDecks,
        sort: ItemSortOrder = .createdAscending,
        search: String = ""
    ) async throws -> [SavedItemSummary] {
        try await items(scope: scope, sort: sort, search: search)
    }

    func fetchItem(id: UUID) async throws -> (item: Item, itemType: ItemType)? {
        try await item(id: id)
    }

    func items(
        scope: DeckScope = .allDecks,
        sort: ItemSortOrder = .createdAscending,
        search: String = ""
    ) async throws -> [SavedItemSummary] {
        try await items(scope: scope, sort: sort, search: search)
    }

    func scopeSummary(
        scope: DeckScope = .allDecks,
        asOf: Date = .now
    ) async throws -> ScopeSummary {
        try await scopeSummary(scope: scope, asOf: asOf)
    }
}

public extension LibraryItemMutating {
    func createItem(_ item: Item, asOf: Date = .now) async throws -> SavedItemSummary {
        try await createItem(item, asOf: asOf)
    }

    func updateItem(_ item: Item, asOf: Date = .now) async throws -> SavedItemSummary {
        try await updateItem(item, asOf: asOf)
    }

    func deleteItem(id: UUID, asOf: Date = .now) async throws -> Bool {
        try await deleteItem(id: id, asOf: asOf)
    }

    func deleteAllUnassignedItems(asOf: Date = .now) async throws -> Int {
        try await deleteAllUnassignedItems(asOf: asOf)
    }

    func acknowledgeRepeatedLapses(
        itemIDs: Set<UUID>,
        asOf: Date = .now
    ) async throws -> Int {
        try await acknowledgeRepeatedLapses(itemIDs: itemIDs, asOf: asOf)
    }
}

public extension LibraryDeckManaging {
    func deckSummaries(asOf: Date = .now) async throws -> [DeckSummary] {
        try await deckSummaries(asOf: asOf)
    }

    func resetDeckProgress(id: UUID, asOf: Date = .now) async throws -> Int {
        try await resetDeckProgress(id: id, asOf: asOf)
    }
}

public extension LibraryItemTypeManaging {
    func updateItemType(_ itemType: ItemType, asOf: Date = .now) async throws -> ItemType {
        try await updateItemType(itemType, asOf: asOf)
    }

    func repairItemTypeDefinition(id: UUID, asOf: Date = .now) async throws -> ItemType {
        try await repairItemTypeDefinition(id: id, asOf: asOf)
    }
}

public extension LibraryStudying {
    func isNewStudyCardEligible(cardID: UUID, scope: DeckScope, asOf: Date) async throws -> Bool {
        try await dueCards(scope: scope, asOf: asOf, limit: nil).contains { $0.id == cardID }
    }

    func dueCards(
        scope: DeckScope,
        asOf: Date,
        limit: Int? = nil
    ) async throws -> [DueCard] {
        try await dueCards(scope: scope, asOf: asOf, limit: limit)
    }

    func reviewSchedulePreviews(
        cardID: UUID,
        asOf: Date
    ) async throws -> [ReviewRating: ReviewSchedulePreview] {
        [:]
    }
}

public extension LibraryStudyResponses {
    func completeAudioSubmission(
        _ draft: StudyResponseDraft,
        submittedAt: Date = .now
    ) async throws -> StudyResponse {
        try await completeAudioSubmission(draft, submittedAt: submittedAt)
    }

    func studyResponses(
        matching query: StudyResponseQuery = StudyResponseQuery()
    ) async throws -> [StudyResponse] {
        try await studyResponses(matching: query)
    }

    func deleteStudyResponse(id: UUID, asOf: Date = .now) async throws -> Bool {
        try await deleteStudyResponse(id: id, asOf: asOf)
    }
}

public extension LibraryScheduling {
    func requestAutomaticSchedulingMaintenance(asOf: Date = .now) async {}

    func schedulingHealthSnapshot() async throws -> LibrarySchedulingHealth {
        LibrarySchedulingHealth(
            modelIdentifier: "Unavailable",
            desiredRetention: SchedulerPersistenceConstants.desiredRetention,
            maximumIntervalDays: SchedulerPersistenceConstants.maximumIntervalDays,
            automaticOptimizationEnabled: false,
            parameterCount: 0,
            usesPopulationDefaults: true
        )
    }

    func fsrsParameterSetHistory() async throws -> [LibraryFSRSParameterSet] { [] }

    func fsrsOptimizationRunHistory(limit: Int? = nil) async throws -> [LibraryFSRSOptimizationRun] {
        []
    }
}

// MARK: - SQLite adapter

/// The sole production adapter that knows `ItemStore`. Presentation, API, and
/// synchronization code receive application capabilities instead of the store.
public actor SQLiteLibraryRepository:
    LibraryRepository,
    LibraryCoordinatedItemEditing,
    LibraryItemTypeEditingSafeguarding,
    LibraryItemTypeStudioSaving
{
    let store: ItemStore

    public init(databaseURL: URL, profileID: String = "default") throws {
        store = try ItemStore(databaseURL: databaseURL, profileID: profileID)
    }

    /// Kept for migration and test composition. The wrapped store never escapes.
    public init(store: ItemStore) {
        self.store = store
    }

    public func bootstrap() async throws { try await store.bootstrap() }

    public func coldHomeSnapshot(
        scope: DeckScope,
        asOf: Date
    ) async throws -> ColdLibraryHomeSnapshot {
        try await store.coldLibraryHomeSnapshot(scope: scope, asOf: asOf)
    }

    public func mediaStore() async -> MediaStore? { await store.media }

    public func libraryID() async throws -> UUID { try await store.libraryID() }
    public func loadItemTypes() async throws -> ItemTypeLoadResult { try await store.loadItemTypes() }
    public func loadItemTypeCatalog() async throws -> ItemTypeCatalog {
        try await store.loadItemTypeCatalog()
    }
    public func effectiveItemTypePolicy(for deckID: UUID) async throws -> DeckItemTypePolicy? {
        try await store.effectiveItemTypePolicy(for: deckID)
    }
    public func items(
        scope: DeckScope,
        sort: ItemSortOrder,
        search: String
    ) async throws -> [SavedItemSummary] {
        try await store.listItems(scope: scope, sort: sort, search: search)
    }
    public func item(id: UUID) async throws -> (item: Item, itemType: ItemType)? {
        try await store.fetchItem(id: id)
    }
    public func cardMaturityDetails(itemID: UUID) async throws -> [CardMaturityDetail] {
        try await store.cardMaturityDetails(itemID: itemID)
    }
    public func itemBrowseSchedules(itemIDs: [UUID]) async throws -> [UUID: ItemBrowseSchedule] {
        try await store.fetchItemBrowseSchedules(itemIDs: itemIDs)
    }
    public func scopeSummary(scope: DeckScope, asOf: Date) async throws -> ScopeSummary {
        try await store.scopeSummary(scope: scope, asOf: asOf)
    }

    public func createItem(_ item: Item, asOf: Date) async throws -> SavedItemSummary {
        try await store.createItem(item, now: asOf)
    }
    public func updateItem(_ item: Item, asOf: Date) async throws -> SavedItemSummary {
        try await store.updateItem(item, now: asOf)
    }
    public func reconcileItemTypeAndItems(
        expectedItemType: ItemType,
        updatedItemType: ItemType,
        replacements: [Item],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        try await store.reconcileItemTypeAndItems(
            expectedItemType: expectedItemType,
            updatedItemType: updatedItemType,
            replacements: replacements,
            now: asOf
        )
    }
    public func reconcileOrderedDeckItems(
        _ operations: [ItemBulkOperation],
        order: OrderedDeckItemReconciliation,
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        try await store.reconcileOrderedDeckItems(operations, order: order, now: asOf)
    }
    public func deleteUnchangedUnreviewedItems(
        _ expectedItems: [Item],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        try await store.deleteUnchangedUnreviewedItems(expectedItems, now: asOf)
    }
    public func deleteItem(id: UUID, asOf: Date) async throws -> Bool {
        try await store.deleteItem(id: id, now: asOf)
    }
    public func deleteAllUnassignedItems(asOf: Date) async throws -> Int {
        try await store.deleteAllUnassignedItems(now: asOf)
    }
    public func moveItem(id: UUID, to deckID: UUID?) async throws -> Bool {
        try await store.updateItemDeck(itemID: id, deckID: deckID)
    }
    public func acknowledgeRepeatedLapses(
        itemIDs: Set<UUID>,
        asOf: Date
    ) async throws -> Int {
        try await store.acknowledgeRepeatedLapses(itemIDs: itemIDs, asOf: asOf)
    }
    public func performBulkItemOperations(
        _ operations: [ItemBulkOperation],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        try await store.executeItemBulk(operations, dryRun: false, now: asOf)
    }
    public func reserveMedia(
        data: Data,
        kind: MediaKind,
        altText: String,
        asOf: Date
    ) async throws -> ReservedMediaAsset {
        try await store.reserveMedia(data: data, kind: kind, altText: altText, now: asOf)
    }

    public func deck(id: UUID) async throws -> Deck { try await store.deck(id: id) }
    public func deckSummaries(asOf: Date) async throws -> [DeckSummary] {
        try await store.deckSummaries(asOf: asOf)
    }
    public func createDeck(_ deck: Deck) async throws -> Deck { try await store.createDeck(deck) }
    public func updateDeck(_ deck: Deck) async throws -> Deck { try await store.updateDeck(deck) }
    public func moveDeck(id: UUID, to destination: DeckMoveDestination) async throws -> Bool {
        try await store.moveDeck(id: id, to: destination)
    }
    public func deleteDeck(id: UUID) async throws -> Bool { try await store.deleteDeck(id: id) }
    public func resetDeckProgress(id: UUID, asOf: Date) async throws -> Int {
        try await store.resetDeckProgress(id: id, now: asOf)
    }

    public func authoringItemTypes(for deckID: UUID?) async throws -> AuthoringItemTypes { try await store.authoringItemTypes(for: deckID) }
    public func createItemType(_ type: ItemType, deckID: UUID?, availableEverywhere: Bool) async throws -> ItemType {
        try await store.createItemType(type, deckID: deckID, availableEverywhere: availableEverywhere)
    }
    public func attachItemType(id: UUID, to deckID: UUID) async throws { try await store.attachItemType(id: id, to: deckID) }
    public func setDeckItemTypes(_ settings: DeckItemTypeSettings) async throws { try await store.setDeckItemTypes(settings) }
    public func setItemTypeAvailability(id: UUID, availableEverywhere: Bool) async throws { try await store.setItemTypeAvailability(id: id, availableEverywhere: availableEverywhere) }

    public func createItemType(_ itemType: ItemType) async throws -> ItemType {
        try await store.createItemType(itemType)
    }
    public func updateItemType(_ itemType: ItemType, asOf: Date) async throws -> ItemType {
        try await store.updateItemType(itemType, now: asOf)
    }
    public func updateItemType(
        _ itemType: ItemType,
        authorization: ItemTypeUpdateAuthorization,
        asOf: Date
    ) async throws -> ItemType {
        try await store.updateItemType(itemType, authorization: authorization, now: asOf)
    }
    public func duplicateItemType(id: UUID, name: String) async throws -> ItemType {
        try await store.duplicateItemType(id: id, name: name)
    }
    public func itemTypeEditingImpact(id: UUID) async throws -> ItemTypeEditingImpact {
        try await store.itemTypeEditingImpact(id: id)
    }
    public func unlockItemType(id: UUID) async throws -> ItemType {
        try await store.unlockItemType(id: id)
    }
    public func itemTypeSchemaChangeImpact(
        from existing: ItemType,
        to updated: ItemType
    ) async throws -> ItemTypeSchemaChangeImpact {
        try await store.itemTypeSchemaChangeImpact(from: existing, to: updated)
    }
    public func prepareItemTypeUpdateAuthorization(
        from existing: ItemType,
        to updated: ItemType
    ) async throws -> ItemTypeUpdateAuthorization {
        try await store.prepareItemTypeUpdateAuthorization(from: existing, to: updated)
    }
    public func repairItemTypeDefinition(id: UUID, asOf: Date) async throws -> ItemType {
        try await store.repairItemTypeDefinition(id: id, now: asOf)
    }
    public func countItems(itemTypeID: UUID) async throws -> Int {
        try await store.countItems(itemTypeID: itemTypeID)
    }
    public func deleteItemType(id: UUID) async throws -> Bool {
        try await store.deleteItemType(id: id)
    }

    public func dueCount(scope: DeckScope, asOf: Date) async throws -> Int {
        try await store.dueCount(scope: scope, asOf: asOf)
    }
    public func dueCards(
        scope: DeckScope,
        asOf: Date,
        limit: Int?
    ) async throws -> [DueCard] {
        try await store.fetchDueCards(scope: scope, asOf: asOf, limit: limit)
    }
    public func isNewStudyCardEligible(cardID: UUID, scope: DeckScope, asOf: Date) async throws -> Bool {
        try await store.isNewStudyCardEligible(cardID: cardID, scope: scope, asOf: asOf)
    }

    public func submitReview(
        cardID: UUID,
        rating: ReviewRating,
        asOf: Date,
        durationMilliseconds: Int
    ) async throws -> ReviewSubmission {
        try await store.submitReviewWithReceipt(
            cardID: cardID,
            rating: rating,
            now: asOf,
            durationMs: durationMilliseconds
        )
    }

    public func reviewSchedulePreviews(
        cardID: UUID,
        asOf: Date
    ) async throws -> [ReviewRating: ReviewSchedulePreview] {
        let details = try await store.reviewPreviewDetails(cardID: cardID, now: asOf)
        return Dictionary(uniqueKeysWithValues: details.map { rating, detail in
            (rating, ReviewSchedulePreview(detail, reviewedAt: asOf))
        })
    }

    public func completeAudioSubmission(
        _ draft: StudyResponseDraft,
        submittedAt: Date
    ) async throws -> StudyResponse {
        try await store.completeAudioSubmission(draft, submittedAt: submittedAt)
    }

    public func studyResponses(matching query: StudyResponseQuery) async throws -> [StudyResponse] {
        try await store.studyResponses(matching: query)
    }

    public func studyResponse(id: UUID) async throws -> StudyResponse {
        try await store.studyResponse(id: id)
    }

    public func studyResponseMediaBytes(id: UUID) async throws -> (StudyResponse, MediaAsset, Data) {
        try await store.studyResponseMediaBytes(id: id)
    }

    public func deleteStudyResponse(id: UUID, asOf: Date) async throws -> Bool {
        try await store.deleteStudyResponse(id: id, asOf: asOf)
    }

    public func ordinaryMediaReferenceCount(hash: String) async throws -> Int {
        try await store.ordinaryMediaReferenceCount(hash: hash)
    }

    public func isStudyResponseMediaHash(_ hash: String) async throws -> Bool {
        try await store.isStudyResponseMediaHash(hash)
    }

    public func studyResponseCount(cardIDs: Set<UUID>) async throws -> Int {
        try await store.studyResponseCount(cardIDs: cardIDs)
    }

    public func studyResponseCount(itemIDs: Set<UUID>) async throws -> Int {
        try await store.studyResponseCount(itemIDs: itemIDs)
    }

    public func studyResponseCount(templateIDs: Set<UUID>) async throws -> Int {
        try await store.studyResponseCount(templateIDs: templateIDs)
    }

    public func revertReview(id: UUID, asOf: Date) async throws {
        try await store.revertReview(reviewLogID: id, now: asOf)
    }

    public func studyDayRolloverMinutes() async throws -> Int {
        try await store.studyDayRolloverMinutes()
    }
    public func setStudyDayRolloverMinutes(_ minutes: Int) async throws {
        try await store.setStudyDayRolloverMinutes(minutes)
    }
    public func requestAutomaticSchedulingMaintenance(asOf: Date) async {
        await store.requestAutomaticSchedulingMaintenance(after: 0)
    }
    public func schedulingHealthSnapshot() async throws -> LibrarySchedulingHealth {
        let snapshot = try await store.schedulingHealthSnapshot()
        return LibrarySchedulingHealth(
            modelIdentifier: snapshot.activeModelVersion
                ?? SchedulerPersistenceConstants.memoryModelVersion,
            desiredRetention: snapshot.desiredRetention,
            maximumIntervalDays: snapshot.preset.maximumIntervalDays,
            automaticOptimizationEnabled: snapshot.automaticOptimizationEnabled,
            parameterCount: snapshot.activeParameterSet?.weights.count ?? 0,
            usesPopulationDefaults: snapshot.activeSource == .populationDefault,
            activeParameterSetID: snapshot.activeParameterSet?.id,
            activeParameterSource: snapshot.activeSource?.rawValue,
            optimizerParityVerified: snapshot.optimizerParityVerified,
            lastOptimizationDecision: snapshot.lastOptimizationRun?.decision.rawValue,
            lastOptimizationReason: snapshot.lastOptimizationRun?.reason,
            lastOptimizationCompletedAt: snapshot.lastOptimizationRun?.completedAt,
            migrationStatus: snapshot.latestMigration?.status.rawValue,
            legacyParametersQuarantined: snapshot.legacyParametersQuarantined,
            cohortCount: snapshot.cohortCount,
            personalizedCohortCount: snapshot.personalizedCohortCount,
            inheritedCohortCount: snapshot.inheritedCohortCount,
            pendingMaintenance: snapshot.pendingMaintenance,
            lastMaintenanceAt: snapshot.lastMaintenanceAt
        )
    }
    public func fsrsParameterSetHistory() async throws -> [LibraryFSRSParameterSet] {
        let activeIDs = Set(try await store.schedulerCohorts().compactMap(\.activeParameterSetID))
        return try await store.fsrsParameterSets().map {
            LibraryFSRSParameterSet($0, isActive: activeIDs.contains($0.id))
        }
    }
    public func fsrsOptimizationRunHistory(
        limit: Int?
    ) async throws -> [LibraryFSRSOptimizationRun] {
        try await store.fsrsOptimizationRuns(limit: limit).map(LibraryFSRSOptimizationRun.init)
    }

    public func importJSONItems(
        from data: Data,
        itemTypeID: UUID?,
        context: ImportContext,
        asOf: Date
    ) async throws -> [SavedItemSummary] {
        try await store.importItemSummaries(
            from: data,
            adapter: JSONImportAdapter(),
            itemTypeID: itemTypeID,
            context: context,
            now: asOf
        )
    }
    public func importCSVItems(
        from data: Data,
        itemTypeID: UUID?,
        itemTypeName: String,
        context: ImportContext,
        asOf: Date
    ) async throws -> [SavedItemSummary] {
        try await store.importItemSummaries(
            from: data,
            adapter: CSVImportAdapter(itemTypeName: itemTypeName),
            itemTypeID: itemTypeID,
            context: context,
            now: asOf
        )
    }

    public func importPortableDeck(
        from source: URL,
        conflictResolution: PortableDeckTypeConflictResolution
    ) async throws -> PortableDeckImportResult {
        try await PortableDeck.importDeck(
            from: source,
            into: store,
            conflictResolution: conflictResolution
        )
    }
    public func importAuthoredDeck(from source: URL) async throws -> PortableDeckImportResult {
        try await AuthoredDeck.importDeck(from: source, into: store)
    }
    public func importAuthoredItems(
        from source: URL,
        into deckID: UUID
    ) async throws -> PortableDeckImportResult {
        try await AuthoredDeck.importItems(from: source, into: store, deckID: deckID)
    }
    public func exportPortableDeck(id: UUID, to destination: URL) async throws {
        try await PortableDeck.export(deckID: id, from: store, to: destination)
    }

    public func currentChangeCursor() async throws -> Int64 {
        try await store.currentChangeCursor()
    }
    public func changeNotifications() async -> AsyncStream<Int64> {
        await store.libraryChangeNotifications()
    }
    public func recordLibraryAlias(_ aliasID: UUID, canonicalID: UUID) async throws {
        try await store.recordLibraryAlias(aliasID, canonicalID: canonicalID)
    }
    public func libraryAliases(canonicalID: UUID) async throws -> Set<UUID> {
        try await store.libraryAliases(canonicalID: canonicalID)
    }
    public func changes(after cursor: Int64, limit: Int) async throws -> [LibraryChange] {
        try await store.libraryChanges(after: cursor, limit: limit)
    }
    public func resourceRevisionSnapshot() async throws -> [LibraryResourceRevision] {
        try await store.resourceRevisionSnapshot()
    }
    public func recordSyncItemTypeAlias(remoteID: UUID, localID: UUID) async throws {
        try await store.recordSyncItemTypeAlias(remoteID: remoteID, localID: localID)
    }
    public func syncItemTypeAliases() async throws -> [UUID: UUID] {
        try await store.syncItemTypeAliases()
    }
    public func createBackup(at destination: URL) async throws {
        try await store.createValidationDatabaseSnapshot(at: destination)
    }

    public func applySynchronizedCard(_ card: Card) async throws { try await store.applySynchronizedCard(card) }
    public func applySynchronizedReview(_ log: ReviewLog) async throws { try await store.applySynchronizedReview(log) }
    public func synchronizedReviewRecord(id: UUID) async throws -> SynchronizedReviewRecord {
        try await store.synchronizedReviewRecord(id: id)
    }
    public func synchronizedItemRecord(id: UUID) async throws -> SynchronizedItemRecord {
        try await store.synchronizedItemRecord(id: id)
    }
    public func reviewRevertRecord(id: UUID) async throws -> ReviewRevertRecord {
        try await store.reviewRevertRecord(id: id)
    }
    public func itemTypeMembershipRecord(id: String) async throws -> ItemTypeMembershipRecord {
        try await store.itemTypeMembershipRecord(id: id)
    }
    public func schedulingSettingsRecord(id: String) async throws -> SchedulingSettingsRecord {
        try await store.schedulingSettingsRecord(id: id)
    }
    public func portableItemTypeMappingRecord(id: String) async throws -> PortableItemTypeMappingRecord {
        try await store.portableItemTypeMappingRecord(id: id)
    }
    public func applySynchronizedBatch(_ mutations: [SynchronizedLibraryMutation]) async throws {
        for mutation in mutations {
            switch mutation {
            case let .itemType(type): try ItemTypeValidation.validate(type)
            case let .deck(deck):
                guard deck.newCardsPerDay.map({ $0 >= 0 }) ?? true else {
                    throw DatabaseError.invalidDeck("Daily new-card limit cannot be negative.")
                }
            default: break
            }
        }
        try await store.applySynchronizedBatch(mutations)
    }

    public func verifyBackup(at destination: URL) async throws {
        let verification = try SQLiteLibraryRepository(databaseURL: destination)
        try await verification.bootstrap()
        _ = try await verification.libraryID()
    }
}

extension SQLiteLibraryRepository: LibraryScenarioSeeding {
    public func corruptItemTypeDefinitionForTesting(id: UUID) async throws {
        try await store.testingCorruptItemTypeDefinition(id: id)
    }
}


// Compatibility defaults for read-only/older repository implementations.
public extension LibraryBrowsing {
    func authoringItemTypes(for deckID: UUID?) async throws -> AuthoringItemTypes {
        let policy: DeckItemTypePolicy?
        if let deckID { policy = try await effectiveItemTypePolicy(for: deckID) } else { policy = nil }
        let catalog = try await loadItemTypeCatalog()
        let fallback = policy?.itemTypes.isEmpty != false
        let choices = fallback ? catalog.itemTypes : policy!.itemTypes
        return AuthoringItemTypes(deckID: deckID, sourceDeckID: policy?.sourceDeckID, itemTypes: choices,
            defaultItemTypeID: fallback ? choices.first { $0.id == BuiltInItemTypes.basicID }?.id : policy?.defaultItemTypeID,
            usesSharedFallback: fallback)
    }
}
public extension LibraryItemTypeManaging {
    func createItemType(_ type: ItemType, deckID: UUID?, availableEverywhere: Bool) async throws -> ItemType {
        let created = try await createItemType(type)
        if let deckID { try await attachItemType(id: created.id, to: deckID) }
        return created
    }
    func attachItemType(id: UUID, to deckID: UUID) async throws { throw DatabaseError.invalidItemType("This library does not support deck attachments.") }
    func setDeckItemTypes(_ settings: DeckItemTypeSettings) async throws { throw DatabaseError.invalidItemType("This library does not support deck type settings.") }
    func setItemTypeAvailability(id: UUID, availableEverywhere: Bool) async throws { throw DatabaseError.invalidItemType("This library does not support type availability settings.") }
}

extension SQLiteLibraryRepository: LibraryLearningTime {
    public func recordLearningTimeAliases(_ aliases: [LearningTimeItemAlias]) async throws { try await store.recordLearningTimeAliases(aliases) }
    public func learningTimeItemAliases() async throws -> [LearningTimeItemAlias] { try await store.learningTimeItemAliases() }
    public func learningTimeLibraryID() async throws -> UUID { try await store.libraryID() }
    public func recordLearningTime(_ segments: [LearningTimeSegment]) async throws { try await store.recordLearningTime(segments) }
    public func learningTimeSegments(after sequence: Int64, limit: Int) async throws -> [LearningTimeStoredSegment] {
        try await store.learningTimeSegments(after: sequence, limit: limit)
    }
    public func learningTimeNotifications() async -> AsyncStream<Void> { await store.learningTimeNotifications() }
    public func learningTimeSummary(scope: DeckScope, period: LearningTimePeriod, asOf: Date,
                                    calendar: Calendar) async throws -> LearningTimeSummary {
        try await store.learningTimeSummary(scope: scope, period: period, asOf: asOf, calendar: calendar)
    }
}
