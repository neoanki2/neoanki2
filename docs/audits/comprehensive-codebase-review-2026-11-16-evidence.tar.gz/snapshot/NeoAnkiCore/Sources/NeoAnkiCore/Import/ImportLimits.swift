import Foundation

public enum ImportLimits {
    public static let maxPayloadBytes = 5_000_000
    public static let maxRows = 10_000
    public static let maxFieldsPerRow = 256
    public static let maxFieldStringBytes = 32_768
    public static let maxFieldStringLength = maxFieldStringBytes

    public static func validatePayloadSize(_ data: Data) throws {
        guard data.count <= maxPayloadBytes else {
            throw ImportError.invalidFormat("Import file exceeds \(maxPayloadBytes / 1_000_000) MB limit.")
        }
    }

    public static func validateRowCount(_ count: Int) throws {
        guard count <= maxRows else {
            throw ImportError.invalidFormat("Import exceeds \(maxRows) row limit.")
        }
    }

    /// Validates decoded row shape and textual field payloads before any media
    /// resolution or persistence work begins.
    public static func validateDecodedPayload(_ payload: ImportPayload) throws {
        try validateRowCount(payload.rows.count)
        for row in payload.rows {
            let (fieldCount, overflowed) = row.fieldValues.count.addingReportingOverflow(
                row.structuredFields.count
            )
            guard !overflowed, fieldCount <= maxFieldsPerRow else {
                throw ImportError.invalidFormat(
                    "Import rows may contain at most \(maxFieldsPerRow) fields."
                )
            }
            for (name, value) in row.fieldValues {
                try validateFieldString(value, fieldName: name)
            }
            for (name, value) in row.structuredFields {
                switch value {
                case let .text(text), let .cloze(text, _), let .mediaPath(text):
                    try validateFieldString(text, fieldName: name)
                case let .imageOcclusion(path, alt, _, masks, _):
                    try validateFieldString(path, fieldName: name)
                    try validateFieldString(alt, fieldName: name)
                    for mask in masks { if let text = mask.answerText { try validateFieldString(text, fieldName: name) } }
                case let .mediaBase64(_, fileExtension, altText):
                    if let fileExtension {
                        try validateFieldString(fileExtension, fieldName: "\(name) file extension")
                    }
                    if let altText {
                        try validateFieldString(altText, fieldName: "\(name) alt text")
                    }
                }
            }
        }
    }

    public static func validateFieldString(_ value: String, fieldName: String) throws {
        guard value.utf8.count <= maxFieldStringBytes else {
            throw ImportError.invalidFormat("Field \"\(fieldName)\" exceeds maximum length.")
        }
    }

    public static func validateBase64EncodedSize(
        _ value: String,
        kind: MediaKind,
        fieldName: String
    ) throws {
        let maxEncodedBytes = ((MediaValidation.maxBytes(for: kind) + 2) / 3) * 4
        guard value.utf8.count <= maxEncodedBytes else {
            throw ImportError.invalidFormat("Media in field \"\(fieldName)\" exceeds its size limit.")
        }
    }
}

/// Structured JSON cell for non-scalar field values.
public enum StructuredFieldValue: Decodable, Sendable, Equatable {
    case text(String)
    case cloze(text: String, blanks: [ClozeSpan])
    case imageOcclusion(path: String, altText: String, mode: ImageOcclusionMode, masks: [ImageOcclusionMask], nextGroup: Int)
    case mediaPath(String)
    case mediaBase64(String, fileExtension: String?, altText: String?)

    private enum CodingKeys: String, CodingKey {
        case text, blanks, path, base64, fileExtension, altText, imageOcclusion
    }

    public init(from decoder: Decoder) throws {
        if let single = try? decoder.singleValueContainer(),
           let string = try? single.decode(String.self) {
            self = .text(string)
            return
        }

        let container = try decoder.container(keyedBy: CodingKeys.self)
        if container.contains(.imageOcclusion) {
            struct Input: Decodable {
                let path: String
                let altText: String
                let mode: ImageOcclusionMode
                let masks: [ImageOcclusionMask]
                let nextGroup: Int
            }
            let input = try container.decode(Input.self, forKey: .imageOcclusion)
            self = .imageOcclusion(path: input.path, altText: input.altText, mode: input.mode, masks: input.masks, nextGroup: input.nextGroup)
            return
        }
        if let path = try container.decodeIfPresent(String.self, forKey: .path) {
            self = .mediaPath(path)
            return
        }
        if let base64 = try container.decodeIfPresent(String.self, forKey: .base64) {
            self = .mediaBase64(
                base64,
                fileExtension: try container.decodeIfPresent(String.self, forKey: .fileExtension),
                altText: try container.decodeIfPresent(String.self, forKey: .altText)
            )
            return
        }

        let text = try container.decode(String.self, forKey: .text)
        let blanks = try container.decodeIfPresent([ClozeSpan].self, forKey: .blanks) ?? []
        if blanks.isEmpty {
            self = .text(text)
        } else {
            self = .cloze(text: text, blanks: blanks)
        }
    }
}
