# Independent simplification challenge

Reviewed decisive current files under `../snapshot/`, independently of the application agent's preference. No execution. All source citations below are paths relative to that pinned snapshot.

## Verdict

For **largest conceptual simplification**, I narrowly prefer the poem/prose typed native creation plan over the durable inbox handoff, conditional on implementing a shared validated plan and canonical compatibility exporter rather than adding another privileged import path. The inbox handoff is the clearest smaller improvement and the lower-risk first implementation. Native refresh consolidation is third on current evidence because a shared read/revision policy already exists; the remaining distinct presentation semantics are real.

The vocabulary-builder removal reduces typed creation to two families, so do not claim a three-builder payoff. Nor can this change delete existing editor reconciliation: those editors already use typed bulk operations and ordered snapshots.

All scores higher is favorable:

| Candidate | Impact | Confidence | Ease | Low introduced complexity | Migration favorable |
|---|---:|---:|---:|---:|---:|
| Typed poem/prose native creation plan + shared importer | 4 | 4 | 2 | 3 | 5 |
| Single durable inbox ownership/handoff | 3 | 5 | 4 | 4 | 5 |
| Further refresh/publication ownership consolidation | 4 | 3 | 2 | 2 | 5 |

This ordering is not an arithmetic sum: low-risk/easy first work and biggest simplification are different questions. If a proposal must preserve all generator internals/encoders intact and merely adds a typed bypass, inbox should win instead.

## Typed native plan: why it can remove a real abstraction boundary

Poem creates a temporary workspace, writes its private format records, calls `AuthoredDeck.validate`, and returns a cleanup-bearing bundle (`Sources/PoemDeckBuilder/PoemDeckGenerator.swift:95-111`). Prose does the same (`Sources/ProseDeckBuilder/ProseDeckGenerator.swift:60-76`). Both emit nearly the same manifest/type/deck/template/slot/component/skill/item text DTO vocabulary: ten private Encodable structs each (`Sources/PoemDeckBuilder/PoemDeckGenerator.swift:259-333`; `Sources/ProseDeckBuilder/ProseDeckGenerator.swift:193-263`), in addition to equivalent record vocabulary inside the loader (`NeoAnkiCore/Sources/NeoAnkiCore/AuthoredDeck/AuthoredDeck.swift:229-245` and following). The native path then reparses through `AuthoredDeckLoader.load()` during import (`NeoAnkiCore/Sources/NeoAnkiCore/AuthoredDeck/AuthoredDeck.swift:82-114`).

A useful plan removes five native lifecycle responsibilities: temporary workspace creation/permissions, JSONL serialization, format-only validation/reparse, bundle cleanup, and post-import placement. Reuse the existing common persistence/importer behavior, not a new sequence of create calls. The common typed `AuthoredDeckPackage` already contains root/decks/types/items/media/policies (`NeoAnkiCore/Sources/NeoAnkiCore/AuthoredDeck/AuthoredDeck.swift:209-217`), but is an internal product of untrusted format compilation, not yet a safe public constructor. A validated creation plan can be a narrow native constructor of that existing importer representation.

The current importer also performs important schema-digest reuse, field ordinal mapping, new item identity and ordered creation timestamps (`NeoAnkiCore/Sources/NeoAnkiCore/AuthoredDeck/ItemStore+AuthoredDeck.swift:14-105`); preserve these. Do not have builders reproduce these semantics. Keep public bundle/workspace APIs as compatibility wrappers that serialize the same plan through one exporter. Their existence prevents claiming removal of the external authored format or all filesystem code. Sharing that exporter can remove duplicated DTO definitions; leaving two bespoke DTO encoders plus a new plan is less simplification than advertised.

Behavior correction must be separate: current macOS generation imports, then updates the parent in a second operation (`Sources/NeoAnki2/ContentView.swift:901-918`); iOS does the same twice (`Sources/NeoAnkiIOS/ManagementViews.swift:315-333`, `:369-386`). Atomic parent validation/import avoids a committed top-level deck if the chosen parent disappears. It is valuable but not merely behavior-preserving refactoring. A creation-plan interface should distinguish “create root under parent” from existing `destinationDeckID` import-items behavior, which puts items into an existing deck and suppresses hierarchy; reusing that parameter incorrectly changes semantics.

Acceptance before calling it a simplification: the native callers take only a typed validated plan and outcome; one importer owns all persistence invariants; compatibility wrappers produce existing format; current schema reuse, all generated card content/order, limits, built-in type interpretation and cloud/native journal behavior remain equivalent. Tests should compare native typed and compatibility-bundle imports semantically in temporary libraries, including parent deletion between planning/commit. No .neoanki/.neodeck/SQLite format change.

## Inbox handoff: real ownership duplication, smaller structural deletion

Explicit fetcher commits page/token, then collects/returns raw records (`Sources/NeoAnkiCloudSync/LibraryZoneChangeFetcher.swift:20-30`). The transport buffers those records (`Sources/NeoAnkiCloudSync/CKSyncEngineTransport.swift:313-320`); service fetches them then stages again (`Sources/NeoAnkiCloudSync/OfflineFirstSyncService.swift:179-184`). Delegate delivery/conflicts follow the same stage+append arrangement (`Sources/NeoAnkiCloudSync/CKSyncEngineTransport.swift:340-349`, `:362-390`). The second stage copies assets afresh (`Sources/NeoAnkiCloudSync/SyncMetadataStore.swift:266-289`) before overwriting/deleting the first copy. For one page delivered once through this path, the code deterministically executes two receipt/staging passes; each asset is copied once per pass. This is a static count, not a measured bytes/time claim.

The exact removable mechanisms are the **incoming envelope** buffer and append/drain methods (`Sources/NeoAnkiCloudSync/CKSyncEngineTransport.swift:23`, `:84-89`), append calls at explicit fetch/delegate/conflict sites, service restaging for a known durable transport, and fetcher accumulation when no compatibility caller needs it. Keep outgoing envelopes, server CKRecord/change-tag cache, absent records, failure tracking and unacknowledged-upload guard. Those are different owners.

A typed receipt/refinement is safe only if it proves identity of the same metadata-store actor/directory generation that the service consumes. A free Boolean or caller-supplied token increases loss risk. The fallback unstaged path is necessary while preserving existing `CloudSyncTransport`; its generic fake transport conformers are not evidence of durable delivery. Prefer a single small internal capability returning the durable inbox source, validated once at construction, to a new token framework/generation registry on every batch.

Alternative considered: require every transport to stage into one owned inbox adapter. That yields a cleaner single path but changes existing public conformer obligations or requires compatibility wrapping, and therefore is larger migration/API work than it initially appears. Adding an internal protocol refinement is a practical compatibility compromise, not automatically a net simplification. It adds at least one capability/receipt and a delivery branch while deleting a small memory buffer and redundant receipt calls. The conceptual benefit is clear, but source/ownership deletion is narrower than a successful typed native-plan refactor.

Safeguards: receive page/token together; never announce receipt before asset copy and metadata persist complete; exact full-envelope comparison when completing consumed inbox, so newer same-resource callback survives; no retained CKAsset URL reliance; restart after each page and callback/consume boundary; no conflict delivery error suppression; unchanged complete initial snapshot semantics. Keep current property-list keys and relative filenames. A failing receipt identity check must fall back to safe staging or fail explicitly, never silently skip delivery.

## Refresh ownership: strongest broad upside, least bounded proof

`NativeLibraryReadCoordinator` already centralizes demand-specific reads and before/after revision retry (`Sources/NeoAnkiApplication/NativeLibraryReadCoordinator.swift:45-87`). Both macOS models receive it (`Sources/NeoAnki2/DecksModel.swift:45-60`; `Sources/NeoAnki2/ItemsModel.swift:123-139`), and the mobile/shared feature model uses it with generation, scope and study-save checks (`Sources/NeoAnkiFeatures/LibraryFeatureModel.swift:170-225`). Simply introducing a second shared coordinator would add a layer.

There is remaining duplication: macOS ContentView orchestrates sidebar/detail refresh at common time (`Sources/NeoAnki2/ContentView.swift:999-1060`), ItemsModel independently subscribes journal invalidations (`Sources/NeoAnki2/ItemsModel.swift:132-139`), and feature models refresh after commands in addition to observing changes (`Sources/NeoAnkiFeatures/LibraryFeatureModel.swift:170-179`, `:554-560`). A single presentation publication owner could coalesce work and make a multi-surface snapshot truly one revision, rather than two separately consistent reads at the same clock instant.

But preservation requirements are substantial: time-driven due refresh without a journal revision, local command optimistic state, save-in-flight study fences, inactive browse demand, scope/sort selection cancellation, stale results, non-flickering errors/loading, reminder/device-state publication and maturity degradation. The current view/model split embodies these semantics. Until the proposal shows exactly which owners and state machines disappear, refresh remains less concrete than the other two candidates. Do not score call-site count as proof that those responsibilities can all collapse safely.
