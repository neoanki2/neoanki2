import Foundation
import NeoAnkiApplication

// Exact production SyncMetadataStore + LibraryZoneChangeFetcher source copies
// sit beside this file. No CloudKit/network transport or user data is opened.
@main struct MetadataProbe {
    static func record(_ id: Int, revision: Int = 1) -> SyncRecordEnvelope {
        SyncRecordEnvelope(id: "record-\(id)", resourceKind: "item", revision: revision,
            deviceID: "synthetic-probe", order: Int64(id), isTombstone: false,
            payload: Data(("{\"synthetic\":\(id),\"text\":\"" + String(repeating: "x", count: 480) + "\"}").utf8))
    }
    static func main() async throws {
        let counts = CommandLine.arguments.dropFirst().compactMap(Int.init)
        print("baseline_count,event,iteration,seconds,file_bytes")
        for n in counts.isEmpty ? [1_000, 10_000, 50_000] : counts {
            let root = FileManager.default.temporaryDirectory.appendingPathComponent("neoanki-metadata-probe-\(UUID())")
            defer { try? FileManager.default.removeItem(at: root) }
            var baseline: [String: SyncRecordEnvelope] = [:]
            for id in 0..<n { let r = record(id); baseline["item:\(r.id)"] = r }
            let seed = SyncMetadata(outboundCursor: Int64(n), serverBaseline: baseline,
                didCreateInitialBackup: true, didCompleteInitialMerge: true)
            let store = SyncMetadataStore(directory: root)
            try await store.save(seed)
            // Warm-up load is excluded; each measured event still calls real I/O.
            _ = try await store.load()
            for iteration in 0..<6 {
                try await measure(n, "one_record_zone_page_ack", iteration, root) {
                    let fetcher = LibraryZoneChangeFetcher(metadataStore: store)
                    let r = record(n + iteration)
                    let received = try await fetcher.fetch { _ in
                        .init(records: [r], token: Data("token-\(iteration)".utf8), moreComing: false)
                    }
                    let snapshot = try await store.load()
                    let committed = try await store.completeIncoming(received, metadata: snapshot)
                    precondition(committed.stagedInbound.isEmpty)
                    precondition(committed.serverBaseline?["item:\(r.id)"] == r)
                }
                try await measure(n, "no_change_bookkeeping", iteration, root) {
                    let metadata = try await store.load()
                    try await store.save(metadata)
                }
                try await measure(n, "outbound_ack", iteration, root) {
                    try await store.acknowledge([record(iteration, revision: 2)])
                }
            }
            // Inbox candidate: exact production removal equality, including
            // concurrent/newer same-ID safety, with realistic all-page consume.
            let inbox = (0..<min(n, 10_000)).map { record($0, revision: 3) }
            try await store.receive(inbox)
            let snapshot = try await store.load()
            try await measure(n, "full_inbox_consume", 0, root) {
                let committed = try await store.completeIncoming(inbox, metadata: snapshot)
                precondition(committed.stagedInbound.isEmpty)
            }
            // A fresh actor verifies persisted state, excluding memory-only success.
            let restarted = try await SyncMetadataStore(directory: root).load()
            precondition(restarted.stagedInbound.isEmpty)
            precondition(restarted.outboundCursor == Int64(n))
        }
    }
    @MainActor static func measure(_ n: Int, _ event: String, _ iteration: Int, _ root: URL,
        action: () async throws -> Void) async throws {
        let clock = ContinuousClock()
        let start = clock.now
        try await action()
        let duration = start.duration(to: clock.now)
        let seconds = Double(duration.components.seconds) + Double(duration.components.attoseconds) / 1e18
        let attrs = try FileManager.default.attributesOfItem(atPath: root.appendingPathComponent("cloud-sync-metadata.plist").path)
        print("\(n),\(event),\(iteration),\(seconds),\(attrs[.size]!)")
    }
}
