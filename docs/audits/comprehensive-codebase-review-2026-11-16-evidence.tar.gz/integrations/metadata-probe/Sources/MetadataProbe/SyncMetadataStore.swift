import CloudKit
import Foundation
import NeoAnkiApplication

public struct SyncMetadata: Codable, Sendable {
    public var engineState: CKSyncEngine.State.Serialization?
    /// Independent cursor for explicit library reads, including missed pushes.
    public var libraryZoneChangeToken: Data?
    public var deviceID: String
    public var outboundCursor: Int64
    public var stagedInbound: [SyncRecordEnvelope]
    public var pendingOutbound: [SyncRecordEnvelope]?
    public var serverBaseline: [String: SyncRecordEnvelope]?
    public var issues: [SyncIssue]
    /// Losing versions remain recoverable after automatic conflict resolution.
    /// Optional for backward compatibility with metadata written by older apps.
    public var resolvedConflictCopies: [SyncConflictCopy]?
    public var didCreateInitialBackup: Bool?
    public var didCompleteInitialMerge: Bool?

    public init(
        engineState: CKSyncEngine.State.Serialization? = nil,
        libraryZoneChangeToken: Data? = nil,
        deviceID: String = UUID().uuidString,
        outboundCursor: Int64 = 0,
        stagedInbound: [SyncRecordEnvelope] = [],
        pendingOutbound: [SyncRecordEnvelope]? = nil,
        serverBaseline: [String: SyncRecordEnvelope]? = nil,
        issues: [SyncIssue] = [],
        resolvedConflictCopies: [SyncConflictCopy]? = nil,
        didCreateInitialBackup: Bool? = nil,
        didCompleteInitialMerge: Bool? = nil
    ) {
        self.engineState = engineState
        self.libraryZoneChangeToken = libraryZoneChangeToken
        self.deviceID = deviceID
        self.outboundCursor = outboundCursor
        self.stagedInbound = stagedInbound
        self.pendingOutbound = pendingOutbound
        self.serverBaseline = serverBaseline
        self.issues = issues
        self.resolvedConflictCopies = resolvedConflictCopies
        self.didCreateInitialBackup = didCreateInitialBackup
        self.didCompleteInitialMerge = didCompleteInitialMerge
    }
}

/// Stores engine state and sync bookkeeping beside, never inside, domain tables.
public actor SyncMetadataStore {
    private let fileURL: URL
    private let stagedAssetDirectory: URL
    private let outboundAssetDirectory: URL
    private let encoder = PropertyListEncoder()
    private let decoder = PropertyListDecoder()

    public init(directory: URL) {
        fileURL = directory.appendingPathComponent("cloud-sync-metadata.plist", isDirectory: false)
        stagedAssetDirectory = directory.appendingPathComponent("inbound-assets", isDirectory: true)
        outboundAssetDirectory = directory.appendingPathComponent("outbound-assets", isDirectory: true)
    }

    public func load() throws -> SyncMetadata {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            return SyncMetadata()
        }
        var metadata = try decoder.decode(SyncMetadata.self, from: Data(contentsOf: fileURL))
        metadata.stagedInbound = metadata.stagedInbound.map(resolveAssetLocation)
        metadata.pendingOutbound = metadata.pendingOutbound?.map(resolveAssetLocation)
        return metadata
    }

    public func save(_ metadata: SyncMetadata) throws {
        var metadata = metadata
        // CKSyncEngine emits state updates while a service awaits a network
        // operation. Preserve that newer serialization during bookkeeping.
        if FileManager.default.fileExists(atPath: fileURL.path) {
            let current = try load()
            metadata.engineState = current.engineState
            metadata.libraryZoneChangeToken = current.libraryZoneChangeToken
            // Only completeIncoming may remove delivered records. A stale
            // service snapshot cannot erase a concurrent transport callback.
            metadata.stagedInbound = current.stagedInbound
            metadata.serverBaseline = current.serverBaseline
            metadata.resolvedConflictCopies = mergedArchive(current, metadata)
        }
        try persist(metadata)
    }

    /// Finish a single conflict against the latest metadata so a concurrent
    /// transport callback cannot lose another newly preserved conflict.
    func completeConflict(_ issue: SyncIssue) throws -> SyncMetadata {
        var metadata = try load()
        guard let copy = issue.conflictCopy else { return metadata }
        var archive = metadata.resolvedConflictCopies ?? []
        if !archive.contains(where: { $0.id == copy.id }) { archive.append(copy) }
        metadata.resolvedConflictCopies = archive
        metadata.issues.removeAll { $0.id == issue.id }
        try persist(metadata)
        return metadata
    }

    func saveEngineState(_ state: CKSyncEngine.State.Serialization) throws {
        var metadata = try load()
        metadata.engineState = state
        try persist(metadata)
    }

    func resetLibraryZoneChangeToken() throws {
        var metadata = try load()
        metadata.libraryZoneChangeToken = nil
        try persist(metadata)
    }

    /// Commit delivered records before the engine may persist its next fetch
    /// token. On process death, the service can replay this durable inbox.
    func receive(_ records: [SyncRecordEnvelope]) throws {
        guard !records.isEmpty else { return }
        try receiveZonePage(records, token: nil)
    }

    /// Stage payloads and advance the explicit fetch cursor in the same write.
    /// A failed page (including asset staging) must leave the old cursor intact.
    func receiveZonePage(_ records: [SyncRecordEnvelope], token: Data?) throws {
        let staged = try stageAssets(in: records)
        var metadata = try load()
        var latest: [String: SyncRecordEnvelope] = [:]
        for record in metadata.stagedInbound + staged {
            latest["\(record.resourceKind):\(record.id)"] = record
        }
        let obsolete = (metadata.stagedInbound + staged).filter { old in
            latest["\(old.resourceKind):\(old.id)"]?.stagedFileURL != old.stagedFileURL
        }
        metadata.stagedInbound = Array(latest.values)
        if let token { metadata.libraryZoneChangeToken = token }
        try persist(metadata)
        removeStagedAssets(in: obsolete)
    }

    func completeIncoming(_ consumed: [SyncRecordEnvelope], metadata: SyncMetadata) throws -> SyncMetadata {
        var committed = metadata
        let current = try load()
        committed.engineState = current.engineState
        committed.libraryZoneChangeToken = current.libraryZoneChangeToken
        committed.stagedInbound = current.stagedInbound.filter { !consumed.contains($0) }
        committed.serverBaseline = current.serverBaseline
        committed.resolvedConflictCopies = mergedArchive(current, committed)
        for record in consumed { setBaseline(record, metadata: &committed) }
        try persist(committed)
        removeStagedAssets(in: consumed)
        return committed
    }

    func stageOutbound(_ records: [SyncRecordEnvelope]) throws -> [SyncRecordEnvelope] {
        try stageAssets(in: records, directory: outboundAssetDirectory)
    }

    func acknowledge(_ records: [SyncRecordEnvelope]) throws {
        var metadata = try load()
        for record in records { setBaseline(record, metadata: &metadata) }
        try persist(metadata)
    }

    private func setBaseline(_ record: SyncRecordEnvelope, metadata: inout SyncMetadata) {
        if metadata.serverBaseline == nil { metadata.serverBaseline = [:] }
        metadata.serverBaseline?["\(record.resourceKind):\(record.id)"] = SyncRecordEnvelope(
            id: record.id, resourceKind: record.resourceKind, revision: record.revision,
            deviceID: record.deviceID, order: record.order, isTombstone: record.isTombstone,
            payload: record.payload, asset: record.asset
        )
    }

    static func sameContent(_ a: SyncRecordEnvelope, _ b: SyncRecordEnvelope) -> Bool {
        a.id == b.id && a.resourceKind == b.resourceKind && a.payload == b.payload
            && a.asset == b.asset && a.isTombstone == b.isTombstone
    }

    func preserveConflict(local: SyncRecordEnvelope, server: SyncRecordEnvelope) throws {
        guard !Self.sameContent(local, server) else { return }
        var metadata = try load()
        // Retries/restarts preserve one copy of each losing version.
        let preserved = metadata.issues.compactMap(\.conflictCopy) + (metadata.resolvedConflictCopies ?? [])
        guard !preserved.contains(where: {
            $0.originalResourceID == local.id
                && $0.resourceKind == local.resourceKind
                && $0.payload == local.payload
                && $0.wasTombstone == local.isTombstone
        }) else { return }
        let kind: SyncIssueKind = local.isTombstone || server.isTombstone ? .deleteVersusEdit
            : local.resourceKind == "deck" ? .deckConflict
            : local.resourceKind == "itemType" ? .itemTypeConflict : .itemConflict
        let copy = SyncConflictCopy(resourceKind: local.resourceKind, originalResourceID: local.id,
            sourceDeviceID: local.deviceID, payload: local.payload,
            wasTombstone: local.isTombstone, acceptedWasTombstone: server.isTombstone)
        metadata.issues.append(SyncIssue(kind: kind, resourceID: local.id,
            summary: "A change from another device was accepted. Your prior version is preserved.", conflictCopy: copy))
        try persist(metadata)
    }

    private func persist(_ metadata: SyncMetadata) throws {
        let directory = fileURL.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var stored = metadata
        // iOS can relocate the entire data container during an app update. Queue
        // owned filenames, never the installation-specific absolute sandbox URL.
        stored.stagedInbound = stored.stagedInbound.map(relativeAssetLocation)
        stored.pendingOutbound = stored.pendingOutbound?.map(relativeAssetLocation)
        let data = try encoder.encode(stored)
        try data.write(to: fileURL, options: .atomic)
    }

    /// Recognizes only opaque files created by this store, including absolute
    /// paths from older installations. Remote asset names never select a path.
    private func ownedAssetLocation(_ url: URL) -> (directory: URL, filename: String)? {
        let filename = url.lastPathComponent
        guard UUID(uuidString: filename) != nil else { return nil }
        let parent = url.deletingLastPathComponent().lastPathComponent
        let directory: URL
        switch parent {
        case "inbound-assets": directory = stagedAssetDirectory
        case "outbound-assets": directory = outboundAssetDirectory
        default: return nil
        }
        if url.scheme == nil {
            guard url.relativeString == "\(parent)/\(filename)" else { return nil }
        } else {
            // Legacy absolute locations must have our metadata-directory layout.
            // Do not reinterpret arbitrary external files as queue-owned assets.
            guard url.isFileURL,
                  url.deletingLastPathComponent().deletingLastPathComponent().lastPathComponent
                    == fileURL.deletingLastPathComponent().lastPathComponent else { return nil }
        }
        return (directory, filename)
    }

    private func replacingAssetLocation(_ record: SyncRecordEnvelope, with url: URL) -> SyncRecordEnvelope {
        SyncRecordEnvelope(
            id: record.id, resourceKind: record.resourceKind, revision: record.revision,
            deviceID: record.deviceID, order: record.order, isTombstone: record.isTombstone,
            payload: record.payload, asset: record.asset, stagedFileURL: url
        )
    }

    private func resolveAssetLocation(_ record: SyncRecordEnvelope) -> SyncRecordEnvelope {
        guard let url = record.stagedFileURL, let location = ownedAssetLocation(url) else { return record }
        return replacingAssetLocation(record, with: location.directory.appendingPathComponent(location.filename))
    }

    private func relativeAssetLocation(_ record: SyncRecordEnvelope) -> SyncRecordEnvelope {
        guard let url = record.stagedFileURL, let location = ownedAssetLocation(url),
              let relative = URL(string: "\(location.directory.lastPathComponent)/\(location.filename)")
        else { return record }
        return replacingAssetLocation(record, with: relative)
    }

    private func mergedArchive(_ current: SyncMetadata, _ incoming: SyncMetadata) -> [SyncConflictCopy]? {
        guard current.resolvedConflictCopies != nil || incoming.resolvedConflictCopies != nil else { return nil }
        let existing = current.resolvedConflictCopies ?? []
        let ids = Set(existing.map(\.id))
        return existing + (incoming.resolvedConflictCopies ?? []).filter { !ids.contains($0.id) }
    }

    public func stageAssets(in records: [SyncRecordEnvelope]) throws -> [SyncRecordEnvelope] {
        try stageAssets(in: records, directory: stagedAssetDirectory)
    }

    private func stageAssets(in records: [SyncRecordEnvelope], directory: URL) throws -> [SyncRecordEnvelope] {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var created: [URL] = []
        do { return try records.map { record in
            guard let source = record.stagedFileURL, let asset = record.asset else { return record }
            // Remote hash/extension strings are untrusted path components.
            // Validation happens in the adapter; staging uses an opaque name.
            let destination = directory.appendingPathComponent(UUID().uuidString)
            try FileManager.default.copyItem(at: source, to: destination)
            created.append(destination)
            return SyncRecordEnvelope(
                id: record.id,
                resourceKind: record.resourceKind,
                revision: record.revision,
                deviceID: record.deviceID,
                order: record.order,
                isTombstone: record.isTombstone,
                payload: record.payload,
                asset: asset,
                stagedFileURL: destination
            )
        } } catch {
            for url in created { try? FileManager.default.removeItem(at: url) }
            throw error
        }
    }

    public func removeStagedAssets(in records: [SyncRecordEnvelope]) {
        let roots = [stagedAssetDirectory, outboundAssetDirectory].map { $0.standardizedFileURL.path + "/" }
        for record in records {
            guard let url = record.stagedFileURL,
                  roots.contains(where: { url.standardizedFileURL.path.hasPrefix($0) })
            else { continue }
            try? FileManager.default.removeItem(at: url)
        }
    }
}
