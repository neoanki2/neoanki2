// External read-work probe. Does not modify product/test code. No user library or OS services.
// Counter deltas are operation counts, not timing measurements. Mutations below intentionally isolate explicit didMutate refresh.
import Foundation
import NeoAnkiCore
import NeoAnkiApplication
import NeoAnkiFeatures

actor CountingLibrary: LibraryRepository, LibraryNativeReadSupporting, LibraryNativeCommandSupporting, LibraryStudyAvailabilityReading {
    let base: SQLiteLibraryRepository
    var counts: [String: Int] = [:]
    init(_ base: SQLiteLibraryRepository) { self.base = base }
    func takeCounts() -> [String: Int] { defer { counts = [:] }; return counts }
    func itemRecordsPage(offset: Int, limit: Int) async throws -> [LibraryItemRecord] {
        counts["itemRecordsPage", default: 0] += 1
        return try await base.itemRecordsPage(offset: offset, limit: limit)
    }
    func deckDeletionImpact(id: UUID, policy: DeckDeletionPolicy) async throws -> DeckDeletionImpact {
        counts["deckDeletionImpact", default: 0] += 1
        return try await base.deckDeletionImpact(id: id, policy: policy)
    }
    func commitDeckDeletion(id: UUID, policy: DeckDeletionPolicy, asOf: Date) async throws {
        counts["commitDeckDeletion", default: 0] += 1
        try await base.commitDeckDeletion(id: id, policy: policy, asOf: asOf)
    }
    func deckResetImpact(id: UUID) async throws -> DeckResetImpact {
        counts["deckResetImpact", default: 0] += 1
        return try await base.deckResetImpact(id: id)
    }
func bootstrap() async throws {
        counts["bootstrap", default: 0] += 1
        return try await base.bootstrap()
    }

func coldHomeSnapshot(
        scope: DeckScope,
        asOf: Date
    ) async throws -> ColdLibraryHomeSnapshot {
        counts["coldHomeSnapshot", default: 0] += 1
        return try await base.coldHomeSnapshot(scope: scope, asOf: asOf)
    }

func mediaStore() async -> MediaStore? {
        counts["mediaStore", default: 0] += 1
        return await base.mediaStore()
    }

func libraryID() async throws -> UUID {
        counts["libraryID", default: 0] += 1
        return try await base.libraryID()
    }

func loadItemTypes() async throws -> ItemTypeLoadResult {
        counts["loadItemTypes", default: 0] += 1
        return try await base.loadItemTypes()
    }

func loadItemTypeCatalog() async throws -> ItemTypeCatalog {
        counts["loadItemTypeCatalog", default: 0] += 1
        return try await base.loadItemTypeCatalog()
    }

func effectiveItemTypePolicy(for deckID: UUID) async throws -> DeckItemTypePolicy? {
        counts["effectiveItemTypePolicy", default: 0] += 1
        return try await base.effectiveItemTypePolicy(for: deckID)
    }

func items(
        scope: DeckScope,
        sort: ItemSortOrder,
        search: String
    ) async throws -> [SavedItemSummary] {
        counts["items", default: 0] += 1
        return try await base.items(scope: scope, sort: sort, search: search)
    }

func item(id: UUID) async throws -> (item: Item, itemType: ItemType)? {
        counts["item", default: 0] += 1
        return try await base.item(id: id)
    }

func cardMaturityDetails(itemID: UUID) async throws -> [CardMaturityDetail] {
        counts["cardMaturityDetails", default: 0] += 1
        return try await base.cardMaturityDetails(itemID: itemID)
    }

func itemBrowseSchedules(itemIDs: [UUID]) async throws -> [UUID: ItemBrowseSchedule] {
        counts["itemBrowseSchedules", default: 0] += 1
        return try await base.itemBrowseSchedules(itemIDs: itemIDs)
    }

func scopeSummary(scope: DeckScope, asOf: Date) async throws -> ScopeSummary {
        counts["scopeSummary", default: 0] += 1
        return try await base.scopeSummary(scope: scope, asOf: asOf)
    }

func createItem(_ item: Item, asOf: Date) async throws -> SavedItemSummary {
        counts["createItem", default: 0] += 1
        return try await base.createItem(item, asOf: asOf)
    }

func updateItem(_ item: Item, asOf: Date) async throws -> SavedItemSummary {
        counts["updateItem", default: 0] += 1
        return try await base.updateItem(item, asOf: asOf)
    }

func reconcileItemTypeAndItems(
        expectedItemType: ItemType,
        updatedItemType: ItemType,
        replacements: [Item],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        counts["reconcileItemTypeAndItems", default: 0] += 1
        return try await base.reconcileItemTypeAndItems(expectedItemType: expectedItemType, updatedItemType: updatedItemType, replacements: replacements, asOf: asOf)
    }

func reconcileOrderedDeckItems(
        _ operations: [ItemBulkOperation],
        order: OrderedDeckItemReconciliation,
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        counts["reconcileOrderedDeckItems", default: 0] += 1
        return try await base.reconcileOrderedDeckItems(operations, order: order, asOf: asOf)
    }

func deleteUnchangedUnreviewedItems(
        _ expectedItems: [Item],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        counts["deleteUnchangedUnreviewedItems", default: 0] += 1
        return try await base.deleteUnchangedUnreviewedItems(expectedItems, asOf: asOf)
    }

func deleteItem(id: UUID, asOf: Date) async throws -> Bool {
        counts["deleteItem", default: 0] += 1
        return try await base.deleteItem(id: id, asOf: asOf)
    }

func deleteAllUnassignedItems(asOf: Date) async throws -> Int {
        counts["deleteAllUnassignedItems", default: 0] += 1
        return try await base.deleteAllUnassignedItems(asOf: asOf)
    }

func moveItem(id: UUID, to deckID: UUID?) async throws -> Bool {
        counts["moveItem", default: 0] += 1
        return try await base.moveItem(id: id, to: deckID)
    }

func acknowledgeRepeatedLapses(
        itemIDs: Set<UUID>,
        asOf: Date
    ) async throws -> Int {
        counts["acknowledgeRepeatedLapses", default: 0] += 1
        return try await base.acknowledgeRepeatedLapses(itemIDs: itemIDs, asOf: asOf)
    }

func performBulkItemOperations(
        _ operations: [ItemBulkOperation],
        asOf: Date
    ) async throws -> [ItemBulkOperationResult] {
        counts["performBulkItemOperations", default: 0] += 1
        return try await base.performBulkItemOperations(operations, asOf: asOf)
    }

func reserveMedia(
        data: Data,
        kind: MediaKind,
        altText: String,
        asOf: Date
    ) async throws -> ReservedMediaAsset {
        counts["reserveMedia", default: 0] += 1
        return try await base.reserveMedia(data: data, kind: kind, altText: altText, asOf: asOf)
    }

func deck(id: UUID) async throws -> Deck {
        counts["deck", default: 0] += 1
        return try await base.deck(id: id)
    }

func deckSummaries(asOf: Date) async throws -> [DeckSummary] {
        counts["deckSummaries", default: 0] += 1
        return try await base.deckSummaries(asOf: asOf)
    }

func createDeck(_ deck: Deck) async throws -> Deck {
        counts["createDeck", default: 0] += 1
        return try await base.createDeck(deck)
    }

func updateDeck(_ deck: Deck) async throws -> Deck {
        counts["updateDeck", default: 0] += 1
        return try await base.updateDeck(deck)
    }

func moveDeck(id: UUID, to destination: DeckMoveDestination) async throws -> Bool {
        counts["moveDeck", default: 0] += 1
        return try await base.moveDeck(id: id, to: destination)
    }

func deleteDeck(id: UUID) async throws -> Bool {
        counts["deleteDeck", default: 0] += 1
        return try await base.deleteDeck(id: id)
    }

func resetDeckProgress(id: UUID, asOf: Date) async throws -> Int {
        counts["resetDeckProgress", default: 0] += 1
        return try await base.resetDeckProgress(id: id, asOf: asOf)
    }

func authoringItemTypes(for deckID: UUID?) async throws -> AuthoringItemTypes {
        counts["authoringItemTypes", default: 0] += 1
        return try await base.authoringItemTypes(for: deckID)
    }

func createItemType(_ type: ItemType, deckID: UUID?, availableEverywhere: Bool) async throws -> ItemType {
        counts["createItemType", default: 0] += 1
        return try await base.createItemType(type, deckID: deckID, availableEverywhere: availableEverywhere)
    }

func attachItemType(id: UUID, to deckID: UUID) async throws {
        counts["attachItemType", default: 0] += 1
        return try await base.attachItemType(id: id, to: deckID)
    }

func setDeckItemTypes(_ settings: DeckItemTypeSettings) async throws {
        counts["setDeckItemTypes", default: 0] += 1
        return try await base.setDeckItemTypes(settings)
    }

func setItemTypeAvailability(id: UUID, availableEverywhere: Bool) async throws {
        counts["setItemTypeAvailability", default: 0] += 1
        return try await base.setItemTypeAvailability(id: id, availableEverywhere: availableEverywhere)
    }

func createItemType(_ itemType: ItemType) async throws -> ItemType {
        counts["createItemType", default: 0] += 1
        return try await base.createItemType(itemType)
    }

func updateItemType(_ itemType: ItemType, asOf: Date) async throws -> ItemType {
        counts["updateItemType", default: 0] += 1
        return try await base.updateItemType(itemType, asOf: asOf)
    }

func updateItemType(
        _ itemType: ItemType,
        authorization: ItemTypeUpdateAuthorization,
        asOf: Date
    ) async throws -> ItemType {
        counts["updateItemType", default: 0] += 1
        return try await base.updateItemType(itemType, authorization: authorization, asOf: asOf)
    }

func duplicateItemType(id: UUID, name: String) async throws -> ItemType {
        counts["duplicateItemType", default: 0] += 1
        return try await base.duplicateItemType(id: id, name: name)
    }

func itemTypeEditingImpact(id: UUID) async throws -> ItemTypeEditingImpact {
        counts["itemTypeEditingImpact", default: 0] += 1
        return try await base.itemTypeEditingImpact(id: id)
    }

func unlockItemType(id: UUID) async throws -> ItemType {
        counts["unlockItemType", default: 0] += 1
        return try await base.unlockItemType(id: id)
    }

func itemTypeSchemaChangeImpact(
        from existing: ItemType,
        to updated: ItemType
    ) async throws -> ItemTypeSchemaChangeImpact {
        counts["itemTypeSchemaChangeImpact", default: 0] += 1
        return try await base.itemTypeSchemaChangeImpact(from: existing, to: updated)
    }

func prepareItemTypeUpdateAuthorization(
        from existing: ItemType,
        to updated: ItemType
    ) async throws -> ItemTypeUpdateAuthorization {
        counts["prepareItemTypeUpdateAuthorization", default: 0] += 1
        return try await base.prepareItemTypeUpdateAuthorization(from: existing, to: updated)
    }

func repairItemTypeDefinition(id: UUID, asOf: Date) async throws -> ItemType {
        counts["repairItemTypeDefinition", default: 0] += 1
        return try await base.repairItemTypeDefinition(id: id, asOf: asOf)
    }

func countItems(itemTypeID: UUID) async throws -> Int {
        counts["countItems", default: 0] += 1
        return try await base.countItems(itemTypeID: itemTypeID)
    }

func deleteItemType(id: UUID) async throws -> Bool {
        counts["deleteItemType", default: 0] += 1
        return try await base.deleteItemType(id: id)
    }

func dueCount(scope: DeckScope, asOf: Date) async throws -> Int {
        counts["dueCount", default: 0] += 1
        return try await base.dueCount(scope: scope, asOf: asOf)
    }

func dueCards(
        scope: DeckScope,
        asOf: Date,
        limit: Int?
    ) async throws -> [DueCard] {
        counts["dueCards", default: 0] += 1
        return try await base.dueCards(scope: scope, asOf: asOf, limit: limit)
    }

func isNewStudyCardEligible(cardID: UUID, scope: DeckScope, asOf: Date) async throws -> Bool {
        counts["isNewStudyCardEligible", default: 0] += 1
        return try await base.isNewStudyCardEligible(cardID: cardID, scope: scope, asOf: asOf)
    }

func submitReview(
        cardID: UUID,
        rating: ReviewRating,
        asOf: Date,
        durationMilliseconds: Int
    ) async throws -> ReviewSubmission {
        counts["submitReview", default: 0] += 1
        return try await base.submitReview(cardID: cardID, rating: rating, asOf: asOf, durationMilliseconds: durationMilliseconds)
    }

func reviewSchedulePreviews(
        cardID: UUID,
        asOf: Date
    ) async throws -> [ReviewRating: ReviewSchedulePreview] {
        counts["reviewSchedulePreviews", default: 0] += 1
        return try await base.reviewSchedulePreviews(cardID: cardID, asOf: asOf)
    }

func completeAudioSubmission(
        _ draft: StudyResponseDraft,
        submittedAt: Date
    ) async throws -> StudyResponse {
        counts["completeAudioSubmission", default: 0] += 1
        return try await base.completeAudioSubmission(draft, submittedAt: submittedAt)
    }

func studyResponses(matching query: StudyResponseQuery) async throws -> [StudyResponse] {
        counts["studyResponses", default: 0] += 1
        return try await base.studyResponses(matching: query)
    }

func studyResponse(id: UUID) async throws -> StudyResponse {
        counts["studyResponse", default: 0] += 1
        return try await base.studyResponse(id: id)
    }

func studyResponseMediaBytes(id: UUID) async throws -> (StudyResponse, MediaAsset, Data) {
        counts["studyResponseMediaBytes", default: 0] += 1
        return try await base.studyResponseMediaBytes(id: id)
    }

func deleteStudyResponse(id: UUID, asOf: Date) async throws -> Bool {
        counts["deleteStudyResponse", default: 0] += 1
        return try await base.deleteStudyResponse(id: id, asOf: asOf)
    }

func ordinaryMediaReferenceCount(hash: String) async throws -> Int {
        counts["ordinaryMediaReferenceCount", default: 0] += 1
        return try await base.ordinaryMediaReferenceCount(hash: hash)
    }

func isStudyResponseMediaHash(_ hash: String) async throws -> Bool {
        counts["isStudyResponseMediaHash", default: 0] += 1
        return try await base.isStudyResponseMediaHash(hash)
    }

func studyResponseCount(cardIDs: Set<UUID>) async throws -> Int {
        counts["studyResponseCount", default: 0] += 1
        return try await base.studyResponseCount(cardIDs: cardIDs)
    }

func studyResponseCount(itemIDs: Set<UUID>) async throws -> Int {
        counts["studyResponseCount", default: 0] += 1
        return try await base.studyResponseCount(itemIDs: itemIDs)
    }

func studyResponseCount(templateIDs: Set<UUID>) async throws -> Int {
        counts["studyResponseCount", default: 0] += 1
        return try await base.studyResponseCount(templateIDs: templateIDs)
    }

func revertReview(id: UUID, asOf: Date) async throws {
        counts["revertReview", default: 0] += 1
        return try await base.revertReview(id: id, asOf: asOf)
    }

func studyDayRolloverMinutes() async throws -> Int {
        counts["studyDayRolloverMinutes", default: 0] += 1
        return try await base.studyDayRolloverMinutes()
    }

func setStudyDayRolloverMinutes(_ minutes: Int) async throws {
        counts["setStudyDayRolloverMinutes", default: 0] += 1
        return try await base.setStudyDayRolloverMinutes(minutes)
    }

func requestAutomaticSchedulingMaintenance(asOf: Date) async {
        counts["requestAutomaticSchedulingMaintenance", default: 0] += 1
        return await base.requestAutomaticSchedulingMaintenance(asOf: asOf)
    }

func schedulingHealthSnapshot() async throws -> LibrarySchedulingHealth {
        counts["schedulingHealthSnapshot", default: 0] += 1
        return try await base.schedulingHealthSnapshot()
    }

func fsrsParameterSetHistory() async throws -> [LibraryFSRSParameterSet] {
        counts["fsrsParameterSetHistory", default: 0] += 1
        return try await base.fsrsParameterSetHistory()
    }

func fsrsOptimizationRunHistory(
        limit: Int?
    ) async throws -> [LibraryFSRSOptimizationRun] {
        counts["fsrsOptimizationRunHistory", default: 0] += 1
        return try await base.fsrsOptimizationRunHistory(limit: limit)
    }

func importJSONItems(
        from data: Data,
        itemTypeID: UUID?,
        context: ImportContext,
        asOf: Date
    ) async throws -> [SavedItemSummary] {
        counts["importJSONItems", default: 0] += 1
        return try await base.importJSONItems(from: data, itemTypeID: itemTypeID, context: context, asOf: asOf)
    }

func importCSVItems(
        from data: Data,
        itemTypeID: UUID?,
        itemTypeName: String,
        context: ImportContext,
        asOf: Date
    ) async throws -> [SavedItemSummary] {
        counts["importCSVItems", default: 0] += 1
        return try await base.importCSVItems(from: data, itemTypeID: itemTypeID, itemTypeName: itemTypeName, context: context, asOf: asOf)
    }

func importPortableDeck(
        from source: URL,
        conflictResolution: PortableDeckTypeConflictResolution
    ) async throws -> PortableDeckImportResult {
        counts["importPortableDeck", default: 0] += 1
        return try await base.importPortableDeck(from: source, conflictResolution: conflictResolution)
    }

func importAuthoredDeck(from source: URL) async throws -> PortableDeckImportResult {
        counts["importAuthoredDeck", default: 0] += 1
        return try await base.importAuthoredDeck(from: source)
    }

func importAuthoredItems(
        from source: URL,
        into deckID: UUID
    ) async throws -> PortableDeckImportResult {
        counts["importAuthoredItems", default: 0] += 1
        return try await base.importAuthoredItems(from: source, into: deckID)
    }

func exportPortableDeck(id: UUID, to destination: URL) async throws {
        counts["exportPortableDeck", default: 0] += 1
        return try await base.exportPortableDeck(id: id, to: destination)
    }

func currentChangeCursor() async throws -> Int64 {
        counts["currentChangeCursor", default: 0] += 1
        return try await base.currentChangeCursor()
    }

func changeNotifications() async -> AsyncStream<Int64> {
        return AsyncStream { $0.finish() } // Isolate explicit refresh; no mutation observer for this count probe.
    }

func recordLibraryAlias(_ aliasID: UUID, canonicalID: UUID) async throws {
        counts["recordLibraryAlias", default: 0] += 1
        return try await base.recordLibraryAlias(aliasID, canonicalID: canonicalID)
    }

func libraryAliases(canonicalID: UUID) async throws -> Set<UUID> {
        counts["libraryAliases", default: 0] += 1
        return try await base.libraryAliases(canonicalID: canonicalID)
    }

func changes(after cursor: Int64, limit: Int) async throws -> [LibraryChange] {
        counts["changes", default: 0] += 1
        return try await base.changes(after: cursor, limit: limit)
    }

func resourceRevisionSnapshot() async throws -> [LibraryResourceRevision] {
        counts["resourceRevisionSnapshot", default: 0] += 1
        return try await base.resourceRevisionSnapshot()
    }

func recordSyncItemTypeAlias(remoteID: UUID, localID: UUID) async throws {
        counts["recordSyncItemTypeAlias", default: 0] += 1
        return try await base.recordSyncItemTypeAlias(remoteID: remoteID, localID: localID)
    }

func syncItemTypeAliases() async throws -> [UUID: UUID] {
        counts["syncItemTypeAliases", default: 0] += 1
        return try await base.syncItemTypeAliases()
    }

func createBackup(at destination: URL) async throws {
        counts["createBackup", default: 0] += 1
        return try await base.createBackup(at: destination)
    }

func applySynchronizedCard(_ card: Card) async throws {
        counts["applySynchronizedCard", default: 0] += 1
        return try await base.applySynchronizedCard(card)
    }

func applySynchronizedReview(_ log: ReviewLog) async throws {
        counts["applySynchronizedReview", default: 0] += 1
        return try await base.applySynchronizedReview(log)
    }

func synchronizedReviewRecord(id: UUID) async throws -> SynchronizedReviewRecord {
        counts["synchronizedReviewRecord", default: 0] += 1
        return try await base.synchronizedReviewRecord(id: id)
    }

func synchronizedItemRecord(id: UUID) async throws -> SynchronizedItemRecord {
        counts["synchronizedItemRecord", default: 0] += 1
        return try await base.synchronizedItemRecord(id: id)
    }

func reviewRevertRecord(id: UUID) async throws -> ReviewRevertRecord {
        counts["reviewRevertRecord", default: 0] += 1
        return try await base.reviewRevertRecord(id: id)
    }

func itemTypeMembershipRecord(id: String) async throws -> ItemTypeMembershipRecord {
        counts["itemTypeMembershipRecord", default: 0] += 1
        return try await base.itemTypeMembershipRecord(id: id)
    }

func schedulingSettingsRecord(id: String) async throws -> SchedulingSettingsRecord {
        counts["schedulingSettingsRecord", default: 0] += 1
        return try await base.schedulingSettingsRecord(id: id)
    }

func portableItemTypeMappingRecord(id: String) async throws -> PortableItemTypeMappingRecord {
        counts["portableItemTypeMappingRecord", default: 0] += 1
        return try await base.portableItemTypeMappingRecord(id: id)
    }

func applySynchronizedBatch(_ mutations: [SynchronizedLibraryMutation]) async throws {
        counts["applySynchronizedBatch", default: 0] += 1
        return try await base.applySynchronizedBatch(mutations)
    }

func verifyBackup(at destination: URL) async throws {
        counts["verifyBackup", default: 0] += 1
        return try await base.verifyBackup(at: destination)
    }

func corruptItemTypeDefinitionForTesting(id: UUID) async throws {
        counts["corruptItemTypeDefinitionForTesting", default: 0] += 1
        return try await base.corruptItemTypeDefinitionForTesting(id: id)
    }

func recordLearningTimeAliases(_ aliases: [LearningTimeItemAlias]) async throws {
        counts["recordLearningTimeAliases", default: 0] += 1
        return try await base.recordLearningTimeAliases(aliases)
    }

func learningTimeItemAliases() async throws -> [LearningTimeItemAlias] {
        counts["learningTimeItemAliases", default: 0] += 1
        return try await base.learningTimeItemAliases()
    }

func learningTimeLibraryID() async throws -> UUID {
        counts["learningTimeLibraryID", default: 0] += 1
        return try await base.learningTimeLibraryID()
    }

func recordLearningTime(_ segments: [LearningTimeSegment]) async throws {
        counts["recordLearningTime", default: 0] += 1
        return try await base.recordLearningTime(segments)
    }

func learningTimeSegments(after sequence: Int64, limit: Int) async throws -> [LearningTimeStoredSegment] {
        counts["learningTimeSegments", default: 0] += 1
        return try await base.learningTimeSegments(after: sequence, limit: limit)
    }

func learningTimeNotifications() async -> AsyncStream<Void> {
        counts["learningTimeNotifications", default: 0] += 1
        return await base.learningTimeNotifications()
    }

func learningTimeSummary(scope: DeckScope, period: LearningTimePeriod, asOf: Date,
                                    calendar: Calendar) async throws -> LearningTimeSummary {
        counts["learningTimeSummary", default: 0] += 1
        return try await base.learningTimeSummary(scope: scope, period: period, asOf: asOf, calendar: calendar)
    }

func nativeHomeSnapshot(scope: DeckScope, asOf: Date) async throws -> (ColdLibraryHomeSnapshot, String?) {
        counts["nativeHomeSnapshot", default: 0] += 1
        return try await base.nativeHomeSnapshot(scope: scope, asOf: asOf)
    }

func nativeScopeSummary(scope: DeckScope, asOf: Date) async throws -> (ScopeSummary, String?) {
        counts["nativeScopeSummary", default: 0] += 1
        return try await base.nativeScopeSummary(scope: scope, asOf: asOf)
    }

func moveItems(_ selection: [ItemMoveSelection], to deckID: UUID?) async throws -> Int {
        counts["moveItems", default: 0] += 1
        return try await base.moveItems(selection, to: deckID)
    }

func importItems(_ data: Data, format: NativeImportFormat, itemTypeID: UUID?,
        destinationDeckID: UUID?, context: ImportContext, asOf: Date) async throws -> [SavedItemSummary] {
        counts["importItems", default: 0] += 1
        return try await base.importItems(data, format: format, itemTypeID: itemTypeID, destinationDeckID: destinationDeckID, context: context, asOf: asOf)
    }

func deleteItemsAtomically(_ ids: Set<UUID>, asOf: Date) async throws -> Int {
        counts["deleteItemsAtomically", default: 0] += 1
        return try await base.deleteItemsAtomically(ids, asOf: asOf)
    }

func nativeCommandReceipt(_ context: NativeCommandContext) async throws -> NativeCommandReceipt? {
        counts["nativeCommandReceipt", default: 0] += 1
        return try await base.nativeCommandReceipt(context)
    }

func studyAvailability(scope: DeckScope, asOf: Date) async throws -> StudyAvailability {
        counts["studyAvailability", default: 0] += 1
        return try await base.studyAvailability(scope: scope, asOf: asOf)
    }
}
actor ProbeWidget: WidgetSnapshotPublishing { var count = 0; func publish(_ snapshot: DueWidgetSnapshot) { count += 1 }; func take() -> Int { defer { count = 0 }; return count } }
@main struct Probe {
    @MainActor static func main() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("fresh-refresh-probe-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let base = try SQLiteLibraryRepository(databaseURL: root.appendingPathComponent("library.sqlite"))
        try await base.bootstrap()
        for i in 0..<12 { _ = try await base.createDeck(Deck(name: "Fixture \(i)")) }
        let library = CountingLibrary(base), widget = ProbeWidget()
        let model = LibraryFeatureModel(library: library, widgetPublisher: widget)
        func report(_ stage: String) async {
            let counts = await library.takeCounts()
            let encoded = try! JSONSerialization.data(withJSONObject: counts, options: [.sortedKeys])
            print("REFRESH_COUNTS stage=\(stage) calls=\(String(decoding: encoded, as: UTF8.self)) widgetWrites=\(await widget.take())")
        }
        await model.bootstrap(startSync: false)
        await report("bootstrap_home")
        await model.refresh()
        await report("idle_refresh_before_browse")
        _ = try await model.loadBrowse(scope: .allDecks)
        await report("open_browse")
        for _ in 0..<3 { await model.refresh() }
        await report("three_idle_refreshes_after_browse")
        let type = model.itemTypes.first { $0.id == BuiltInItemTypes.basicID }!
        try await model.createItem(itemType: type, deckID: nil, values: [BuiltInItemTypes.frontFieldID: .text("Question"), BuiltInItemTypes.backFieldID: .text("Answer")])
        await report("one_create_explicit_refresh_only")
    }
}
