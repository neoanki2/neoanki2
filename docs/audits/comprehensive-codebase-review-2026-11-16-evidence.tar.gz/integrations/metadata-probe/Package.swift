// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "MetadataProbe", platforms: [.macOS(.v14)], dependencies: [.package(path: "/Users/yanzay/projects/yanzay/neoanki2/.build/fresh-codebase-review-2026-11-16-5baf3fe/snapshot")], targets: [.executableTarget(name: "MetadataProbe", dependencies: [.product(name: "NeoAnkiApplication", package: "snapshot")]) , .executableTarget(name: "RefreshProbe", dependencies: [.product(name: "NeoAnkiApplication", package: "snapshot"), .product(name: "NeoAnkiFeatures", package: "snapshot")])])
