# Independent performance challenge

Read-only challenge of the core agent's **new current evidence**, not an execution by this agent. Reviewed `../core/report.md`, `sql-probe.py`, `sql-work-counts.py`, `sql-query-results.json`, `sql-query-timings.jsonl`, `sql-work-counts.json`, `has-work-parity.json`, timing logs and sample/guard caveats against pinned source under `../snapshot/`.

## Current verdict

Prefer the **bounded ordinary first-card query** as the first performance recommendation. Its work removal is directly demonstrated by exact-statement plans and stable SQLite VM counts; it needs no schema/file-format change and is narrower than incremental relation maintenance. Full relation rebuilding remains a high-impact runner-up. Metadata is a strong structurally proven scaling concern whose production-path cost was still unmeasured when this challenge began; do not select it over measured foreground work based on predicted worst case alone. Re-rank when the metadata event measurements arrive.

All scores 1–5 higher favorable, before a completed metadata benchmark:

| Candidate | Impact | Confidence | Ease | Low introduced complexity | Migration favorable |
|---|---:|---:|---:|---:|---:|
| Bounded ordinary unlimited-new head + indexed work existence | 5 | 5 for SQL mechanism; 4 for whole flow | 4 | 5 | 5 |
| Incremental study relation maintenance | 4 | 5 for rebuild cost; 3 for safe incremental design | 2 | 2 | 3 |
| Format-preserving metadata cache/receipt consolidation | 4 | 5 for redundant work; 3 for measured benefit pending | 3 | 3 | 5 |
| Persistent SQLite/journal sync metadata migration | 4 | 3 | 1 | 2 | 1 under strict unchanged-format constraint |

## What is actually demonstrated

The current first-card path calls `refreshStudyRelationsIfNeeded()`, probes for any work, fetches learned then new partitions, orders work-containing queues, and only afterward truncates (`NeoAnkiCore/Sources/NeoAnkiCore/Database/SQLiteDatabase.swift:5052-5076`, `:5127-5142`). The `.none` new-limit case builds a broad eligible CTE (`:3447-3461`), and its head orders by due/id (`:5086-5103`). Existing active-new partial index already matches the desired due/id order (`NeoAnkiCore/Sources/NeoAnkiCore/Database/Schema.swift:219-221`).

System SQLite instruction counts from `../core/sql-work-counts.json` remove noisy timing from the central mechanism:

| Ordinary all-new fixture | Production new head VM steps | Specialized existing-index head VM steps | Production work probe | Forced work-index EXISTS |
|---:|---:|---:|---:|---:|
| 100 cards | 12,734 | 132 | 1,115 | 18 |
| 1,000 cards | 127,025 | 132 | 11,015 | 18 |
| 25,000 cards | 3,175,061 | 132 | 275,015 | 18 |
| 100,000 cards | 12,700,064 | 132 | 1,100,015 | 18 |

The new head sort count changes from one to zero. On these fixtures both alternatives return the same ID. Zero `fullscan_steps` does **not** imply bounded production work: scanning an index over all candidates still performs millions of VM instructions. This is good evidence for the mechanism, not an end-to-end startup speedup measurement.

Raw wall-time data is exploratory because process guards show unrelated external xcodebuild. Earlier `sql-query-timings.jsonl` reports at 100k roughly 1,347 ms production new-ID query versus 0.034 ms specialized query, but those are not defensible precise release/startup guarantees. The full ItemStore fixture trace also shows warm one-card reads and post-edit reads growing strongly with cardinality, and sampled stacks spend work in SQLite stepping/page reads. Compiler inlining makes line-level callsite attribution less authoritative than the exact query plans and VM counters.

Artifact distinction: current `sql-probe.py` has a forced `INDEXED BY idx_study_work` alternative. Existing earlier `sql-query-results.json`/timings have an unforced relation-first alternative whose plan says `SCAN relation` and whose 100k median is 4.66 ms. The newer `sql-work-counts.json` 18-step result is the forced-index variant. Do not combine its instruction count with the old alternative's wall time/plan as one trial. Both suggest the same direction, but are different experiments. This distinction was sent to the measuring agent/coordinator.

## Semantic challenge: acceptable bounded scope

For `newCardLimitShape.none`, replacing the CTE's `(phase != 'new' OR familyPredicate)` plus outer `phase='new'` with direct `phase='new' AND familyPredicate` is algebraically equivalent. The probe carries the same usability predicate, suspension flag, due instant, family predicate and due/id ordering. It retains the original correlated inner family-first lookups instead of silently replacing them with raw due cards.

The family rule is substantive (`NeoAnkiCore/Sources/NeoAnkiCore/Database/SQLiteDatabase.swift:274-327`): new representative selection is scoped, learned relatives/exposure are library-wide; usable due learned relatives suppress a new sibling; today's un-reverted review exposure respects scheduling-history origin; among new relatives the lowest due/id wins. The ordinary test fixture has no learned/family conflicts and cannot by itself validate these edge cases. Keeping the exact predicate makes the candidate plausible; acceptance still needs real mixed fixtures.

The specialized query must dispatch only for the `.none` daily-limiter branch. `.single`/`.multiple` apply deck/subtree introduction constraints (`:3463-3476` and later helper bodies); bypassing them is a correctness regression. Scope predicates and family candidate scope must be threaded identically, including `.unassigned`, descendant UUID sets and empty sets. The probe hardcodes all-scope clock/day values and is not evidence for every timezone/rollover or bound-parameter case.

The work-existence rewrite is an equivalent indexed semijoin: a non-null work relation exists with at least one same-item active due card in scope. `../core/has-work-parity.json` covers 21 combinations of due/future/suspended/mixed/scoped work states; it tests existence only, not new-head family, daily limit or full queue ordering. A **separate subsequently supplied** `../core/new-head-parity.py`/`.json` adds 21 new-head comparisons covering basic, suspended/future, shared-family, due-learned-relative, a scoped family representative and corrupt-template states across all/deck/unassigned scopes. I read its SQL substitutions and cumulative mutations: it correctly substitutes both outer and candidate scope, and checks exact IDs. Several scoped outcomes are empty; it does not yet cover review reverts/history origins, daily/ancestor limits or full ordered works. Preserve the current work-containing route that loads eligible rows and applies `StudyQueueOrdering.orderWorks`, because `LIMIT 1` before that operation can produce the wrong first card (`:5066-5076`). Optimize ordinary/no-work first; do not claim the work-heavy library path is fixed.

Partial index use does not guarantee constant work for all workloads: if many early due cards fail family/usability/scope predicates, the ordered cursor still scans them. Existing `(due_at,id)` index is well matched to all-scope ordinary new cards; highly selective deck scopes may prefer another strategy. Acceptance should count examined candidates and compare plans for these cases rather than enforce a single index for every scope.

## Actual user-facing consumer and residual cost

`StudyFeatureModel.start` first reads total due count (`Sources/NeoAnkiFeatures/StudyFeatureModel.swift:195-202`), then item types (`:217-220`), then requests a one-card head (`:223-227`). Only then does it publish the first card (`:246-256`). The complete hydrated queue is fetched afterward (`:263-280`). Thus the optimized head is directly on first-visible-card latency; it is not the only preceding cost. Due-count eligibility can still scan data, and relation rebuilding can already have occurred in that earlier read.

Grading remains disabled while the complete queue is preparing (`Sources/NeoAnkiFeatures/StudyFeatureModel.swift:438-440`); audio submission has the same guard (`:412-417`). “First ready” timing here means first visible card, not immediate fully interactive grading. Optimizing the head does not eliminate full-queue hydration or its wait. The probe's alternative statements select ID only; production selects Card columns, decodes card memory, hydrates item/template data and executes actor/repository work (`NeoAnkiCore/Sources/NeoAnkiCore/Database/ItemStore.swift:691-722`). Both exact-ID variants make the SQL cost comparison meaningful, but no full optimized implementation has been benchmarked.

## Relation rebuild competitor

Every items/item_types insert/update/delete sets the global dirty bit (`NeoAnkiCore/Sources/NeoAnkiCore/Database/Schema.swift:62-70`), and refresh fetches all types/items, derives all family/work relationships, deletes and inserts entire projection tables (`NeoAnkiCore/Sources/NeoAnkiCore/Database/SQLiteDatabase.swift:174-233`). This cost is real and spans more than study startup. The post-tag-edit public ItemStore traces are consistent with an extra full relation refresh; they also include the ordinary queue cost, so subtraction under external load is not a clean standalone rebuild benchmark.

Safe incremental maintenance is harder than “update one row”: a type name/schema edit changes every item of that type; moving/reordering/removing one poem/prose item can change both old and new work groups; tags carry opening-card semantics; family exposure is cross-item. Persistent dirty scopes or a cursor must survive crashes/external connections and publish a complete projection transactionally. Keep full rebuild as bootstrap/recovery and preserve schema compatibility if file format must stay exact. The bounded head fix is a better first isolated experiment because it changes query strategy without adding dirty-state/recovery machinery.

## Metadata competitor and measurement requirements

The sync store rereads/reencodes a full plist containing `serverBaseline` on routine page/ack/bookkeeping operations (`Sources/NeoAnkiCloudSync/SyncMetadataStore.swift:62-86`, `:139-169`, `:199-209`). `completeIncoming` uses nested equality lookup (`:144`); duplicate transport→service staging copies received media again. These are not hypothetical optimizations. However the prepared metadata probe measures synthetic metadata events, not whole domain+network sync, and default fixtures have ~500-byte payloads. Report actual file bytes and realistic record counts/payload distributions before comparing to a library with 100k study cards.

Under strict unchanged persisted format, an actor-owned decoded cache removes repeated reads/decode; it still must encode/atomically write the whole plist at durable token/inbox, ack/baseline, cursor/outbox and consumed-domain-batch boundaries. Batch only redundant writes that do not cross these boundaries. Do not call it constant-time metadata persistence or claim SQLite-style write reduction without changing the format. If metadata measurement wins absolute milliseconds at a large synthetic scale, also report foreground trigger/frequency and whether shared actor contention blocks local user commands; library sync failure must continue to allow local work.

## Acceptance for chosen recommendation

Keep source implementation unchanged during analysis. For a future actual change: temporary real libraries at 100/1k/25k/100k, fixed clock, warm and after-edit cases; compare first-card ID and complete ordered queue with ordinary/context/work content, learned/repair/new phases, review reverts, same-due ties, suspended/future cards, corrupted templates, deck/descendant/unassigned scopes and nested daily limits. Preserve existing family inner lookup indexes. Add deterministic EXPLAIN/work-count checks for the narrow no-limiter ordinary path; run release end-to-end timings only after implementing the actual query consumer, with no competing builds, separately reporting due count, head, first visible and full queue/grade-enabled latency.

## Metadata results received after initial challenge

The core agent executed the exact production-copy store/fetcher probe and supplied `../core/metadata-timings.csv` and `metadata-resource.log`. I read the CSV and source; no timings were run by this challenger. Three-sample medians (one sample for full inbox):

| Baseline envelopes | Plist bytes, approximately | One received record page + complete | Unchanged load/save | One outbound acknowledgment |
|---:|---:|---:|---:|---:|
| 1,000 | 592,000 | 31.2 ms | 15.3 ms | 11.1 ms |
| 10,000 | 5,938,000 | 291.6 ms | 157.6 ms | 110.2 ms |
| 50,000 | 30,868,000 | 1,745.7 ms | 860.8 ms | 661.6 ms |

The 10k-record full-inbox completion at 50k baseline took 1,051.8 ms. The “one_record_zone_page_ack” label means fetcher receive+token commit then completeIncoming/baseline commit; it is not a network/server acknowledgment or domain item mutation. It does not include the service's second redundant receive/staging pass. Warm load/save explicitly calls real disk serialization, not merely synthetic encoder work. This is convincing production-path baseline scaling and makes metadata a strong second recommendation ahead of a complex incremental relation rewrite, especially for large sync histories.

These are baseline costs, not a measured optimization: no candidate cache/unchanged-write-elision implementation was run. A decoded cache still leaves encode/atomic-write cost; removing unchanged bookkeeping writes or duplicate receipts can help without changing file format, but do not multiply baseline figures into claimed savings. Whole-process maximum RSS was 741,081,088 bytes, including synthetic seed/inbox arrays and all scales; do not attribute it to a single production event or claim a measured memory reduction. Before/after metadata process guards are empty, although the broader review had external builds and three samples remain a small local trial; deterministic source scaling and actual CPU/file work are stronger conclusions than an environment-independent SLA.

Final ordering remains **bounded ordinary head first**, **format-preserving metadata work second**, **incremental relation rebuild third**. The head has a direct first-visible-card consumer, the strongest measured alternative work reduction, no new persistent state and straightforward fallback to existing constrained/work routes. Metadata may consume more aggregate CPU for a particular large synchronized library, but its safe unchanged-format alternative benefit and impact on local foreground tasks are not yet measured. State this conditional tradeoff rather than assert a universal fastest-path winner.
