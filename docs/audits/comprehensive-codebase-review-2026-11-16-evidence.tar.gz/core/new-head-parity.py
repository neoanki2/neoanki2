import pathlib,sqlite3,json
root=pathlib.Path(__file__).parent
space={'__file__':str(root/'sql-probe.py')};s=(root/'sql-probe.py').read_text();exec(s[:s.index('results=[]')],space)
dst=root/'new-head-parity.sqlite';source=sqlite3.connect('file:'+str(root/'fixtures/n100/library.sqlite')+'?mode=ro',uri=True);d=sqlite3.connect(dst);source.backup(d);source.close()
ids=d.execute('SELECT id,item_id FROM cards ORDER BY id LIMIT 8').fetchall();deck='00000000-0000-4000-8000-000000000002'
d.execute('INSERT INTO decks(id,name,parent_id,new_cards_per_day) VALUES (?,"Scoped",NULL,NULL)',[deck]);cases=[]
mutations=[('basic',None),('suspended-first',('UPDATE cards SET is_suspended=1 WHERE id=?',[ids[0][0]])),('future-second',('UPDATE cards SET due_at=1800000100 WHERE id=?',[ids[1][0]])),('shared-family',('UPDATE study_item_relations SET family_key="shared" WHERE item_id IN (?,?)',[ids[2][1],ids[3][1]])),('due-learned-relative',('UPDATE cards SET phase="review" WHERE id=?',[ids[2][0]])),('remove-family-representative-from-scope',('UPDATE cards SET deck_id=? WHERE id=?',[deck,ids[3][0]])),('corrupt-template',('DELETE FROM study_valid_templates WHERE template_id=(SELECT template_id FROM cards WHERE id=?)',[ids[4][0]]))]
for name,mutation in mutations:
 if mutation:d.execute(*mutation)
 for scope,candidate in [('1=1','1 = 1'),(f"cards.deck_id='{deck}'",f"candidate.deck_id='{deck}'"),('cards.deck_id IS NULL','candidate.deck_id IS NULL')]:
  a=space['new'].replace('AND 1=1',f'AND {scope}').replace('(1 = 1)',f'({candidate})')
  b=space['newalt'].replace('AND 1=1',f'AND {scope}').replace('(1 = 1)',f'({candidate})')
  left=d.execute(a).fetchall();right=d.execute(b).fetchall();assert left==right,(name,scope,left,right)
  cases.append(dict(case=name,scope=scope,result=left))
d.rollback();d.close();(root/'new-head-parity.json').write_text(json.dumps(cases,indent=2));print(len(cases),'cases passed')
