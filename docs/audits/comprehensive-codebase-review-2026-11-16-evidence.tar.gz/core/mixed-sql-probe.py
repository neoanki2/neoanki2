import pathlib,sqlite3,json,statistics,time,subprocess
root=pathlib.Path(__file__).parent
scope={'__file__':str(root/'sql-work-counts.py')};s=(root/'sql-work-counts.py').read_text();exec(s[:s.index('out=[]')],scope)
original=root/'fixtures/n100000/library.sqlite';target=root/'mixed100k.sqlite'
a=sqlite3.connect('file:'+str(original)+'?mode=ro',uri=True);d=sqlite3.connect(target);a.backup(d);a.close()
# SQL-only adversarial fixture, not an end-to-end decoded-card model. Each bucket25k.
d.execute("UPDATE cards SET phase='review' WHERE rowid%4=0")
d.execute("UPDATE cards SET due_at=1801000000 WHERE rowid%4=1")
d.execute("UPDATE cards SET is_suspended=1 WHERE rowid%4=2")
d.commit();d.close()
db=scope['ptr']();scope['lib'].sqlite3_open_v2(str(target).encode(),scope['C'].byref(db),1,None)
results=[]
for name in ['has','alt','learned','new','newalt']:
 result=scope['run'](db,scope['space'][name]);results.append(dict(name=name,**result))
assert results[0]['rows']==results[1]['rows'];assert results[3]['rows']==results[4]['rows']
scope['lib'].sqlite3_close(db)
(root/'mixed100k-work-counts.json').write_text(json.dumps(results,indent=2))
# Current corrected forced-index query walltimes, guarded per flow, fixture setup untimed.
wall=[]
for n in [100,1000,25000,100000]:
 c=sqlite3.connect('file:'+str(root/f'fixtures/n{n}/library.sqlite')+'?mode=ro',uri=True)
 for name in ['has','alt','learned','new','newalt']:
  guard_before=subprocess.run(['pgrep','-x','xcodebuild'],capture_output=True,text=True).stdout.strip()
  q=scope['space'][name];samples=[];repetitions=5 if n>=25000 and name in ['has','new'] else 100
  for i in range(repetitions+1):
   t=time.perf_counter_ns();r=c.execute(q).fetchall();ms=(time.perf_counter_ns()-t)/1e6
   if i:samples.append(ms)
  guard_after=subprocess.run(['pgrep','-x','xcodebuild'],capture_output=True,text=True).stdout.strip()
  wall.append(dict(n=n,name=name,repetitions=repetitions,median_ms=statistics.median(samples),minimum_ms=min(samples),maximum_ms=max(samples),p95_ms=sorted(samples)[94] if repetitions==100 else None,build_pids_before=guard_before,build_pids_after=guard_after,sql=q,plan=list(c.execute('EXPLAIN QUERY PLAN '+q))))
 c.close()
(root/'guarded-sql-results.json').write_text(json.dumps(wall,indent=2))
print(json.dumps([{k:v for k,v in r.items() if k not in ['sql','plan']} for r in wall],indent=2))
