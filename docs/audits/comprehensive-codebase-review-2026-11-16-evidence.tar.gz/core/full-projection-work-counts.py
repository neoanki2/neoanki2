# Reproduce the complete production queue SELECT projection; deterministic only.
import pathlib,sqlite3,json
root=pathlib.Path(__file__).parent
ns={'__file__':str(root/'sql-work-counts.py')};src=(root/'sql-work-counts.py').read_text();exec(src[:src.index('out=[]')],ns)
columns='id, item_id, template_id, skill, memory, is_suspended, deck_id, cloze_group, occlusion_group, memory_model_version, memory_parameter_set_id, scheduling_history_origin'
queries={'new_full_production':ns['space']['new'].replace('SELECT id FROM eligible_due',f'SELECT {columns} FROM eligible_due'),'new_full_specialized':ns['space']['newalt'].replace('SELECT cards.id FROM cards',f'SELECT {columns} FROM cards')}
results=[]
for n in [100,1000,25000,100000]:
 db=ns['ptr']();assert ns['lib'].sqlite3_open_v2(str(root/f'fixtures/n{n}/library.sqlite').encode(),ns['C'].byref(db),1,None)==0
 c=sqlite3.connect('file:'+str(root/f'fixtures/n{n}/library.sqlite')+'?mode=ro',uri=True)
 rows={}
 for name,q in queries.items():
  r=ns['run'](db,q);rows[name]=r['rows'];results.append(dict(items=n,name=name,sql=q,plan=list(c.execute('EXPLAIN QUERY PLAN '+q)),**r))
 assert rows['new_full_production']==rows['new_full_specialized']
 ns['lib'].sqlite3_close(db);c.close()
(root/'full-projection-work-counts.json').write_text(json.dumps(results,indent=2))
print(json.dumps([{k:v for k,v in r.items() if k not in ['sql','plan']} for r in results],indent=2))
