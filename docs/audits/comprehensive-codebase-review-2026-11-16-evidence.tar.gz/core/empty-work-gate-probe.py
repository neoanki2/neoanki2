# Deterministic SQLite statement counters/plans only; no timing during baseline tests.
import pathlib,sqlite3,json
root=pathlib.Path(__file__).parent
ns={'__file__':str(root/'sql-work-counts.py')};src=(root/'sql-work-counts.py').read_text();exec(src[:src.index('out=[]')],ns)
gate='SELECT 1 FROM study_item_relations AS relation INDEXED BY idx_study_work WHERE relation.work_key IS NOT NULL LIMIT 1'
results=[]
for n in [100,1000,25000,100000]:
 db=ns['ptr']();assert ns['lib'].sqlite3_open_v2(str(root/f'fixtures/n{n}/library.sqlite').encode(),ns['C'].byref(db),1,None)==0
 r=ns['run'](db,gate);assert not r['rows'];ns['lib'].sqlite3_close(db)
 c=sqlite3.connect('file:'+str(root/f'fixtures/n{n}/library.sqlite')+'?mode=ro',uri=True)
 results.append(dict(items=n,sql=gate,plan=list(c.execute('EXPLAIN QUERY PLAN '+gate)),**r));c.close()
(root/'empty-work-gate-counts.json').write_text(json.dumps(results,indent=2))
c=sqlite3.connect('file:'+str(root/'fixtures/n100/library.sqlite')+'?mode=ro',uri=True)
target=root/'empty-work-gate-parity.sqlite';d=sqlite3.connect(target);c.backup(d);c.close()
ids=d.execute('SELECT id,item_id FROM cards ORDER BY id LIMIT 3').fetchall();deck='00000000-0000-4000-8000-000000000003'
d.execute('INSERT INTO decks(id,name,parent_id,new_cards_per_day) VALUES (?,"Gate scoped",NULL,NULL)',[deck]);parity=[]
for label,mutation in [('no-work',None),('due-work',('UPDATE study_item_relations SET work_key="sequence",source_ordinal=0 WHERE item_id=?',[ids[0][1]])),('future-work',('UPDATE cards SET due_at=1800000100 WHERE id=?',[ids[0][0]])),('suspended-work',('UPDATE cards SET due_at=1800000000,is_suspended=1 WHERE id=?',[ids[0][0]])),('out-of-scope-work',('UPDATE cards SET is_suspended=0,deck_id=? WHERE id=?',[deck,ids[0][0]])),('two-work-rows',('UPDATE study_item_relations SET work_key="sequence",source_ordinal=1 WHERE item_id=?',[ids[1][1]]))]:
 if mutation:d.execute(*mutation)
 exists=bool(d.execute(gate).fetchall())
 for where in ['1=1',f"cards.deck_id='{deck}'",'cards.deck_id IS NULL']:
  q=ns['space']['has'].replace('1=1',where)
  old=d.execute(q).fetchall();new=d.execute(q).fetchall() if exists else [];assert old==new
  parity.append(dict(case=label,scope=where,globally_has_work=exists,existing_result=old,new_result=new,original_scoped_query_retained=exists))
d.rollback();d.close();(root/'empty-work-gate-parity.json').write_text(json.dumps(parity,indent=2))
print(json.dumps(results,indent=2));print('parity_cases',len(parity))
