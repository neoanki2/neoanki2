import sqlite3,pathlib,time,json,statistics
root=pathlib.Path(__file__).parent
src=pathlib.Path('NeoAnkiCore/Sources/NeoAnkiCore/Database/SQLiteDatabase.swift').read_text()
part=src[src.index('    private func newFamilyEligibilitySQL'):src.index('    func cacheToken()')]
family=part[part.index('        return """')+len('        return """'):part.index('        """',part.index('        return """')+20)]
def usable(alias):
 return f'EXISTS (SELECT 1 FROM items AS study_item JOIN study_valid_templates AS usable ON usable.item_type_id = study_item.item_type_id WHERE study_item.id = {alias}.item_id AND usable.template_id = {alias}.template_id)'
family=family.replace('\\(instant)','1800000000.0').replace('\\(start)','1799964000.0').replace('\\(end)','1800050400.0').replace('\\(candidateScope)','1 = 1')
for alias in ['learned','candidate']: family=family.replace('\\(usableStudyCardSQL("'+alias+'"))',usable(alias))
assert '\\(' not in family, family
has='''SELECT 1 FROM study_item_relations AS relation JOIN cards ON cards.item_id = relation.item_id WHERE relation.work_key IS NOT NULL AND cards.is_suspended = 0 AND cards.due_at <= 1800000000 AND 1=1 LIMIT 1'''
alt='''SELECT 1 FROM study_item_relations AS relation INDEXED BY idx_study_work WHERE relation.work_key IS NOT NULL AND EXISTS (SELECT 1 FROM cards WHERE cards.item_id = relation.item_id AND cards.is_suspended = 0 AND cards.due_at <= 1800000000 AND 1=1) LIMIT 1'''
learned=f'''SELECT cards.id FROM cards WHERE cards.is_suspended=0 AND {usable('cards')} AND cards.due_at<=1800000000 AND 1=1 AND cards.phase!='new' ORDER BY cards.due_at,cards.id LIMIT 1'''
new=f'''WITH eligible_due AS (SELECT cards.* FROM cards WHERE cards.is_suspended=0 AND {usable('cards')} AND cards.due_at<=1800000000 AND 1=1 AND (cards.phase!='new' OR ({family}))) SELECT id FROM eligible_due WHERE phase='new' ORDER BY due_at,id LIMIT 1'''
newalt=f"SELECT cards.id FROM cards INDEXED BY idx_cards_active_new_due WHERE cards.is_suspended=0 AND cards.phase='new' AND {usable('cards')} AND cards.due_at<=1800000000 AND 1=1 AND ({family}) ORDER BY cards.due_at,cards.id LIMIT 1"
results=[]
for n in [100,1000,25000,100000]:
 c=sqlite3.connect('file:'+str(root/f'fixtures/n{n}/library.sqlite')+'?mode=ro',uri=True)
 for name,q in [('has-work-production',has),('has-work-relation-first',alt),('learned-queue-production',learned),('new-queue-production',new),('new-queue-specialized-index',newalt)]:
  plan=list(c.execute('EXPLAIN QUERY PLAN '+q)); outputs=list(c.execute(q)); samples=[]
  for _ in range(5 if n==100000 and name in ['has-work-production','new-queue-production'] else 100):
   t=time.perf_counter_ns(); rows=list(c.execute(q)); samples.append((time.perf_counter_ns()-t)/1e6); assert rows==outputs
  results.append(dict(n=n,name=name,median_ms=statistics.median(samples),p95_ms=sorted(samples)[int((len(samples)-1)*0.95)],result=outputs,plan=plan,sql=q))
  print(json.dumps({k:v for k,v in results[-1].items() if k not in ['sql','plan','result']}),flush=True)
 assert list(c.execute(has))==list(c.execute(alt))
 c.close()
(root/'sql-query-results.json').write_text(json.dumps(results,indent=2))
