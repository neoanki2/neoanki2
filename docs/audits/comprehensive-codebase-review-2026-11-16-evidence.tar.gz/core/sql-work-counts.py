import ctypes as C, pathlib,json,sqlite3
root=pathlib.Path(__file__).parent
space={'__file__':str(root/'sql-probe.py')}; s=(root/'sql-probe.py').read_text();exec(s[:s.index('results=[]')],space)
lib=C.CDLL('/usr/lib/libsqlite3.dylib')
ptr=C.c_void_p
lib.sqlite3_open_v2.argtypes=[C.c_char_p,C.POINTER(ptr),C.c_int,ptr]
lib.sqlite3_prepare_v2.argtypes=[ptr,C.c_char_p,C.c_int,C.POINTER(ptr),ptr]
lib.sqlite3_step.argtypes=[ptr];lib.sqlite3_stmt_status.argtypes=[ptr,C.c_int,C.c_int]
lib.sqlite3_column_text.argtypes=[ptr,C.c_int];lib.sqlite3_column_text.restype=C.c_char_p
lib.sqlite3_finalize.argtypes=[ptr];lib.sqlite3_close.argtypes=[ptr]
def run(db,q):
 st=ptr();rc=lib.sqlite3_prepare_v2(db,q.encode(),-1,C.byref(st),None);assert rc==0,(rc,q)
 rows=[]
 while True:
  rc=lib.sqlite3_step(st)
  if rc==101:break
  assert rc==100,rc
  value=lib.sqlite3_column_text(st,0);rows.append(value.decode() if value else None)
 answer=dict(rows=rows,vm_steps=lib.sqlite3_stmt_status(st,4,0),sorts=lib.sqlite3_stmt_status(st,2,0),fullscan_steps=lib.sqlite3_stmt_status(st,1,0))
 lib.sqlite3_finalize(st);return answer
out=[]
for n in [100,1000,25000,100000]:
 db=ptr();assert lib.sqlite3_open_v2(str(root/f'fixtures/n{n}/library.sqlite').encode(),C.byref(db),1,None)==0
 values={}
 for name in ['has','alt','learned','new','newalt']:
  values[name]=run(db,space[name]);out.append(dict(n=n,name=name,**values[name])); print(json.dumps(out[-1]),flush=True)
 assert values['has']['rows']==values['alt']['rows'];assert values['new']['rows']==values['newalt']['rows']
 lib.sqlite3_close(db)
(root/'sql-work-counts.json').write_text(json.dumps(out,indent=2))
# Algebraic existence equivalence plus key edge cases on disposable copy only.
original=root/'fixtures/n100/library.sqlite'
c=sqlite3.connect('file:'+str(original)+'?mode=ro',uri=True);dst=root/'mixed-parity.sqlite';d=sqlite3.connect(dst);c.backup(d);c.close()
ids=d.execute('SELECT id,item_id FROM cards ORDER BY id LIMIT 6').fetchall();deck='00000000-0000-4000-8000-000000000001'
d.execute('INSERT INTO decks(id,name,parent_id,new_cards_per_day) VALUES (?,"Scoped",NULL,NULL)',[deck])
cases=[]
for name,mutation in [('ordinary-empty-work',None),('work-due',('UPDATE study_item_relations SET work_key="work-1",source_ordinal=0 WHERE item_id=?',[ids[0][1]])),('work-suspended',('UPDATE cards SET is_suspended=1 WHERE id=?',[ids[0][0]])),('work-future',('UPDATE cards SET is_suspended=0,due_at=1800000100 WHERE id=?',[ids[0][0]])),('mixed-second-due-work',('UPDATE study_item_relations SET work_key="work-2",source_ordinal=0 WHERE item_id=?',[ids[1][1]])),('work-scoped',('UPDATE cards SET deck_id=? WHERE id=?',[deck,ids[1][0]])),('work-mastered-not-due',('UPDATE cards SET phase="review",due_at=1800000100 WHERE id=?',[ids[1][0]]))]:
 if mutation:d.execute(*mutation)
 for scope in ['1=1',f"cards.deck_id='{deck}'",'cards.deck_id IS NULL']:
  a=space['has'].replace('1=1',scope);b=space['alt'].replace('1=1',scope)
  l=d.execute(a).fetchall();r=d.execute(b).fetchall();assert l==r,(name,scope,l,r)
  cases.append(dict(case=name,scope=scope,result=l))
d.rollback();d.close();(root/'has-work-parity.json').write_text(json.dumps(cases,indent=2))
