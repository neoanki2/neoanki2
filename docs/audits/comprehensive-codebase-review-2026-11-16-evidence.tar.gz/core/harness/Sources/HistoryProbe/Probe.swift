import Foundation
import NeoAnkiCore
@main struct HistoryProbe {
 @MainActor static func main() async throws {
  let root=URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
  try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
  let source=URL(fileURLWithPath:CommandLine.arguments[2])
  let file=root.appendingPathComponent("library.sqlite")
  try FileManager.default.copyItem(at:source,to:file)
  let store=try ItemStore(databaseURL:file)
  try await store.bootstrap();await store.requestAutomaticSchedulingMaintenance(after:3600)
  let now=Date(timeIntervalSince1970:1800000000)
  let all=try await store.fetchDueCards(asOf:now)
  let count=min(all.count,1000)
  for day in 0..<12 {
   for (index,entry) in all.prefix(count).enumerated() {
    let at=now.addingTimeInterval(Double(day-12)*86400)
    _=try await store.submitReview(cardID:entry.id,rating:(index%5==0 && day%4==0) ? .again:.good,now:at,durationMs:1500)
   }
   print("reviews=\((day+1)*count)");fflush(stdout)
  }
  await store.requestAutomaticSchedulingMaintenance(after:3600)
  for phase in ["warm","after-tag","after-type"] {
   if phase=="after-tag",var item=try await store.fetchItem(id:all[0].item.id)?.item {
    item.tags=["history-fixture"];_=try await store.updateItem(item,now:now)
   }
   if phase=="after-type" { var type=try await store.itemType(id:BuiltInItemTypes.basicID);type.name="Basic Renamed";_=try await store.updateItemType(type,now:now) }
   for i in 0..<5 {
    let start=ContinuousClock.now
    let head=try await store.fetchDueCards(asOf:now.addingTimeInterval(180*86400),limit:1)
    let summary=try await store.scopeSummary(scope:.allDecks,asOf:now.addingTimeInterval(180*86400))
    let duration=start.duration(to:ContinuousClock.now)
    let ms=Double(duration.components.seconds)*1000+Double(duration.components.attoseconds)/1e15
    print("{\"phase\":\"\(phase)\",\"iteration\":\(i),\"ms\":\(ms),\"items\":\(count),\"reviews\":\(count*12),\"head\":\(head.count),\"due\":\(summary.dueNow)}")
   }
  }
 }
}
