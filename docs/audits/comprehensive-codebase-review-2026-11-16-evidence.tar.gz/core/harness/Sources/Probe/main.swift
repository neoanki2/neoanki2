import Foundation
import NeoAnkiCore

@MainActor func measure<T>(_ operation: () async throws -> T) async rethrows -> (T,Double) {
    let clock = ContinuousClock()
    let begin = clock.now
    let result = try await operation()
    let elapsed = begin.duration(to: clock.now)
    return (result, Double(elapsed.components.seconds)*1000 + Double(elapsed.components.attoseconds)/1e15)
}
func emit(_ name: String, _ count: Int, _ iteration: Int, _ ms: Double, _ detail: Int = 0) {
    print("{\"flow\":\"\(name)\",\"items\":\(count),\"iteration\":\(iteration),\"ms\":\(ms),\"result\":\(detail)}")
    fflush(stdout)
}
@main struct Probe {
 static func main() async throws {
    let root = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
    let sizes = CommandLine.arguments.dropFirst(2).compactMap(Int.init)
    let now = Date(timeIntervalSince1970: 1_800_000_000)
    for count in sizes {
        let fixtureRoot = root.appendingPathComponent("n\(count)", isDirectory: true)
        try FileManager.default.createDirectory(at: fixtureRoot, withIntermediateDirectories: true)
        let store = try ItemStore(databaseURL: fixtureRoot.appendingPathComponent("library.sqlite"))
        try await store.bootstrap()
        await store.requestAutomaticSchedulingMaintenance(after: 3600)
        for start in stride(from: 0, to: count, by: 10_000) {
            let rows = (start..<min(count,start+10_000)).map { ["Front": "Question \($0)", "Back": "Answer \($0)"] }
            let data = try JSONSerialization.data(withJSONObject: ["itemType":"Basic", "rows":rows])
            let (_,ms) = try await measure { try await store.importItems(from: data, adapter: JSONImportAdapter(), now: now) }
            emit("fixture-import", count, start, ms)
        }
        let first = try await store.listItems()[0]
        var item = try await store.fetchItem(id: first.id)!.item
        _ = try await store.fetchDueCards(asOf: now, limit: 1)
        for i in 0..<100 {
            let (cards,warm) = try await measure { try await store.fetchDueCards(asOf: now, limit: 1) }
            emit("queue-one-warm", count, i, warm, cards.count)
            if i >= 5 { continue }
            item.tags = ["changed-\(i)"]
            let (_,update) = try await measure { try await store.updateItem(item, now: now) }
            emit("one-tag-update", count, i, update)
            let (after,cold) = try await measure { try await store.fetchDueCards(asOf: now, limit: 1) }
            emit("queue-one-after-tag-update", count, i, cold, after.count)
            precondition(after.count == 1)
        }
        for i in 0..<3 {
            let (all,ms) = try await measure { try await store.fetchDueCards(asOf: now) }
            emit("queue-all-hydrated", count, i, ms, all.count)
            precondition(all.count == count)
            let (rows,browse) = try await measure { try await store.listItems(scope: .allDecks, sort: .titleAscending, search: "Question") }
            emit("browse-search-sort-all", count, i, browse, rows.count)
            precondition(rows.count == count)
        }
        // Public promotion statistics path, fixed deterministic observations; no optimizer training.
        for scale in count == sizes.last ? [1000, 10000] : [] {
            let observations = (0..<scale).map { index in
                FSRSPromotionObservation(cardID: UUID(uuidString: String(format:"00000000-0000-4000-8000-%012d",index/10))!, reviewedAt: now.addingTimeInterval(Double(index)*86_400), elapsedDays: Double(index%30+1), recalled: index%5 != 0, activeProbability: 0.8, defaultProbability: 0.8, candidateProbability: 0.81)
            }
            for i in 0..<3 {
                let (_,ms) = await measure { FSRSPromotionPolicy().metrics(observations: observations, desiredRetention: 0.9) }
                emit("promotion-bootstrap", scale, i, ms)
            }
        }
    }
 }
}
