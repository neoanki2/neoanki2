// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "FreshReviewProbe", platforms: [.macOS(.v14)], dependencies: [.package(path: "/Users/yanzay/projects/yanzay/neoanki2/NeoAnkiCore")], targets: [.executableTarget(name: "Probe", dependencies: [.product(name: "NeoAnkiCore", package: "NeoAnkiCore")]), .executableTarget(name: "HistoryProbe", dependencies: [.product(name: "NeoAnkiCore", package: "NeoAnkiCore")])])
