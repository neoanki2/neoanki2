# Fresh codebase investigation evidence

Analysis only, November 16, 2026. Read REPORT.md for the consolidated findings. The source basis is commit 5baf3fe4810512ea9e00babba2f3ae6fbfe67c3f plus the stable current-source snapshot and manifest; another task removed the vocabulary builder during review. Historical investigation reports were removed before agents started and were not used as evidence.

## Contents

- snapshot/: frozen repository source/config/docs; snapshot-manifest.json contains all 866 hashes. No production library or credentials are included.
- coverage.tsv: unified file classification, structural scan, exact agent semantic/focused slices and hashes. Agent-specific ledgers retain detailed scope.
- cleanup-manifest.json: old investigation paths removed and protected categories. No historical findings/evidence are copied here; Git history remains untouched.
- core/report.md, application/report.md, integrations/report.md: actual independent investigations. integrations/*-challenge.md documents independent alternatives and limitations; the main report is the reconciled decision.
- core/README.md: probe commands, runtime/library details, and authoritative versus exploratory results. Definitive walltime tables: guarded-sql-results.json and metadata-confirmed-summary.json. Full production-projection counters: full-projection-work-counts.json; conservative gate: empty-work-gate-counts.json. Initial contaminated results remain explicitly exploratory.
- application/verification-results.md: 161 passing baseline tests plus documentation and snapshot checks; exact filters, commands and raw logs in application/verification/.
- core/harness and integrations/metadata-probe: external Swift diagnostic packages, not changes to product implementation. The working refresh wrapper is integrations/metadata-probe/Sources/RefreshProbe/Probe.swift. application/refresh-count-probe.swift is an earlier uncompiled draft retained to explain the corrected harness.
- fixture-manifest.json: hashes/counts for synthetic SQLite libraries. Databases, compilation products, caches and temporary metadata directories are omitted from the archive; source fixture generators/parameters remain.
- coordinator/: coverage merging, snapshot integrity checking, archive construction and final documentation/diff checks. No product improvement or release execution occurs here.

## Reproduction

Unpack in a disposable directory. Diagnostic Package.swift files record original absolute dependency paths; on another machine, update only these external harness manifests to point to the included snapshot/NeoAnkiCore or snapshot root before building. Some diagnostic Python scripts expect core/fixtures/n{100,1000,25000,100000}/library.sqlite; generate those first using the external Probe as described in core/README.md. Each probe must use a fresh empty synthetic destination. Source UUIDs are generated per fixture, so fresh reruns preserve semantics/distribution rather than exact UUID bytes.

Run only one benchmark at a time, without compiler/test workloads. Do not infer application latency from SQL-only statements, machine-independent latency from this Mac, or a completed implementation from baseline tests. Metadata full-inbox consume remains an exploratory single sample; final page/bookkeeping/ack medians exclude iteration 0 and retain five observations. The invalid initial history-rename probe and original external compile failures are retained with explanations, not treated as application defects.

The two recommendations preserve external API contracts and file formats and require their own implementation review, acceptance campaign and release plan.
