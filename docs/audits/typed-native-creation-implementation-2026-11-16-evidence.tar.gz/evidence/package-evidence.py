from pathlib import Path
import subprocess,tarfile,json,hashlib
repo=Path.cwd();base=repo/'.build/typed-builders-study-head'
source=[]
for line in subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],text=True).splitlines():
 name=line[3:];p=repo/name
 if p.is_file() and not name.endswith(('.tar.gz','.tsv')):
  source.append(p)
manifest=[dict(path=str(p.relative_to(repo)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in source]
(base/'source-hashes.json').write_text(json.dumps({'base':'4f812e0','files':manifest},indent=2)+'\n')
archive=repo/'docs/audits/typed-native-creation-implementation-2026-11-16-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(base.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(base)
  if '.build' in rel.parts or rel.parts[0] in {'benchmark-binaries','benchmark-data'}:continue
  if p.suffix in {'.py','.swift','.log','.json','.jsonl','.txt','.stderr'}:
   tar.add(p,arcname='evidence/'+str(rel),recursive=False)
 for p in source:tar.add(p,arcname='source/'+str(p.relative_to(repo)),recursive=False)
print('Evidence archive:',archive.stat().st_size,'bytes;',len(source),'changed source/docs files')
