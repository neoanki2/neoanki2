import Foundation
import NeoAnkiCore
import NeoAnkiApplication
import NeoAnkiFeatures

@main struct AcceptanceProbe {
    @MainActor static func main() async throws {
        let fixture = URL(fileURLWithPath: CommandLine.arguments[1])
        let output = URL(fileURLWithPath: CommandLine.arguments[2])
        let count = Int(CommandLine.arguments[3])!
        let repetitions = Int(CommandLine.arguments[4])!
        try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
        let copy = output.appendingPathComponent("library.sqlite")
        try FileManager.default.copyItem(at: fixture, to: copy)
        let store = try ItemStore(databaseURL: copy)
        try await store.bootstrap()
        await store.requestAutomaticSchedulingMaintenance(after: 3600)
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        var expected: UUID?
        for index in -1..<repetitions {
            let clock = ContinuousClock(); let start = clock.now
            let cards = try await store.fetchDueCards(asOf: now, limit: 1)
            let elapsed = start.duration(to: clock.now)
            let ms = Double(elapsed.components.seconds)*1000 + Double(elapsed.components.attoseconds)/1e15
            precondition(cards.count == 1)
            if let expected { precondition(expected == cards[0].card.id) } else { expected = cards[0].card.id }
            print("{\"flow\":\"head\",\"n\":\(count),\"iteration\":\(index),\"ms\":\(ms),\"id\":\"\(cards[0].card.id)\"}")
            fflush(stdout)
        }
        let repository = SQLiteLibraryRepository(store: store)
        for index in -1..<5 {
            let model = StudyFeatureModel(library: repository, scope: .allDecks, title: "Acceptance", clock: { now })
            await model.start()
            precondition(!model.didFailToLoad && !model.isPreparingQueue && model.queue.count == count)
            let timing = model.lastStartTiming
            print("{\"flow\":\"feature-start\",\"n\":\(count),\"iteration\":\(index),\"firstReadyMs\":\(timing.firstReadySeconds*1000),\"totalMs\":\(timing.totalSeconds*1000),\"headMs\":\(timing.headFetchSeconds*1000)}")
            fflush(stdout)
        }
    }
}
