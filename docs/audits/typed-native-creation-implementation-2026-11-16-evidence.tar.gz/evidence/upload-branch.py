"""Publish local commit trees through authenticated gh only; never use git network commands."""
from pathlib import Path
import subprocess,json,base64,concurrent.futures,sys
repo='neoanki2/neoanki2';branch='refactor/typed-builders-study-head';base='5baf3fe4810512ea9e00babba2f3ae6fbfe67c3f'
root=Path(__file__).resolve().parent;receipt=root/'github-upload-receipt.json'
def local(*args):return subprocess.check_output(['git',*args]).decode().strip()
def api(path,method='GET',data=None):
 args=['gh','api','repos/'+repo+'/'+path,'--method',method]
 if data is not None:args+=['--input','-']
 p=subprocess.run(args,input=json.dumps(data) if data is not None else None,text=True,capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr)
 return json.loads(p.stdout)
state=json.loads(receipt.read_text()) if receipt.exists() else {'base':base,'commits':{},'blobs':{}}
head=local('rev-parse','HEAD');main=api('git/ref/heads/main')['object']['sha']
if main!=base:raise RuntimeError('Main changed; integrate it before publishing: '+main)
commits=local('rev-list','--reverse',base+'..'+head).splitlines();parent=base
for commit in commits:
 if commit in state['commits']:
  parent=state['commits'][commit]['sha'];continue
 source_parent=local('rev-parse',commit+'^');paths=local('diff','--name-only',source_parent,commit).splitlines();entries=[];uploads={}
 for path in paths:
  entry=local('ls-tree',commit,'--',path)
  if not entry:entries.append({'path':path,'mode':'100644','type':'blob','sha':None});continue
  mode,kind,sha=entry.split('\t')[0].split()
  if kind!='blob':raise RuntimeError('Unsupported tree entry '+path)
  entries.append({'path':path,'mode':mode,'type':kind,'sha':sha});uploads[sha]=path
 def blob(item):
  sha,path=item
  if sha in state['blobs']:return sha
  content=subprocess.check_output(['git','cat-file','blob',sha])
  result=api('git/blobs','POST',{'encoding':'base64','content':base64.b64encode(content).decode()})
  if result['sha']!=sha:raise RuntimeError('Blob hash mismatch '+path)
  return sha
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for sha in pool.map(blob,uploads.items()):state['blobs'][sha]=True
 receipt.write_text(json.dumps(state,indent=2)+'\n')
 tree=api('git/trees','POST',{'base_tree':local('rev-parse',source_parent+'^{tree}'),'tree':entries})
 if tree['sha']!=local('rev-parse',commit+'^{tree}'):raise RuntimeError('Remote tree mismatch')
 info=local('show','-s','--format=%an%n%ae%n%aI%n%cn%n%ce%n%cI%n%B',commit).splitlines()
 result=api('git/commits','POST',{'tree':tree['sha'],'parents':[parent],
  'message':'\n'.join(info[6:]).rstrip()+'\n',
  'author':dict(zip(['name','email','date'],info[:3])),
  'committer':dict(zip(['name','email','date'],info[3:6]))})
 state['commits'][commit]={'sha':result['sha'],'tree':tree['sha']};parent=result['sha'];receipt.write_text(json.dumps(state,indent=2)+'\n')
 print('Published commit tree',commit[:8],'as',parent[:8],flush=True)
# Create only; an existing different branch is never overwritten blindly.
check=subprocess.run(['gh','api','repos/'+repo+'/git/ref/heads/'+branch],capture_output=True,text=True)
if check.returncode:
 api('git/refs','POST',{'ref':'refs/heads/'+branch,'sha':parent})
elif json.loads(check.stdout)['object']['sha']!=parent:
 api('git/refs/heads/'+branch,'PATCH',{'sha':parent,'force':False})
state['head']=parent;receipt.write_text(json.dumps(state,indent=2)+'\n');print('Branch ready:',branch,parent)
