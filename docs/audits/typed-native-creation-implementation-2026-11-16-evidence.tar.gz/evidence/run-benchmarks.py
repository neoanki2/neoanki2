from pathlib import Path
import subprocess,json,statistics,time
base=Path(__file__).resolve().parent
fixtures=base.parent/'fresh-codebase-review-2026-11-16-5baf3fe/core/fixtures'
records=[]
for n in [100,1000,25000,100000]:
 for variant in ['baseline','candidate']:
  guard=subprocess.run(['pgrep','-x','xcodebuild'],capture_output=True,text=True)
  if guard.stdout.strip():raise RuntimeError('Competing xcodebuild: '+guard.stdout)
  package=base/('benchmark-'+variant)
  executable=package/'.build/out/Products/Release/AcceptanceProbe'
  target=base/'benchmark-data'/f'{variant}-{n}'
  output=base/f'performance-{variant}-{n}.jsonl'
  repetitions=100 if variant=='candidate' or n<=1000 else 5
  started=time.time()
  with output.open('w') as log:
   result=subprocess.run([str(executable),str(fixtures/f'n{n}/library.sqlite'),str(target),str(n),str(repetitions)],stdout=log,stderr=subprocess.PIPE,text=True)
  (base/f'performance-{variant}-{n}.stderr').write_text(result.stderr)
  guard_after=subprocess.run(['pgrep','-x','xcodebuild'],capture_output=True,text=True).stdout.strip()
  if result.returncode:raise RuntimeError(f'{variant} {n} failed: '+result.stderr[:1000])
  rows=[json.loads(line) for line in output.read_text().splitlines()]
  for flow,key in [('head','ms'),('feature-start','firstReadyMs'),('feature-start','totalMs')]:
   values=[r[key] for r in rows if r['flow']==flow and r['iteration']>=0]
   values.sort()
   records.append(dict(variant=variant,n=n,flow=flow,metric=key,samples=len(values),median_ms=statistics.median(values),min_ms=min(values),max_ms=max(values),p95_ms=values[max(0,(95*len(values)+99)//100-1)] if len(values)>=100 else None,competing_build_after=guard_after,started_unix=started))
  (base/'performance-summary.json').write_text(json.dumps(records,indent=2)+'\n')
  print(variant,n,'head median',round(records[-3]['median_ms'],3),'first ready',round(records[-2]['median_ms'],3),'gradeable',round(records[-1]['median_ms'],3),flush=True)
