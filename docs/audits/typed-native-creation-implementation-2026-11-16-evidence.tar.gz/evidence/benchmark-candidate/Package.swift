// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "AcceptanceProbe", platforms: [.macOS(.v14)], dependencies: [.package(path: "/Users/yanzay/projects/yanzay/neoanki2"),.package(path: "/Users/yanzay/projects/yanzay/neoanki2/NeoAnkiCore")], targets: [.executableTarget(name: "AcceptanceProbe", dependencies: [.product(name: "NeoAnkiCore", package: "NeoAnkiCore"),.product(name:"NeoAnkiApplication",package:"neoanki2"),.product(name:"NeoAnkiFeatures",package:"neoanki2")])])
