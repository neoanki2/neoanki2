"""Run only disposable CLI probes, serially, after fixture construction finishes."""
from pathlib import Path
import subprocess
import json
import time
import datetime
import os

ROOT = Path(__file__).resolve().parent.parent
EVIDENCE = ROOT / "evidence"
BINARY = ROOT / "snapshot/.build/release/ReviewProbe"

while "END n100000-h12000 exit 0" not in (EVIDENCE / "prepare.log").read_text():
    time.sleep(2)

records = []

def run(mode, fixture, count, history):
    name = f"{mode}-{fixture}"
    command = [str(BINARY), mode, str(ROOT / "fixtures" / fixture), str(count)]
    print("START", name, flush=True)
    with (EVIDENCE / (name + ".ndjson")).open("w") as output, (EVIDENCE / (name + ".stderr")).open("w") as error:
        result = subprocess.run(command, stdout=output, stderr=error, env=dict(os.environ, NEOANKI_REVIEW_DISABLE_MAINTENANCE="1"))
    records.append(dict(command=command, exit=result.returncode,
                        finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    (EVIDENCE / "measurement-commands.json").write_text(json.dumps(records, indent=2) + "\n")
    if result.returncode:
        raise SystemExit(f"Probe failed: {name}, exit {result.returncode}")
    for line in (EVIDENCE / (name + ".ndjson")).read_text().splitlines():
        row = json.loads(line)
        row.update(fixture=fixture, reviews=history)
        with (EVIDENCE / "measurements.ndjson").open("a") as output:
            output.write(json.dumps(row, sort_keys=True) + "\n")
    print("END", name, flush=True)

if (EVIDENCE / "measurements.ndjson").exists():
    raise SystemExit("Refuse to overwrite measurements")

for count, history in [(100, 1200), (1000, 0), (1000, 12000), (25000, 12000), (100000, 12000)]:
    run("read", f"n{count}-h{history}", count, history)

for count in (100, 1000, 25000, 100000):
    run("queue", f"queue-{count}", count, 0)

for count in (1000, 25000):
    run("transfer", f"n{count}-h12000", count, 12000)

print("MEASUREMENTS COMPLETE", flush=True)
