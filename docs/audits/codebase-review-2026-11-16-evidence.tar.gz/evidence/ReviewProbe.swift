import Foundation
import Darwin
import NeoAnkiCore
import NeoAnkiTestSupport
import NeoAnkiApplication
import NeoAnkiFeatures

@main
struct ReviewProbe {
    static let now = Date(timeIntervalSince1970: 1_794_787_200)
    static func seconds(_ duration: Duration) -> Double {
        Double(duration.components.seconds) + Double(duration.components.attoseconds) / 1e18
    }
    @MainActor
    static func measure(_ flow: String, repetition: Int, count: Int, body: () async throws -> Int) async throws {
        let start = ContinuousClock.now
        let result = try await body()
        let elapsed = seconds(start.duration(to: .now))
        let row: [String: Any] = ["flow": flow, "repetition": repetition, "warmup": repetition == 0,
            "items": count, "seconds": elapsed, "result": result]
        print(String(data: try JSONSerialization.data(withJSONObject: row, options: [.sortedKeys]), encoding: .utf8)!)
        fflush(nil)
    }
    @MainActor
    static func main() async throws {
        let args = CommandLine.arguments
        let mode = args[1]
        let directory = URL(fileURLWithPath: args[2], isDirectory: true)
        let count = Int(args[3])!
        let databaseURL = directory.appendingPathComponent("library.sqlite")
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        if mode == "prepare" {
            let store = try ItemStore(databaseURL: databaseURL)
            try await store.bootstrap()
            guard try await store.listItems().isEmpty else { fatalError("Refuse to seed an existing fixture") }
            let past = now.addingTimeInterval(-730 * 86_400)
            _ = try await PerformanceFixtures.seedBasicItems(count: count, in: store, now: past)
            let scale: PerformanceScale = count >= 100_000 ? .stress : count >= 25_000 ? .large : count >= 1_000 ? .medium : .small
            let decks = try await PerformanceFixtures.seedDecksAtScale(scale, in: store)
            try await PerformanceFixtures.assignItemsRoundRobin(to: decks, in: store)
            let historyCount = args.count > 4 ? Int(args[4])! : 0
            if historyCount > 0 {
                let cards = try await store.fetchDueCards(asOf: past, limit: min(count, 1_000))
                for index in 0..<historyCount {
                    let pass = index / cards.count
                    _ = try await store.submitReview(cardID: cards[index % cards.count].id,
                        rating: pass % 4 == 0 ? .again : .good,
                        now: past.addingTimeInterval(Double(pass * 8 + 1) * 86_400))
                }
            }
            print("PREPARED items=\(count) reviews=\(historyCount) database=\(databaseURL.path)")
            return
        }
        func makeStore() async throws -> ItemStore {
            let value = try ItemStore(databaseURL: databaseURL)
            try await value.bootstrap()
            return value
        }
        if mode == "bootstrap" {
            for repetition in 0..<6 {
                let store = try ItemStore(databaseURL: databaseURL)
                try await measure("existing-library-bootstrap", repetition: repetition, count: count) {
                    try await store.bootstrap(); return count
                }
            }
            return
        }
        if mode == "profile" {
            let store = try await makeStore()
            let card = try await store.fetchDueCards(asOf: now, limit: 1)[0]
            var deck = try await store.listDecks()[0]
            print("PROFILE_READY"); fflush(nil)
            let until = ContinuousClock.now.advanced(by: .seconds(12))
            var iteration = 0
            repeat {
                deck.name = "Profile rename \(iteration)"
                _ = try await store.updateDeck(deck)
                _ = try await store.cardMaturityStatus(id: card.id)
                iteration += 1
            } while ContinuousClock.now < until
            return
        }
        if mode == "memory" || mode == "memory-baseline" {
            let store = try await makeStore()
            let cards = try await store.fetchDueCards(asOf: now, limit: 1)
            if mode == "memory" { _ = try await store.cardMaturityStatus(id: cards[0].id) }
            return
        }
        if mode == "queue" {
            let type = BuiltInItemTypes.basic
            let source = (0..<count).map { index -> DueCard in
                let item = Item(itemTypeID: type.id, fields: [
                    .init(fieldID: BuiltInItemTypes.frontFieldID, value: .text("Question \(index)")),
                    .init(fieldID: BuiltInItemTypes.backFieldID, value: .text("Answer \(index)")),
                ])
                return DueCard(card: Card(itemID: item.id, templateID: type.templates[0].id, skill: type.templates[0].skill),
                    item: item, itemType: type, template: type.templates[0])
            }
            for repetition in 0..<101 {
                var queue = source
                try await measure("independent-queue-first-100", repetition: repetition, count: count) {
                    for index in 0..<min(100, queue.count) { StudyQueueOrdering.separateRelated(in: &queue, at: index) }
                    return min(100, queue.count)
                }
                precondition(queue == source)
            }
            return
        }
        let base = try await makeStore()
        let rows = try await base.listItems()
        precondition(rows.count == count)
        let card = try await base.fetchDueCards(asOf: now, limit: 1)[0]
        let decks = try await base.listDecks()
        if mode == "edit" || mode == "profile-study" {
            let original = try await base.fetchItem(id: rows[0].id)!.item
            var repetition = 0
            if mode == "profile-study" { print("PROFILE_READY"); fflush(nil) }
            let deadline = ContinuousClock.now.advanced(by: .seconds(mode == "profile-study" ? 12 : 0))
            repeat {
                let edited = Item(id: original.id, itemTypeID: original.itemTypeID,
                    fields: original.fields.map { field in
                        FieldValue(fieldID: field.fieldID, value: field.fieldID == BuiltInItemTypes.frontFieldID
                            ? .text("Edited question \(repetition)") : field.value)
                    }, tags: original.tags, deckID: original.deckID)
                try await measure("item-edit-and-study-first-50", repetition: repetition, count: count) {
                    _ = try await base.updateItem(edited, now: now)
                    return try await base.fetchDueCards(asOf: now, limit: 50).count
                }
                repetition += 1
            } while mode == "profile-study" ? ContinuousClock.now < deadline : repetition < 6
            return
        }
        if mode == "mix" {
            let front = FieldDef(name: "Rich question", type: .richText, isRequired: true)
            let back = FieldDef(name: "Answer", type: .text, isRequired: true)
            let picture = FieldDef(name: "Picture", type: .image, isRequired: false)
            let type = ItemType(name: "Mixed review fixture", fields: [front, back, picture], templates: [
                Template(name: "Read", prompt: Side(slots: [Slot(source: .field(front.id))]),
                    answer: Side(slots: [Slot(source: .field(back.id))]), interaction: .reveal,
                    skill: Skill(input: .text, output: .text, operation: .recall)),
                Template(name: "Picture", prompt: Side(slots: [Slot(source: .field(picture.id))]),
                    answer: Side(slots: [Slot(source: .field(back.id))]), interaction: .reveal,
                    skill: Skill(input: .image, output: .text, operation: .recall)),
            ])
            _ = try await base.createItemType(type)
            let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=")!
            for index in 0..<100 {
                let reserved = try await base.reserveMedia(data: png, kind: .image, altText: "One-pixel fixture", now: now)
                _ = try await base.createItem(Item(itemTypeID: type.id, fields: [
                    .init(fieldID: front.id, value: .rich([Span("Українське питання \(index) 🦔 "+String(repeating: "context ", count: 50), styles: [.bold])])),
                    .init(fieldID: back.id, value: .text("Answer \(index)")),
                    .init(fieldID: picture.id, value: .media(reserved.reference)),
                ], tags: ["mixed", "українська"], deckID: decks[0].id), now: now)
            }
            print("MIXED addedItems=100 addedCards=200 verifiedImageReferences=100")
            return
        }
        if mode == "read" {
            for repetition in 0..<6 {
                let homeStore = try await makeStore()
                try await measure("cold-home", repetition: repetition, count: count) {
                    try await homeStore.coldLibraryHomeSnapshot(asOf: now).allDecksSummary.itemCount
                }
                let detailStore = try await makeStore()
                try await measure("cold-single-card-maturity", repetition: repetition, count: count) {
                    _ = try await detailStore.cardMaturityStatus(id: card.id); return 1
                }
                let browseStore = try await makeStore()
                try await measure("cold-browse", repetition: repetition, count: count) {
                    try await browseStore.listItems().count
                }
                let dueStore = try await makeStore()
                try await measure("study-first-50", repetition: repetition, count: count) {
                    try await dueStore.fetchDueCards(asOf: now, limit: 50).count
                }
            }
            let library = SQLiteLibraryRepository(store: base)
            let model = LibraryFeatureModel(library: library)
            try await measure("feature-bootstrap", repetition: 1, count: count) {
                await model.bootstrap(startSync: false); return model.items.count
            }
            for repetition in 0..<101 {
                try await measure("warm-single-card-maturity", repetition: repetition, count: count) {
                    _ = try await base.cardMaturityStatus(id: card.id); return 1
                }
                try await measure("feature-visible-items", repetition: repetition, count: count) {
                    model.visibleItems.count
                }
            }
            for repetition in 0..<6 {
                var deck = decks[0]; deck.name = "Renamed \(repetition)"
                _ = try await base.updateDeck(deck)
                try await measure("single-card-maturity-after-deck-rename", repetition: repetition, count: count) {
                    _ = try await base.cardMaturityStatus(id: card.id); return 1
                }
                deck.name = "Feature renamed \(repetition)"
                _ = try await base.updateDeck(deck)
                try await measure("feature-refresh-after-write", repetition: repetition, count: count) {
                    try await model.reload(asOf: now); return model.items.count
                }
            }
            return
        }
        if mode == "transfer" || mode == "transfer-flat" {
            let exportRoot = try await base.createDeck(Deck(name: "Whole library export"))
            for var deck in decks where mode == "transfer-flat" || deck.parentID == nil {
                deck.parentID = exportRoot.id; _ = try await base.updateDeck(deck)
            }
            for repetition in 0..<6 {
                let destination = directory.appendingPathComponent("export-\(repetition).neodeck")
                try await measure("portable-export", repetition: repetition, count: count) {
                    try await PortableDeck.export(deckID: exportRoot.id, from: base, to: destination)
                    return Int(try destination.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0)
                }
                let targetDir = directory.appendingPathComponent("import-\(repetition)")
                try FileManager.default.createDirectory(at: targetDir, withIntermediateDirectories: true)
                let target = try ItemStore(databaseURL: targetDir.appendingPathComponent("library.sqlite"))
                try await target.bootstrap()
                try await measure("portable-import", repetition: repetition, count: count) {
                    try await PortableDeck.importDeck(from: destination, into: target).itemCount
                }
                try FileManager.default.removeItem(at: targetDir)
                try FileManager.default.removeItem(at: destination)
            }
        }
    }
}
