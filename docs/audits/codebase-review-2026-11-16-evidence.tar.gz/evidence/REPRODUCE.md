# Reproducing the codebase review

This archive describes the November 16, 2026 investigation, not product changes. Extract it into a new review directory; its contents live under `evidence/`. Large generated databases/build products are excluded. The original local run retains them under `.build/codebase-review-2026-11-16/`.

## Source and diagnostic setup

Use a detached, disposable checkout of revision `1bfe9f85baae51e3387615d71164d418545aa197` at `<review>/snapshot`. Apply `working-tree.patch`, then copy `untracked-inputs/` into that checkout. `inventory.json` records the original input hashes. `starting-status.txt` identifies the preexisting edits. `original-input-verification.json` confirms all original product inputs remain unchanged and records the one intentional documentation-hub link separately.

The original fast tests ran against that source before instrumentation. The retained XCTest failure is the missing shard entry for the new typed-answer mobile UI test. No unchanged failed check was rerun to obtain green results.

For measurements only:

1. Apply `diagnostic-maintenance-suppression.patch` inside the disposable checkout.
2. Copy `Package.diagnostic.swift` to its `Package.swift`.
3. Copy `ReviewProbe.swift` into `Tools/ReviewProbe/ReviewProbe.swift` and `FaultProbe.swift` into `Tools/FaultProbe/FaultProbe.swift`.
4. Build `ReviewProbe` and, separately, `FaultProbe` using `swift build -c release --product PRODUCT`.
5. Set `NEOANKI_REVIEW_DISABLE_MAINTENANCE=1` for controlled foreground measurements. No production algorithm or query was optimized; this guard only suppresses unrelated automatic fitting.

All probe paths must point to new disposable fixtures. Even `read` mode renames fixture decks to measure invalidation. Nothing here should use an installed application's database, media directory, or cloud account.

## Fixture and measurement commands

`prepare-fixtures.py` builds the original fixture sizes through production APIs. Invoke it with its output redirected to `evidence/prepare.log`. It refuses to seed an existing nonempty fixture. Content and timestamps follow the saved harness; persistence generates UUIDs. Identities stay fixed across repetitions. The final fixture manifest describes state after diagnostic mutations, not an initial database image.

The CLI shape is:

```text
ReviewProbe prepare DIRECTORY ITEM_COUNT REVIEW_COUNT
ReviewProbe read DIRECTORY ITEM_COUNT
ReviewProbe bootstrap DIRECTORY ITEM_COUNT
ReviewProbe queue DIRECTORY ITEM_COUNT
ReviewProbe edit DIRECTORY ITEM_COUNT
ReviewProbe transfer DIRECTORY ITEM_COUNT
ReviewProbe transfer-flat DIRECTORY ITEM_COUNT
ReviewProbe memory-baseline DIRECTORY ITEM_COUNT
ReviewProbe memory DIRECTORY ITEM_COUNT
ReviewProbe profile DIRECTORY ITEM_COUNT
ReviewProbe profile-study DIRECTORY ITEM_COUNT
FaultProbe NEW_DIRECTORY
```

`read` emits six samples for cold reads/post-write paths, 101 samples for warm detail/visible-item paths, and one exploratory feature bootstrap. Repetition zero is warm-up; the single feature bootstrap is excluded from ranking. Each post-write path receives an independent invalidation. `queue` times the first 100 independent positions and checks equality outside the timer. `edit` times one item edit followed by the first 50 study cards. `bootstrap` excludes store construction. `transfer-flat` reparents fixture decks into one level under a new root before timing whole-library exports and imports.

Primary commands and exits are retained in `measurement-commands.json`, `supplementary-commands.json` and `edit-commands.json`. The raw phase logs explain their sequence. `run-measurements.py`, `run-supplementary.py` and `run-profiles.py` are the controllers used for this particular run; their wait conditions refer to its recorded phase markers. For a fresh investigation, use the direct CLI modes above rather than treating those marker-dependent controllers as general-purpose tooling.

The mixed fixture is a SQLite backup of the 1,000-item/12,000-review fixture, extended through `mix DIRECTORY 1000` to add 100 rich-text/image items and 200 cards. Measure it with `read DIRECTORY 1100`. Flat transfer variants also use separate SQLite backups. The original nested failure remains preserved, with no product workaround applied.

## Profiling and statistics

Run benchmarks serially, with no competing builds. Use an optimized build and the same hardware/configuration. Exclude fixture construction and each flow's repetition zero. `measurement-summary.json` contains medians, minima/maxima, and nearest-rank p95 only when at least 100 measured samples exist. All 1,904 timing records, including warm-ups and exploratory single samples, are in `measurements.ndjson`.

For maturity/study CPU samples, launch `profile` or `profile-study`, wait for `PROFILE_READY`, then use `/usr/bin/sample PID 5 1 -file OUTPUT`. These modes perform a bounded 12-second phase after preparation. For bootstrap CPU evidence, sample a fresh `memory-baseline` process immediately. `profile-commands.json` and `study-projection-profile-command.json` record successful probe/sampling exits.

Memory files are single `/usr/bin/time -l` runs in separate fresh processes. Compare process lifetime peaks as descriptive resource evidence; do not subtract them and call the result attributable allocation. Filesystem caches and host background load were not controlled. No host app launch or rendered-frame timing was measured.

`query-plans.json` stores the exact SQL and query plans for all-card/active-history reads. `source-evidence.txt` holds cited source excerpts. `ranking-sensitivity.json` stores subjective candidate ratings, explicit weights, and recomputed rankings.

## Preserved failures

- `fault-probe.json`: the second selection move fails; one item moved durably but the shared native model still shows zero moved. The probe exits successfully only when it detects this existing weakness.
- `failed-nested-export.neodeck`: an exported package passing SQLite integrity/foreign-key checks. The current import order encounters a child before its parent and fails. `nested-import-failure.json` records package order and the empty rolled-back target; the original stderr and command exit are retained. A separate flat dataset supplied successful throughput measurements.
- `test-fast.log` and `ui-manifest-difference.json`: the unchanged UI inventory assertion failure.
- `discarded-unisolated/`: preliminary reads interrupted during measurement setup, excluded from all statistics because automatic fitting was not isolated and independent invalidation was not yet established.

No improvements, validation assertions, recovery safeguards, public APIs or file formats were changed in the working checkout.
