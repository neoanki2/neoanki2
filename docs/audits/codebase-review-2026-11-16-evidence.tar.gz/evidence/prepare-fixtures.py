from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
BINARY = ROOT / "snapshot/.build/release/ReviewProbe"

for count, history in [(100, 1200), (1000, 0), (1000, 12000), (25000, 12000), (100000, 12000)]:
    name = f"n{count}-h{history}"
    started = time.monotonic()
    print("START", name, flush=True)
    result = subprocess.run([str(BINARY), "prepare", str(ROOT / "fixtures" / name), str(count), str(history)])
    print("END", name, "exit", result.returncode, "seconds", time.monotonic() - started, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
