from pathlib import Path
import os
import subprocess
import time
import json

ROOT = Path(__file__).resolve().parent.parent
EVIDENCE = ROOT / "evidence"
BINARY = ROOT / "snapshot/.build/release/ReviewProbe"
ENV = dict(os.environ, NEOANKI_REVIEW_DISABLE_MAINTENANCE="1")

while "SUPPLEMENTARY COMPLETE" not in (EVIDENCE / "supplementary-run.log").read_text():
    time.sleep(2)

results = []
for count, history in [(1000, 0), (1000, 12000), (100000, 12000)]:
    fixture = ROOT / f"fixtures/n{count}-h{history}"
    for mode in ("memory-baseline", "memory"):
        command = ["/usr/bin/time", "-l", str(BINARY), mode, str(fixture), str(count)]
        with (EVIDENCE / f"{mode}-n{count}-h{history}.txt").open("w") as output:
            result = subprocess.run(command, stdout=output, stderr=output, env=ENV)
        results.append(dict(command=command, exit=result.returncode))
        if result.returncode:
            raise SystemExit(result.returncode)

command = [str(BINARY), "profile", str(ROOT / "fixtures/n100000-h12000"), "100000"]
with (EVIDENCE / "profile-probe.log").open("w") as output:
    process = subprocess.Popen(command, stdout=output, stderr=output, env=ENV)
    deadline = time.monotonic() + 120
    while "PROFILE_READY" not in (EVIDENCE / "profile-probe.log").read_text():
        if process.poll() is not None or time.monotonic() > deadline:
            raise SystemExit("Maturity profiler did not reach the measured phase")
        time.sleep(0.05)
    sample = subprocess.run(["/usr/bin/sample", str(process.pid), "5", "1", "-file", str(EVIDENCE / "maturity-cpu-sample.txt")],
                            stdout=output, stderr=output)
    result = process.wait()
results.append(dict(command=command, exit=result, sampleExit=sample.returncode))
with (EVIDENCE / "bootstrap-profile-probe.log").open("w") as output:
    command = [str(BINARY), "memory-baseline", str(ROOT / "fixtures/n100000-h12000"), "100000"]
    process = subprocess.Popen(command, stdout=output, stderr=output, env=ENV)
    sample = subprocess.run(["/usr/bin/sample", str(process.pid), "5", "1", "-file", str(EVIDENCE / "bootstrap-cpu-sample.txt")], stdout=output, stderr=output)
    result = process.wait()
results.append(dict(command=command, exit=result, sampleExit=sample.returncode))
(EVIDENCE / "profile-commands.json").write_text(json.dumps(results, indent=2) + "\n")
print("PROFILES COMPLETE", flush=True)
