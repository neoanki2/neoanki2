from pathlib import Path
import os
import subprocess
import sqlite3
import shutil
import json
import time

ROOT = Path(__file__).resolve().parent.parent
EVIDENCE = ROOT / "evidence"
SNAPSHOT = ROOT / "snapshot"
BINARY = SNAPSHOT / ".build/release/ReviewProbe"
ENV = dict(os.environ, NEOANKI_REVIEW_DISABLE_MAINTENANCE="1")

while "Probe failed: transfer-n1000-h12000" not in (EVIDENCE / "measurement-run.log").read_text():
    time.sleep(2)

shutil.copy2(EVIDENCE / "ReviewProbe.swift", SNAPSHOT / "Tools/ReviewProbe/ReviewProbe.swift")
with (EVIDENCE / "supplementary-build.log").open("w") as output:
    result = subprocess.run(["swift", "build", "-c", "release", "--product", "ReviewProbe"], cwd=SNAPSHOT, stdout=output, stderr=output)
if result.returncode:
    raise SystemExit(result.returncode)

records = []
def run(mode, fixture, count, history, parse=True):
    print("START", mode, fixture, flush=True)
    command = [str(BINARY), mode, str(ROOT / "fixtures" / fixture), str(count)]
    log = EVIDENCE / (mode + "-" + fixture + (".ndjson" if parse else ".log"))
    with log.open("w") as output, (EVIDENCE / (mode + "-" + fixture + ".stderr")).open("w") as error:
        result = subprocess.run(command, stdout=output, stderr=error, env=ENV)
    records.append(dict(command=command, exit=result.returncode))
    (EVIDENCE / "supplementary-commands.json").write_text(json.dumps(records, indent=2) + "\n")
    if result.returncode:
        raise SystemExit(result.returncode)
    if parse:
        with (EVIDENCE / "measurements.ndjson").open("a") as output:
            for line in log.read_text().splitlines():
                row = json.loads(line)
                row.update(fixture=fixture, reviews=history)
                output.write(json.dumps(row, sort_keys=True) + "\n")
    print("END", mode, fixture, flush=True)

for count, history in [(1000, 0), (1000, 12000), (25000, 12000), (100000, 12000)]:
    run("bootstrap", f"n{count}-h{history}", count, history)

mixed = ROOT / "fixtures/n1100-mixed-h12000"
mixed.mkdir()
source = sqlite3.connect(str(ROOT / "fixtures/n1000-h12000/library.sqlite"))
target = sqlite3.connect(str(mixed / "library.sqlite"))
source.backup(target)
target.close()
source.close()
run("mix", mixed.name, 1000, 12000, parse=False)
run("read", mixed.name, 1100, 12000)
for count in (1000, 25000):
    flat = ROOT / f"fixtures/n{count}-flat-h12000"
    flat.mkdir()
    source = sqlite3.connect(str(ROOT / f"fixtures/n{count}-h12000/library.sqlite"))
    target = sqlite3.connect(str(flat / "library.sqlite"))
    source.backup(target)
    target.close()
    source.close()
    run("transfer-flat", flat.name, count, 12000)
print("SUPPLEMENTARY COMPLETE", flush=True)
