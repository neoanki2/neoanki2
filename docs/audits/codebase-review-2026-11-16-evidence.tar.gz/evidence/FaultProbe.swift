import Foundation
import NeoAnkiCore
import NeoAnkiApplication
import NeoAnkiFeatures

@main struct FaultProbe {
    static func sql(_ statement: String, at path: String) throws {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/sqlite3")
        p.arguments = [path, statement]
        try p.run(); p.waitUntilExit()
        precondition(p.terminationStatus == 0)
    }
    @MainActor static func main() async throws {
        let directory = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent("library.sqlite")
        let repository = try SQLiteLibraryRepository(databaseURL: url)
        try await repository.bootstrap()
        let initiallyEmpty = try await repository.items(scope: .allDecks).isEmpty
        precondition(initiallyEmpty)
        let target = try await repository.createDeck(Deck(name: "Move destination"))
        var ids: [UUID] = []
        for i in 0..<3 {
            let value = try await repository.createItem(Item(itemTypeID: BuiltInItemTypes.basicID, fields: [
                .init(fieldID: BuiltInItemTypes.frontFieldID, value: .text("Question \(i)")),
                .init(fieldID: BuiltInItemTypes.backFieldID, value: .text("Answer")),
            ]))
            ids.append(value.id)
        }
        let model = LibraryFeatureModel(library: repository)
        await model.bootstrap(startSync: false)
        try sql("""
            CREATE TABLE probe_move_counter(value INTEGER);
            INSERT INTO probe_move_counter VALUES(0);
            CREATE TRIGGER probe_fail_second_move BEFORE UPDATE OF deck_id ON items BEGIN
                UPDATE probe_move_counter SET value=value+1;
                SELECT CASE WHEN (SELECT value FROM probe_move_counter)>=2 THEN RAISE(ABORT,'injected second-move failure') END;
            END;
            """, at: url.path)
        var thrown: String?
        do { try await model.moveItems(Set(ids.prefix(2)), to: target.id) }
        catch { thrown = String(describing: error) }
        let actual = try await repository.items(scope: .allDecks)
        let durableMoved = actual.filter { $0.deckID == target.id }.count
        let displayedMoved = model.items.filter { $0.deckID == target.id }.count
        let result: [String: Any] = ["threw": thrown != nil, "error": thrown ?? "",
            "durableMoved": durableMoved, "displayedMoved": displayedMoved,
            "selectedCount": 2, "totalItems": actual.count]
        print(String(data: try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys]), encoding: .utf8)!)
        precondition(thrown != nil && durableMoved == 1 && displayedMoved == 0 && actual.count == 3)
        try sql("DROP TRIGGER probe_fail_second_move; DROP TABLE probe_move_counter;", at: url.path)
    }
}
